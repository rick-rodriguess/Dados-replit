import { db, pool } from './db';
import { IStorage } from './storage';
import { 
  User, InsertUser,
  Specialty, InsertSpecialty,
  Question, InsertQuestion,
  Flashcard, InsertFlashcard,
  StudySession, InsertStudySession,
  QuestionReview, InsertQuestionReview,
  PracticeTest, InsertPracticeTest,
  AnswerKey, InsertAnswerKey,
  AiVerifiedAnswer, InsertAiVerifiedAnswer,
  users, specialties, questions, flashcards, studySessions, questionReviews, practiceTests,
  answerKeys, aiVerifiedAnswers
} from '../shared/schema';
import { sql, eq, desc, and, isNull, count } from 'drizzle-orm';
import { startOfDay } from 'date-fns';

export class DbStorage implements IStorage {
  constructor() {}

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  // Specialty operations
  async getSpecialties(): Promise<Specialty[]> {
    return await db.select().from(specialties);
  }

  async getSpecialty(id: number): Promise<Specialty | undefined> {
    const result = await db.select().from(specialties).where(eq(specialties.id, id)).limit(1);
    return result[0];
  }

  async getSpecialtyByName(name: string): Promise<Specialty | undefined> {
    const result = await db.select().from(specialties).where(eq(specialties.name, name)).limit(1);
    return result[0];
  }

  async createSpecialty(specialty: InsertSpecialty): Promise<Specialty> {
    const result = await db.insert(specialties).values(specialty).returning();
    return result[0];
  }

  // Question operations
  async getQuestions(userId: number): Promise<Question[]> {
    return await db.select().from(questions).where(eq(questions.userId, userId));
  }

  async getQuestion(id: number): Promise<Question | undefined> {
    const result = await db.select().from(questions).where(eq(questions.id, id)).limit(1);
    return result[0];
  }

  async getRecentQuestions(userId: number, limit: number): Promise<Question[]> {
    return await db.select()
      .from(questions)
      .where(eq(questions.userId, userId))
      .orderBy(desc(questions.createdAt))
      .limit(limit);
  }

  async getQuestionsBySpecialty(userId: number, specialtyId: number): Promise<Question[]> {
    return await db.select()
      .from(questions)
      .where(
        and(
          eq(questions.userId, userId),
          eq(questions.specialtyId, specialtyId)
        )
      );
  }

  async createQuestion(question: InsertQuestion): Promise<Question> {
    const result = await db.insert(questions).values(question).returning();
    return result[0];
  }

  async updateQuestion(id: number, updatedQuestion: Partial<Question>): Promise<Question | undefined> {
    const result = await db.update(questions)
      .set(updatedQuestion)
      .where(eq(questions.id, id))
      .returning();
    return result[0];
  }

  async deleteQuestion(id: number): Promise<boolean> {
    try {
      await db.delete(questions).where(eq(questions.id, id));
      return true;
    } catch (error) {
      return false;
    }
  }

  // Flashcard operations
  async getFlashcards(userId: number): Promise<Flashcard[]> {
    return await db.select().from(flashcards).where(eq(flashcards.userId, userId));
  }

  async getFlashcard(id: number): Promise<Flashcard | undefined> {
    const result = await db.select().from(flashcards).where(eq(flashcards.id, id)).limit(1);
    return result[0];
  }

  async createFlashcard(flashcard: InsertFlashcard): Promise<Flashcard> {
    const result = await db.insert(flashcards).values(flashcard).returning();
    return result[0];
  }

  async updateFlashcard(id: number, updatedFlashcard: Partial<Flashcard>): Promise<Flashcard | undefined> {
    const result = await db.update(flashcards)
      .set(updatedFlashcard)
      .where(eq(flashcards.id, id))
      .returning();
    return result[0];
  }

  async deleteFlashcard(id: number): Promise<boolean> {
    try {
      await db.delete(flashcards).where(eq(flashcards.id, id));
      return true;
    } catch (error) {
      return false;
    }
  }

  // Study session operations
  async getStudySessions(userId: number): Promise<StudySession[]> {
    return await db.select().from(studySessions).where(eq(studySessions.userId, userId));
  }

  async getActiveStudySession(userId: number): Promise<StudySession | undefined> {
    const result = await db.select()
      .from(studySessions)
      .where(
        and(
          eq(studySessions.userId, userId),
          isNull(studySessions.endTime)
        )
      )
      .limit(1);
    return result[0];
  }

  async createStudySession(session: InsertStudySession): Promise<StudySession> {
    const result = await db.insert(studySessions).values(session).returning();
    return result[0];
  }

  async updateStudySession(id: number, updatedSession: Partial<StudySession>): Promise<StudySession | undefined> {
    const result = await db.update(studySessions)
      .set(updatedSession)
      .where(eq(studySessions.id, id))
      .returning();
    return result[0];
  }

  async endStudySession(id: number, endTime: Date): Promise<StudySession | undefined> {
    const session = await this.getActiveStudySession(id);
    if (!session) return undefined;

    const duration = Math.floor(
      (endTime.getTime() - session.startTime.getTime()) / 1000
    );

    const result = await db.update(studySessions)
      .set({ 
        endTime: endTime,
        duration: duration
      })
      .where(eq(studySessions.id, id))
      .returning();
    return result[0];
  }

  async getTotalStudyTimeToday(userId: number): Promise<number> {
    const today = startOfDay(new Date());
    
    const result = await db.select({
      totalDuration: sql`COALESCE(SUM(duration), 0)`.mapWith(Number)
    })
    .from(studySessions)
    .where(
      and(
        eq(studySessions.userId, userId),
        sql`start_time >= ${today.toISOString()}`
      )
    );
    
    return result[0]?.totalDuration || 0;
  }

  // Question review operations
  async createQuestionReview(review: InsertQuestionReview): Promise<QuestionReview> {
    const result = await db.insert(questionReviews).values(review).returning();
    return result[0];
  }

  async getQuestionReviews(questionId: number): Promise<QuestionReview[]> {
    return await db.select()
      .from(questionReviews)
      .where(eq(questionReviews.questionId, questionId));
  }

  // Practice test operations
  async getPracticeTests(userId: number): Promise<PracticeTest[]> {
    return await db.select().from(practiceTests).where(eq(practiceTests.userId, userId));
  }

  async getPracticeTest(id: number): Promise<PracticeTest | undefined> {
    const result = await db.select().from(practiceTests).where(eq(practiceTests.id, id)).limit(1);
    return result[0];
  }

  async createPracticeTest(test: InsertPracticeTest): Promise<PracticeTest> {
    // Use pg-format SQL directly instead of Drizzle ORM for better control over JSON handling
    const client = await pool.connect();
    try {
      const result = await client.query(
        `INSERT INTO practice_tests (user_id, name, questions) 
         VALUES ($1, $2, $3::json) 
         RETURNING *`,
        [
          test.userId,
          test.name,
          JSON.stringify(test.questions || [])
        ]
      );
      
      // Convert the raw PostgreSQL row to our Drizzle type
      const row = result.rows[0];
      return {
        id: row.id,
        userId: row.user_id,
        name: row.name,
        questions: row.questions,
        createdAt: row.created_at,
        completedAt: row.completed_at,
        score: row.score
      };
    } finally {
      client.release();
    }
  }

  async updatePracticeTest(id: number, updatedTest: Partial<PracticeTest>): Promise<PracticeTest | undefined> {
    // Handle questions array specially if it's being updated
    if (updatedTest.questions !== undefined) {
      const client = await pool.connect();
      try {
        // Build the SET clause for the SQL update statement
        const setClauses = [];
        const params = [id]; // First parameter is the ID
        let paramIndex = 2; // Start at 2 for other parameters
        
        if (updatedTest.name !== undefined) {
          setClauses.push(`name = $${paramIndex}`);
          params.push(updatedTest.name);
          paramIndex++;
        }
        
        if (updatedTest.completedAt !== undefined) {
          setClauses.push(`completed_at = $${paramIndex}`);
          params.push(updatedTest.completedAt);
          paramIndex++;
        }
        
        if (updatedTest.score !== undefined) {
          setClauses.push(`score = $${paramIndex}`);
          params.push(updatedTest.score);
          paramIndex++;
        }
        
        // Add the questions array as JSON
        setClauses.push(`questions = $${paramIndex}::json`);
        params.push(JSON.stringify(updatedTest.questions));
        
        // Execute the update query
        const result = await client.query(
          `UPDATE practice_tests 
           SET ${setClauses.join(', ')} 
           WHERE id = $1 
           RETURNING *`,
          params
        );
        
        if (result.rows.length === 0) {
          return undefined;
        }
        
        // Convert the raw PostgreSQL row to our Drizzle type
        const row = result.rows[0];
        return {
          id: row.id,
          userId: row.user_id,
          name: row.name,
          questions: row.questions,
          createdAt: row.created_at,
          completedAt: row.completed_at,
          score: row.score
        };
      } finally {
        client.release();
      }
    } else {
      // If questions are not being updated, use Drizzle ORM
      const result = await db.update(practiceTests)
        .set(updatedTest)
        .where(eq(practiceTests.id, id))
        .returning();
      return result[0];
    }
  }

  async deletePracticeTest(id: number): Promise<boolean> {
    try {
      await db.delete(practiceTests).where(eq(practiceTests.id, id));
      return true;
    } catch (error) {
      return false;
    }
  }

  // Performance metrics
  async getPerformanceBySpecialty(userId: number): Promise<{ specialtyId: number; accuracy: number }[]> {
    // Get raw client connection
    const client = await pool.connect();
    try {
      const result = await client.query(`
        WITH specialty_reviews AS (
          SELECT 
            q.specialty_id,
            COUNT(CASE WHEN qr.knew_answer THEN 1 END) as correct_answers,
            COUNT(qr.id) as total_reviews
          FROM 
            question_reviews qr
          JOIN 
            questions q ON qr.question_id = q.id
          WHERE 
            qr.user_id = $1
            AND q.specialty_id IS NOT NULL
          GROUP BY 
            q.specialty_id
        )
        SELECT 
          specialty_id as "specialtyId",
          CASE 
            WHEN total_reviews > 0 THEN (correct_answers * 100.0 / total_reviews)
            ELSE 0 
          END as "accuracy"
        FROM 
          specialty_reviews
      `, [userId]);
      
      // Convert the query result to the expected format
      return result.rows.map(row => ({
        specialtyId: Number(row.specialtyId),
        accuracy: Number(row.accuracy)
      }));
    } finally {
      client.release();
    }
  }

  async getOverallPerformance(userId: number): Promise<number> {
    // Get raw client connection
    const client = await pool.connect();
    try {
      const result = await client.query(`
        SELECT 
          CASE 
            WHEN COUNT(id) > 0 THEN (COUNT(CASE WHEN knew_answer THEN 1 END) * 100.0 / COUNT(id))
            ELSE 0 
          END as accuracy
        FROM 
          question_reviews
        WHERE 
          user_id = $1
      `, [userId]);
      
      // Safely extract the accuracy value
      const accuracyValue = result.rows.length > 0 ? result.rows[0].accuracy : '0';
      return parseFloat(String(accuracyValue));
    } finally {
      client.release();
    }
  }

  async getStudyRecommendations(userId: number): Promise<{ specialtyId: number; priority: string }[]> {
    // Get performance data
    const performanceData = await this.getPerformanceBySpecialty(userId);
    
    // Get all specialties
    const allSpecialties = await this.getSpecialties();
    
    // Combine data to generate recommendations
    const recommendations = allSpecialties.map(specialty => {
      const performanceEntry = performanceData.find(p => p.specialtyId === specialty.id);
      const accuracy = performanceEntry?.accuracy || 0;
      
      let priority: string;
      if (accuracy < 40) {
        priority = 'high';
      } else if (accuracy < 70) {
        priority = 'medium';
      } else {
        priority = 'low';
      }
      
      return {
        specialtyId: specialty.id,
        priority
      };
    });
    
    // Sort by priority (high, medium, low)
    return recommendations.sort((a, b) => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      return priorityOrder[a.priority as keyof typeof priorityOrder] - 
             priorityOrder[b.priority as keyof typeof priorityOrder];
    });
  }

  // Answer key operations
  async getAnswerKeys(userId: number): Promise<AnswerKey[]> {
    return await db.select().from(answerKeys).where(eq(answerKeys.userId, userId));
  }

  async getAnswerKey(id: number): Promise<AnswerKey | undefined> {
    const result = await db.select().from(answerKeys).where(eq(answerKeys.id, id)).limit(1);
    return result[0];
  }

  async createAnswerKey(answerKey: InsertAnswerKey): Promise<AnswerKey> {
    const result = await db.insert(answerKeys).values(answerKey).returning();
    return result[0];
  }

  async updateAnswerKey(id: number, updatedAnswerKey: Partial<AnswerKey>): Promise<AnswerKey | undefined> {
    const result = await db.update(answerKeys)
      .set(updatedAnswerKey)
      .where(eq(answerKeys.id, id))
      .returning();
    return result[0];
  }

  async deleteAnswerKey(id: number): Promise<boolean> {
    try {
      await db.delete(answerKeys).where(eq(answerKeys.id, id));
      return true;
    } catch (error) {
      return false;
    }
  }

  async getAnswersByYear(userId: number, year: number): Promise<AnswerKey[]> {
    return await db.select()
      .from(answerKeys)
      .where(
        and(
          eq(answerKeys.userId, userId),
          eq(answerKeys.year, year)
        )
      );
  }

  // AI verified answer operations
  async getAiVerifiedAnswer(questionId: number): Promise<AiVerifiedAnswer | undefined> {
    const result = await db.select()
      .from(aiVerifiedAnswers)
      .where(eq(aiVerifiedAnswers.questionId, questionId))
      .limit(1);
    return result[0];
  }

  async createAiVerifiedAnswer(aiVerifiedAnswer: InsertAiVerifiedAnswer): Promise<AiVerifiedAnswer> {
    const result = await db.insert(aiVerifiedAnswers).values(aiVerifiedAnswer).returning();
    return result[0];
  }

  async updateAiVerifiedAnswer(id: number, updatedAiAnswer: Partial<AiVerifiedAnswer>): Promise<AiVerifiedAnswer | undefined> {
    const result = await db.update(aiVerifiedAnswers)
      .set(updatedAiAnswer)
      .where(eq(aiVerifiedAnswers.id, id))
      .returning();
    return result[0];
  }

  async getConflictingAnswers(userId: number): Promise<{
    questionId: number,
    aiRecommendedAnswer: string,
    officialAnswer: string,
    explanation: string
  }[]> {
    // Get raw client connection
    const client = await pool.connect();
    try {
      const result = await client.query(`
        SELECT 
          ava.question_id as "questionId",
          ava.ai_recommended_answer as "aiRecommendedAnswer",
          ava.official_answer_letter as "officialAnswer",
          ava.explanation_of_difference as "explanation"
        FROM 
          ai_verified_answers ava
        JOIN 
          questions q ON ava.question_id = q.id
        WHERE 
          q.user_id = $1
          AND ava.verification_status = 'conflicting'
          AND ava.official_answer_letter IS NOT NULL
        ORDER BY 
          ava.last_verified_at DESC
      `, [userId]);
      
      return result.rows;
    } finally {
      client.release();
    }
  }

  async verifyQuestionWithAi(questionId: number): Promise<AiVerifiedAnswer> {
    // This is a placeholder implementation that would be replaced with actual AI verification logic
    // In a real implementation, this would:
    // 1. Get the question details
    // 2. Call an external AI service API (like OpenAI)
    // 3. Process the AI's response to determine the recommended answer
    // 4. Compare with official answer if available
    // 5. Store the verification result
    
    // For now, we just create a pending verification record
    const existingVerification = await this.getAiVerifiedAnswer(questionId);
    
    if (existingVerification) {
      // If verification already exists, just update its status and timestamp
      const updated = await this.updateAiVerifiedAnswer(existingVerification.id, {
        verificationStatus: 'pending',
        lastVerifiedAt: new Date()
      });
      return updated!;
    } else {
      // Create a new verification record
      return await this.createAiVerifiedAnswer({
        questionId,
        verificationStatus: 'pending',
        evidenceRating: 0,
        aiModelsConsulted: []
      });
    }
  }
}