import { eq } from 'drizzle-orm';
import { db, pool } from './db';
import { 
  specialties,
  questions,
  answerKeys,
  aiVerifiedAnswers,
} from '../shared/schema';
import { log } from './vite';
import { sql } from 'drizzle-orm';

export async function runMigrations() {
  try {
    log('Running database migrations', 'drizzle');
    
    // The tables should already be created by drizzle-kit push
    // Let's just insert the default specialties
    await insertDefaultSpecialties();
    
    // Add multiple choice fields to questions table if they don't exist
    await updateQuestionsTable();
    
    // Create the new tables for answer verification system if they don't exist
    await createAnswerVerificationTables();
    
    log('Database migrations completed successfully', 'drizzle');
    return true;
  } catch (error) {
    log(`Database migration error: ${error}`, 'drizzle');
    return false;
  }
}

async function updateQuestionsTable() {
  try {
    log('Ensuring multiple choice columns exist in questions table', 'drizzle');
    
    // Use a more robust approach - try to add columns if they don't exist
    try {
      await pool.query(`
        ALTER TABLE questions 
        ADD COLUMN IF NOT EXISTS is_multiple_choice BOOLEAN DEFAULT FALSE,
        ADD COLUMN IF NOT EXISTS correct_option TEXT,
        ADD COLUMN IF NOT EXISTS user_selected_option TEXT
      `);
      log('Multiple choice columns have been verified or added', 'drizzle');
    } catch (err) {
      // If PostgreSQL version doesn't support ADD COLUMN IF NOT EXISTS, 
      // we'll handle each column individually
      log('Falling back to individual column additions', 'drizzle');
      
      // Check and add is_multiple_choice
      try {
        await pool.query(`ALTER TABLE questions ADD COLUMN is_multiple_choice BOOLEAN DEFAULT FALSE`);
        log('Added is_multiple_choice column', 'drizzle');
      } catch (e) {
        log('is_multiple_choice column already exists', 'drizzle');
      }
      
      // Check and add correct_option
      try {
        await pool.query(`ALTER TABLE questions ADD COLUMN correct_option TEXT`);
        log('Added correct_option column', 'drizzle');
      } catch (e) {
        log('correct_option column already exists', 'drizzle');
      }
      
      // Check and add user_selected_option
      try {
        await pool.query(`ALTER TABLE questions ADD COLUMN user_selected_option TEXT`);
        log('Added user_selected_option column', 'drizzle');
      } catch (e) {
        log('user_selected_option column already exists', 'drizzle');
      }
    }
    
    // Ensure imported questions have is_multiple_choice set
    await pool.query(`
      UPDATE questions 
      SET is_multiple_choice = TRUE 
      WHERE answer ~ '^[A-E][):.\\-]\\s+.+$' 
      AND is_multiple_choice = FALSE
    `);
    log('Updated existing questions to set is_multiple_choice flag as needed', 'drizzle');
    
    return true;
  } catch (error) {
    log(`Error updating questions table: ${error}`, 'drizzle');
    throw error;
  }
}

async function insertDefaultSpecialties() {
  const defaultSpecialties = [
    { name: 'Cardiology', description: 'Heart and circulatory system', color: '#ff5757' },
    { name: 'Neurology', description: 'Brain and nervous system', color: '#5e72e4' },
    { name: 'Gastroenterology', description: 'Digestive system', color: '#fb6340' },
    { name: 'Pulmonology', description: 'Respiratory system', color: '#11cdef' },
    { name: 'Endocrinology', description: 'Hormones and metabolism', color: '#2dce89' },
    { name: 'Nephrology', description: 'Kidneys and urinary system', color: '#8965e0' },
    { name: 'Hematology', description: 'Blood disorders', color: '#f5365c' },
    { name: 'Immunology', description: 'Immune system', color: '#ffd600' },
    { name: 'Dermatology', description: 'Skin conditions', color: '#fb6340' },
    { name: 'Psychiatry', description: 'Mental health', color: '#5603ad' },
    { name: 'Oncology', description: 'Cancer and tumors', color: '#8965e0' },
    { name: 'Infectious Disease', description: 'Bacterial, viral and fungal infections', color: '#f5365c' },
    { name: 'Rheumatology', description: 'Autoimmune and inflammatory disorders', color: '#ffd600' },
    { name: 'Pharmacology', description: 'Drug mechanisms and interactions', color: '#5e72e4' },
    { name: 'Pathology', description: 'Disease processes', color: '#172b4d' }
  ];
  
  try {
    for (const specialty of defaultSpecialties) {
      // Check if specialty already exists using Drizzle ORM
      const existingSpecialties = await db.select().from(specialties).where(eq(specialties.name, specialty.name));
      
      if (existingSpecialties.length === 0) {
        // Insert if it doesn't exist
        await db.insert(specialties).values({
          name: specialty.name,
          color: specialty.color
        });
        log(`Inserted specialty: ${specialty.name}`, 'drizzle');
      }
    }
  } catch (error) {
    log(`Error inserting default specialties: ${error}`, 'drizzle');
  }
}

async function createAnswerVerificationTables() {
  try {
    log('Ensuring answer verification tables exist', 'drizzle');
    
    // Create answer_keys table if it doesn't exist
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS answer_keys (
          id SERIAL PRIMARY KEY,
          user_id INTEGER NOT NULL REFERENCES users(id),
          name TEXT NOT NULL,
          pdf_url TEXT,
          image_url TEXT,
          source_type TEXT NOT NULL,
          source TEXT,
          year INTEGER,
          created_at TIMESTAMP DEFAULT NOW(),
          mapped_answers JSONB
        )
      `);
      log('answer_keys table has been verified or created', 'drizzle');
    } catch (err) {
      log(`Error ensuring answer_keys table: ${err}`, 'drizzle');
    }
    
    // Create ai_verified_answers table if it doesn't exist
    try {
      await pool.query(`
        CREATE TABLE IF NOT EXISTS ai_verified_answers (
          id SERIAL PRIMARY KEY,
          question_id INTEGER NOT NULL REFERENCES questions(id),
          ai_recommended_answer TEXT,
          official_answer_letter TEXT,
          explanation_of_difference TEXT,
          evidence_rating INTEGER NOT NULL DEFAULT 0,
          evidence_sources JSONB,
          last_verified_at TIMESTAMP DEFAULT NOW(),
          verification_status TEXT NOT NULL DEFAULT 'pending',
          ai_models_consulted JSONB
        )
      `);
      log('ai_verified_answers table has been verified or created', 'drizzle');
    } catch (err) {
      log(`Error ensuring ai_verified_answers table: ${err}`, 'drizzle');
    }
    
    return true;
  } catch (error) {
    log(`Error creating answer verification tables: ${error}`, 'drizzle');
    throw error;
  }
}