import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import { log } from './vite';

const { Pool } = pg;

// Create a PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Create the Drizzle instance
export const db = drizzle(pool, {
  logger: true
});

// Export pool for raw queries if needed
export { pool };

export async function setupDatabase() {
  try {
    log('Setting up database connection', 'drizzle');
    
    // Test the connection
    const client = await pool.connect();
    const result = await client.query('SELECT 1 as test');
    client.release();
    
    log(`Database connection successful: ${JSON.stringify(result.rows)}`, 'drizzle');
    
    return true;
  } catch (error) {
    log(`Database connection error: ${error}`, 'drizzle');
    return false;
  }
}