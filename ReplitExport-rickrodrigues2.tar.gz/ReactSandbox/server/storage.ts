import {
  User, InsertUser, users,
  Specialty, InsertSpecialty, specialties,
  Question, InsertQuestion, questions,
  Flashcard, InsertFlashcard, flashcards,
  StudySession, InsertStudySession, studySessions,
  QuestionReview, InsertQuestionReview, questionReviews,
  PracticeTest, InsertPracticeTest, practiceTests,
  AnswerKey, InsertAnswerKey, answerKeys,
  AiVerifiedAnswer, InsertAiVerifiedAnswer, aiVerifiedAnswers
} from "@shared/schema";
import { DbStorage } from './dbStorage';

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Specialty operations
  getSpecialties(): Promise<Specialty[]>;
  getSpecialty(id: number): Promise<Specialty | undefined>;
  getSpecialtyByName(name: string): Promise<Specialty | undefined>;
  createSpecialty(specialty: InsertSpecialty): Promise<Specialty>;

  // Question operations
  getQuestions(userId: number): Promise<Question[]>;
  getQuestion(id: number): Promise<Question | undefined>;
  getRecentQuestions(userId: number, limit: number): Promise<Question[]>;
  getQuestionsBySpecialty(userId: number, specialtyId: number): Promise<Question[]>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  updateQuestion(id: number, question: Partial<Question>): Promise<Question | undefined>;
  deleteQuestion(id: number): Promise<boolean>;

  // Flashcard operations
  getFlashcards(userId: number): Promise<Flashcard[]>;
  getFlashcard(id: number): Promise<Flashcard | undefined>;
  createFlashcard(flashcard: InsertFlashcard): Promise<Flashcard>;
  updateFlashcard(id: number, flashcard: Partial<Flashcard>): Promise<Flashcard | undefined>;
  deleteFlashcard(id: number): Promise<boolean>;

  // Study session operations
  getStudySessions(userId: number): Promise<StudySession[]>;
  getActiveStudySession(userId: number): Promise<StudySession | undefined>;
  createStudySession(session: InsertStudySession): Promise<StudySession>;
  updateStudySession(id: number, session: Partial<StudySession>): Promise<StudySession | undefined>;
  endStudySession(id: number, endTime: Date): Promise<StudySession | undefined>;
  getTotalStudyTimeToday(userId: number): Promise<number>; // Returns seconds

  // Question review operations
  createQuestionReview(review: InsertQuestionReview): Promise<QuestionReview>;
  getQuestionReviews(questionId: number): Promise<QuestionReview[]>;

  // Practice test operations
  getPracticeTests(userId: number): Promise<PracticeTest[]>;
  getPracticeTest(id: number): Promise<PracticeTest | undefined>;
  createPracticeTest(test: InsertPracticeTest): Promise<PracticeTest>;
  updatePracticeTest(id: number, test: Partial<PracticeTest>): Promise<PracticeTest | undefined>;
  deletePracticeTest(id: number): Promise<boolean>;

  // Performance metrics
  getPerformanceBySpecialty(userId: number): Promise<{ specialtyId: number, accuracy: number }[]>;
  getOverallPerformance(userId: number): Promise<number>; // Returns percentage
  getStudyRecommendations(userId: number): Promise<{ specialtyId: number, priority: string }[]>;

  // Answer key operations
  getAnswerKeys(userId: number): Promise<AnswerKey[]>;
  getAnswerKey(id: number): Promise<AnswerKey | undefined>;
  createAnswerKey(answerKey: InsertAnswerKey): Promise<AnswerKey>;
  updateAnswerKey(id: number, answerKey: Partial<AnswerKey>): Promise<AnswerKey | undefined>;
  deleteAnswerKey(id: number): Promise<boolean>;
  getAnswersByYear(userId: number, year: number): Promise<AnswerKey[]>;

  // AI verified answer operations
  getAiVerifiedAnswer(questionId: number): Promise<AiVerifiedAnswer | undefined>;
  createAiVerifiedAnswer(aiVerifiedAnswer: InsertAiVerifiedAnswer): Promise<AiVerifiedAnswer>;
  updateAiVerifiedAnswer(id: number, aiVerifiedAnswer: Partial<AiVerifiedAnswer>): Promise<AiVerifiedAnswer | undefined>;
  getConflictingAnswers(userId: number): Promise<{
    questionId: number,
    aiRecommendedAnswer: string,
    officialAnswer: string,
    explanation: string
  }[]>;
  verifyQuestionWithAi(questionId: number): Promise<AiVerifiedAnswer>;
}

// Use the database storage implementation instead of the in-memory storage
export const storage = new DbStorage();
