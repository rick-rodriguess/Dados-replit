interface ParsedQuestion {
  question: string;
  options: string[];
  correctOptionIndex?: number;
  hasMultipleChoiceFormat: boolean;
  questionNumber?: number;
}

/**
 * Processes the text extracted from a PDF to identify and extract individual questions
 */
export function extractQuestionsFromPdf(text: string): ParsedQuestion[] {
  // Preprocess the text to clean it up
  const cleanedText = preprocessPdfText(text);
  
  // Split the text into lines and filter out empty lines
  const lines = cleanedText.split('\n').filter(line => line.trim() !== '');
  
  // Initialize variables
  const questions: ParsedQuestion[] = [];
  let currentQuestion: string = '';
  let currentOptions: string[] = [];
  let isCollectingOptions = false;
  let hasMultipleChoiceFormat = false;
  let questionNumber = 0;
  
  // Specific patterns for PNA exam format
  const questionPatterns = [
    /^\s*(\d+)\s*[.-]\s+(.+)/,  // Pattern for "1. Question text" or "1 - Question text"
    /^\s*(\d+)\s+(.+)/,         // Pattern for "1 Question text"
    /^Questão\s+(\d+)[:.]\s*(.+)/i, // Pattern for "Questão 1: Question text"
    /^Pergunta\s+(\d+)[:.]\s*(.+)/i // Pattern for "Pergunta 1: Question text"
  ];
  
  // Option patterns
  const optionPatterns = [
    /^[(\[]?\s*([A-E])[)\].]?\s+(.+)/,  // (A) Text or A) Text or A. Text or [A] Text
    /^([A-E])\s*[-–]\s*(.+)/,           // A - Text or A – Text
    /^([A-E])\s+(.+)/                   // A Text
  ];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    let matchedQuestion = false;
    
    // Check if this line starts a new question using multiple patterns
    for (const pattern of questionPatterns) {
      const match = line.match(pattern);
      if (match) {
        // If we were already collecting a question, save it before starting a new one
        if (currentQuestion && (currentOptions.length > 0 || !isCollectingOptions)) {
          questions.push({
            question: currentQuestion.trim(),
            options: currentOptions,
            hasMultipleChoiceFormat: hasMultipleChoiceFormat && currentOptions.length > 0
          });
        }
        
        // Reset for the next question
        currentQuestion = match[2];
        currentOptions = [];
        isCollectingOptions = false;
        hasMultipleChoiceFormat = false;
        questionNumber = parseInt(match[1]);
        matchedQuestion = true;
        break;
      }
    }
    
    if (matchedQuestion) {
      continue;
    }
    
    // Check for options using multiple patterns
    let matchedOption = false;
    for (const pattern of optionPatterns) {
      const match = line.match(pattern);
      if (match && currentQuestion) {
        if (!isCollectingOptions) {
          isCollectingOptions = true;
          hasMultipleChoiceFormat = true;
        }
        
        const optionLetter = match[1];
        const optionText = match[2].trim();
        
        // Format the option consistently as "A: Option text"
        currentOptions.push(`${optionLetter}: ${optionText}`);
        matchedOption = true;
        break;
      }
    }
    
    if (matchedOption) {
      continue;
    }
    
    // Handle cases where the line is not a new question or an option
    if (currentQuestion) {
      if (!isCollectingOptions) {
        // If not collecting options yet, append to the question text
        currentQuestion += ' ' + line;
      } else if (currentOptions.length > 0) {
        // If already collecting options, append to the last option
        // Check if this might be a new option without a clear marker
        const potentialOptionMatch = line.match(/^([A-E])\s+(.+)/);
        if (potentialOptionMatch) {
          const optionLetter = potentialOptionMatch[1];
          const optionText = potentialOptionMatch[2].trim();
          currentOptions.push(`${optionLetter}: ${optionText}`);
        } else {
          // Append to the last option
          currentOptions[currentOptions.length - 1] += ' ' + line;
        }
      }
    } else if (line.match(/^\d+\s*$/) && i + 1 < lines.length) {
      // This might be just a question number on its own line
      // The actual question text is on the next line
      questionNumber = parseInt(line);
      currentQuestion = lines[i + 1];
      i++; // Skip the next line as we've already processed it
    } else {
      // If no current question and not a recognized pattern,
      // this might be the start of a question without a clear number
      currentQuestion = line;
    }
  }
  
  // Add the last question if there's any pending
  if (currentQuestion && (currentOptions.length > 0 || !isCollectingOptions)) {
    questions.push({
      question: currentQuestion.trim(),
      options: currentOptions,
      hasMultipleChoiceFormat: hasMultipleChoiceFormat && currentOptions.length > 0
    });
  }
  
  // Additional processing for special cases after initial extraction
  return postProcessQuestions(questions);
}

/**
 * Preprocesses the PDF text to clean it up and prepare it for question extraction
 */
export function preprocessPdfText(text: string): string {
  // Replace multiple spaces with a single space
  let processed = text.replace(/\s+/g, ' ');
  
  // Add line breaks before various question number formats
  processed = processed.replace(/(?<=\s|^)(\d+\.\s)/g, '\n$1'); // "1. Question"
  processed = processed.replace(/(?<=\s|^)(\d+\s-\s)/g, '\n$1'); // "1 - Question"
  processed = processed.replace(/(?<=\s|^)Questão\s+(\d+)[:.]/gi, '\nQuestão $1:'); // "Questão 1:"
  processed = processed.replace(/(?<=\s|^)Pergunta\s+(\d+)[:.]/gi, '\nPergunta $1:'); // "Pergunta 1:"
  
  // Add line breaks before answer options in various formats
  processed = processed.replace(/(?<=\s|^)([A-E][).]\s)/g, '\n$1'); // "A) Option"
  processed = processed.replace(/(?<=\s|^)([A-E])\s-\s/g, '\n$1 - '); // "A - Option"
  processed = processed.replace(/(?<=\s|^)\(([A-E])\)\s/g, '\n($1) '); // "(A) Option"
  processed = processed.replace(/(?<=\s|^)\[([A-E])\]\s/g, '\n[$1] '); // "[A] Option"
  
  // Replace weird unicode characters and fix common OCR issues
  processed = processed.replace(/–/g, '-'); // Replace en dash with hyphen
  processed = processed.replace(/—/g, '-'); // Replace em dash with hyphen
  processed = processed.replace(/•/g, ''); // Remove bullet points
  processed = processed.replace(/´/g, "'"); // Replace acute accent with apostrophe
  processed = processed.replace(/(\d),(\d)/g, '$1.$2'); // Fix European number format 1,5 -> 1.5
  
  // Remove repeated newlines to keep the text clean
  processed = processed.replace(/\n+/g, '\n');
  
  // Add extra newline between questions and options for better separation
  processed = processed.replace(/(\d+\..*?)(\n[A-E][).])/g, '$1\n$2');
  
  return processed;
}

/**
 * Attempts to guess the medical specialty based on keywords in the question
 */
export function guessSpecialty(question: string, specialties: any[]): number {
  // Map of specialty keywords (lowercase)
  const specialtyKeywords: { [key: string]: string[] } = {
    'Cardiology': ['heart', 'cardiac', 'coronary', 'arrhythmia', 'ecg', 'ekg', 'hypertension', 'blood pressure'],
    'Neurology': ['brain', 'neuro', 'seizure', 'epilepsy', 'stroke', 'headache', 'migraine'],
    'Gastroenterology': ['stomach', 'intestine', 'liver', 'hepatic', 'bowel', 'colon', 'ulcer'],
    'Pulmonology': ['lung', 'pulmonary', 'respiratory', 'asthma', 'copd', 'pneumonia'],
    'Endocrinology': ['diabetes', 'thyroid', 'hormone', 'insulin', 'cortisol', 'adrenal'],
    'Nephrology': ['kidney', 'renal', 'dialysis', 'creatinine', 'electrolyte'],
    'Hematology': ['blood', 'anemia', 'leukemia', 'lymphoma', 'platelet', 'clot'],
    'Immunology': ['immune', 'allergy', 'antibody', 'antigen', 'autoimmune'],
    'Dermatology': ['skin', 'rash', 'dermatitis', 'melanoma', 'psoriasis', 'acne'],
    'Psychiatry': ['mental', 'depression', 'anxiety', 'schizophrenia', 'bipolar', 'mood'],
    'Oncology': ['cancer', 'tumor', 'oncology', 'metastasis', 'chemotherapy', 'radiation'],
    'Infectious Disease': ['infection', 'antibiotic', 'bacteria', 'viral', 'sepsis', 'fever'],
    'Rheumatology': ['arthritis', 'rheumatoid', 'joint', 'lupus', 'autoimmune', 'inflammation'],
    'Pharmacology': ['drug', 'medication', 'pharmacology', 'dose', 'receptor', 'antagonist', 'agonist'],
    'Pathology': ['pathology', 'histology', 'biopsy', 'specimen', 'microscopic', 'stain']
  };
  
  // Convert question to lowercase for case-insensitive matching
  const lowerQuestion = question.toLowerCase();
  
  // Score each specialty based on keyword matches
  const scores: { [key: string]: number } = {};
  
  for (const [specialty, keywords] of Object.entries(specialtyKeywords)) {
    scores[specialty] = 0;
    
    for (const keyword of keywords) {
      // Use regex to find whole word matches (not part of other words)
      const regex = new RegExp(`\\b${keyword}\\b`, 'i');
      if (regex.test(lowerQuestion)) {
        scores[specialty] += 1;
      }
    }
  }
  
  // Find the specialty with the highest score
  let maxScore = 0;
  let bestMatch = '';
  
  for (const [specialty, score] of Object.entries(scores)) {
    if (score > maxScore) {
      maxScore = score;
      bestMatch = specialty;
    }
  }
  
  // If no match is found, default to "Pathology" (or any default specialty)
  if (maxScore === 0) {
    bestMatch = 'Pathology';
  }
  
  // Find the specialty ID
  const specialty = specialties.find(s => s.name === bestMatch);
  return specialty ? specialty.id : 1; // Default to ID 1 if not found
}

/**
 * Attempts to assess the difficulty of a question based on its content
 */
export function assessQuestionDifficulty(question: string, options: string[]): 'easy' | 'medium' | 'hard' {
  // Convert to lowercase for easier comparison
  const lowerQuestion = question.toLowerCase();
  
  // Factors to consider
  let length = 0;          // Question length
  let complexityScore = 0; // Based on complex medical terms and length
  
  // Complex medical terms that indicate higher difficulty
  const complexTerms = [
    'pathophysiology', 'etiology', 'differential diagnosis', 'contraindication',
    'pharmacokinetic', 'pharmacodynamic', 'pathogenesis', 'epidemiology',
    'histologically', 'translocation', 'polymorphism', 'comorbidity',
    'manifestation', 'presentation', 'criteria', 'classification'
  ];
  
  // Check for complex terms
  for (const term of complexTerms) {
    if (lowerQuestion.includes(term)) {
      complexityScore += 1;
    }
  }
  
  // Consider question length
  length = lowerQuestion.split(' ').length;
  
  // Consider number of options
  const optionCount = options.length;
  
  // Calculate final score
  let finalScore = complexityScore;
  
  // Adjust by length
  if (length > 30) finalScore += 2;
  else if (length > 20) finalScore += 1;
  
  // Adjust by option count (more options often means harder questions)
  if (optionCount >= 5) finalScore += 1;
  
  // Check for certain patterns suggesting easier questions
  const simplePatterns = [
    'most common', 'first-line', 'best initial', 'most appropriate'
  ];
  
  for (const pattern of simplePatterns) {
    if (lowerQuestion.includes(pattern)) {
      finalScore -= 1;
    }
  }
  
  // Determine difficulty
  if (finalScore >= 3) return 'hard';
  if (finalScore >= 1) return 'medium';
  return 'easy';
}

/**
 * Performs additional processing on the extracted questions to improve accuracy
 * and handle special cases specific to the PNA exam format
 */
function postProcessQuestions(questions: ParsedQuestion[]): ParsedQuestion[] {
  if (!questions || questions.length === 0) {
    return [];
  }
  
  // Process each question
  return questions.map((q, index) => {
    const processedQuestion: ParsedQuestion = { ...q };
    
    // Fix options formatting if needed
    if (processedQuestion.options && processedQuestion.options.length > 0) {
      processedQuestion.options = processedQuestion.options.map(option => {
        // Remove duplicate option letters (e.g., "A: A: Text" -> "A: Text")
        return option.replace(/^([A-E]):\s*\1:\s*/, '$1: ');
      });
    }
    
    // Set the question number if it's not already set
    if (!processedQuestion.questionNumber) {
      // Use the index + 1 as a fallback for question number
      processedQuestion.questionNumber = index + 1;
    }
    
    // Fix common issues in question text
    if (processedQuestion.question) {
      // Remove page numbers that might appear in the text (e.g., "Page 1 of 30")
      processedQuestion.question = processedQuestion.question.replace(/Page\s+\d+\s+of\s+\d+/gi, '');
      
      // Remove section headers that might appear in the text
      processedQuestion.question = processedQuestion.question.replace(/\b(SECTION|PARTE)\s+\d+\b/gi, '');
      
      // Clean up any remaining artifacts
      processedQuestion.question = processedQuestion.question.trim();
    }
    
    // Try to identify the correct answer if possible (some PDFs mark the correct answer)
    if (processedQuestion.options && processedQuestion.options.length > 0) {
      // Look for any markings that might indicate a correct answer
      // For example: "[X] A: Option text" or "A: Option text (correct)"
      for (let i = 0; i < processedQuestion.options.length; i++) {
        const option = processedQuestion.options[i];
        if (
          option.includes('[X]') || 
          option.includes('(correct)') || 
          option.includes('(correto)') ||
          option.includes('✓') ||
          option.includes('✔')
        ) {
          processedQuestion.correctOptionIndex = i;
          break;
        }
      }
    }
    
    return processedQuestion;
  }).filter(q => {
    // Filter out invalid or duplicate questions
    // 1. Must have a non-empty question text
    if (!q.question || q.question.trim() === '') {
      return false;
    }
    
    // 2. Multiple choice questions should have at least 2 options
    if (q.hasMultipleChoiceFormat && q.options.length < 2) {
      return false;
    }
    
    // 3. Question text should be reasonably long
    if (q.question.length < 5) {
      return false;
    }
    
    return true;
  });
}