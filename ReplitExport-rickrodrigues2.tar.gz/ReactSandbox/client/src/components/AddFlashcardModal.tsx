import { useState, useEffect } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Specialty, Question } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

interface AddFlashcardModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuestion?: Question | null;
}

export default function AddFlashcardModal({ isOpen, onClose, initialQuestion }: AddFlashcardModalProps) {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: isOpen && !!user
  });
  
  // Form state
  const [specialtyId, setSpecialtyId] = useState<string>(initialQuestion?.specialtyId.toString() || '');
  const [front, setFront] = useState(initialQuestion?.question || '');
  const [back, setBack] = useState(initialQuestion?.answer || '');
  
  // Reset form when modal is opened with a question
  useEffect(() => {
    if (initialQuestion) {
      setSpecialtyId(initialQuestion.specialtyId.toString());
      setFront(initialQuestion.question);
      setBack(initialQuestion.answer);
    }
  }, [initialQuestion]);
  
  // Create flashcard mutation
  const createFlashcardMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('POST', '/api/flashcards', data);
    },
    onSuccess: async () => {
      queryClient.invalidateQueries({ queryKey: ['/api/flashcards', user?.id] });
      
      toast({
        title: "Flashcard created",
        description: "Your flashcard has been successfully created."
      });
      
      resetForm();
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create flashcard. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Reset form
  const resetForm = () => {
    setSpecialtyId('');
    setFront('');
    setBack('');
  };
  
  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to create flashcards.",
        variant: "destructive"
      });
      return;
    }
    
    if (!specialtyId || !front || !back) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    createFlashcardMutation.mutate({
      userId: user.id,
      specialtyId: parseInt(specialtyId),
      front,
      back
    });
  };
  
  // Handle close
  const handleDialogClose = () => {
    if (!createFlashcardMutation.isPending) {
      resetForm();
      onClose();
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleDialogClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create Flashcard</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-2">
          <div>
            <Label htmlFor="specialty">Medical Specialty</Label>
            <Select 
              value={specialtyId} 
              onValueChange={setSpecialtyId}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a specialty" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map(specialty => (
                  <SelectItem 
                    key={specialty.id} 
                    value={specialty.id.toString()}
                  >
                    {specialty.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="front">Front (Question)</Label>
            <Textarea
              id="front"
              value={front}
              onChange={(e) => setFront(e.target.value)}
              placeholder="Enter the question or term..."
              className="h-24"
            />
          </div>
          
          <div>
            <Label htmlFor="back">Back (Answer)</Label>
            <Textarea
              id="back"
              value={back}
              onChange={(e) => setBack(e.target.value)}
              placeholder="Enter the answer or definition..."
              className="h-24"
            />
          </div>
          
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleDialogClose}
              disabled={createFlashcardMutation.isPending}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={createFlashcardMutation.isPending}
            >
              {createFlashcardMutation.isPending ? 'Creating...' : 'Create Flashcard'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}