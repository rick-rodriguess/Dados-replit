import { useUser } from '@/contexts/UserContext';
import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Question, Specialty } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function QuickReview() {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [mode, setMode] = useState<'struggling' | 'due'>('due');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: !!user
  });
  
  // Fetch questions
  const { data: questions = [], isLoading, refetch } = useQuery<Question[]>({
    queryKey: ['/api/questions', user?.id],
    enabled: !!user?.id
  });
  
  // Filter questions based on mode
  const filteredQuestions = questions.filter(q => {
    if (mode === 'struggling') {
      return !q.isKnown;
    } else {
      // Due for review - questions not reviewed in the last 3 days or never reviewed
      if (!q.lastReviewedAt) return true;
      const lastReviewed = new Date(q.lastReviewedAt);
      const threeDaysAgo = new Date();
      threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
      return lastReviewed < threeDaysAgo;
    }
  });
  
  // Get current question
  const currentQuestion = filteredQuestions[currentQuestionIndex];
  
  // Reset state when mode changes
  useEffect(() => {
    setCurrentQuestionIndex(0);
    setShowAnswer(false);
  }, [mode]);
  
  // Find specialty by ID
  const getSpecialty = (id: number) => {
    return specialties.find(s => s.id === id);
  };
  
  // Review question mutation
  const reviewMutation = useMutation({
    mutationFn: async ({ questionId, knewAnswer }: { questionId: number, knewAnswer: boolean }) => {
      return apiRequest('POST', '/api/question-reviews', {
        userId: user?.id,
        questionId,
        knewAnswer
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/questions', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/overall'] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/by-specialty'] });
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
    }
  });
  
  // Handle review
  const handleReview = async (knewAnswer: boolean) => {
    if (!currentQuestion) return;
    
    try {
      await reviewMutation.mutateAsync({ 
        questionId: currentQuestion.id, 
        knewAnswer 
      });
      
      toast({
        title: knewAnswer ? "Great job!" : "Keep practicing!",
        description: knewAnswer 
          ? "Question marked as known" 
          : "Question marked as needing more review",
      });
      
      // Move to next question
      if (currentQuestionIndex < filteredQuestions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
      } else {
        // If we're at the last question, start over
        setCurrentQuestionIndex(0);
        refetch();
      }
      
      setShowAnswer(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update question review",
        variant: "destructive"
      });
    }
  };
  
  // Get background color based on mode
  const getBackgroundColor = () => {
    return mode === 'struggling' ? 'bg-red-50 border-red-200' : 'bg-accent-50 border-accent-200';
  };
  
  // Get button color based on mode
  const getButtonColor = () => {
    return mode === 'struggling' 
      ? 'bg-white border border-red-200 text-red-700 hover:bg-red-100' 
      : 'bg-white border border-accent-200 text-accent-700 hover:bg-accent-100';
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Quick Review</h2>
        <div className="flex space-x-2">
          <button 
            onClick={() => setMode('struggling')}
            className={`px-3 py-1.5 rounded text-sm ${
              mode === 'struggling' 
                ? 'bg-red-100 text-red-700 border border-red-200' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            Struggling questions
          </button>
          <button 
            onClick={() => setMode('due')}
            className={`px-3 py-1.5 rounded text-sm ${
              mode === 'due' 
                ? 'bg-primary-50 text-primary-600 border border-primary-200' 
                : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
          >
            Due for review
          </button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="py-8 text-center text-gray-500">Loading questions...</div>
      ) : filteredQuestions.length === 0 ? (
        <div className="py-8 text-center text-gray-500">
          <p>No questions to review in this category.</p>
          <p className="mt-2 text-sm">
            {mode === 'struggling' 
              ? 'Great job! You have no struggling questions.' 
              : 'All your questions are up to date.'
            }
          </p>
        </div>
      ) : (
        <div className={`${getBackgroundColor()} rounded-lg p-4 flex flex-col sm:flex-row items-center justify-between`}>
          <div className="mb-4 sm:mb-0">
            <div className="text-center sm:text-left mb-2">
              {currentQuestion && (
                <span 
                  className="text-xs px-2 py-0.5 rounded-full"
                  style={{ 
                    backgroundColor: `${getSpecialty(currentQuestion.specialtyId)?.color}20`,
                    color: getSpecialty(currentQuestion.specialtyId)?.color 
                  }}
                >
                  {getSpecialty(currentQuestion.specialtyId)?.name}
                </span>
              )}
            </div>
            <h3 className="font-medium text-gray-800 text-xl text-center sm:text-left">
              {currentQuestion?.question}
            </h3>
            
            {showAnswer && (
              <div className="mt-3 text-gray-700 bg-white p-3 rounded-lg border border-gray-200">
                {currentQuestion?.answer}
              </div>
            )}
          </div>
          
          <div className="flex flex-col items-center space-y-2">
            <button 
              onClick={() => setShowAnswer(!showAnswer)}
              className={`${getButtonColor()} px-4 py-2 rounded-lg w-full sm:w-auto`}
            >
              {showAnswer ? 'Hide Answer' : 'Show Answer'}
            </button>
            
            {showAnswer && (
              <div className="flex space-x-2">
                <button 
                  onClick={() => handleReview(false)}
                  className="bg-red-100 text-red-600 px-3 py-1.5 rounded text-sm hover:bg-red-200 w-24"
                >
                  Struggled
                </button>
                <button 
                  onClick={() => handleReview(true)}
                  className="bg-green-100 text-green-600 px-3 py-1.5 rounded text-sm hover:bg-green-200 w-24"
                >
                  Knew it
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
