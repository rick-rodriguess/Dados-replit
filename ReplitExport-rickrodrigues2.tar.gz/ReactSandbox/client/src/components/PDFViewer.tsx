import { useState, useEffect } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, X } from 'lucide-react';

interface PDFViewerProps {
  pdfUrl: string;
  onClose: () => void;
}

export default function PDFViewer({ pdfUrl, onClose }: PDFViewerProps) {
  const { t } = useLanguage();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simula um tempo de carregamento para o PDF
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, [pdfUrl]);

  return (
    <Card className="w-full h-[80vh] flex flex-col">
      <div className="flex justify-between items-center p-2 border-b">
        <h2 className="text-lg font-medium">{t('Visualizador de PDF')}</h2>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <CardContent className="flex-1 p-0 overflow-hidden">
        {loading ? (
          <div className="w-full h-full flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">{t('Carregando PDF...')}</span>
          </div>
        ) : (
          <iframe
            src={pdfUrl}
            className="w-full h-full border-0"
            title="PDF Viewer"
          />
        )}
      </CardContent>
    </Card>
  );
}