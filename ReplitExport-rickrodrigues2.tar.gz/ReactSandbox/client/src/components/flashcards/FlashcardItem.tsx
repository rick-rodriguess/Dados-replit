import { useState } from 'react';
import { Flashcard } from '@shared/schema';
import { formatRelativeTime } from '@/utils/formatTime';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface FlashcardItemProps {
  flashcard: Flashcard;
  onMarkReviewed: () => void;
  inReviewMode: boolean;
}

export default function FlashcardItem({ 
  flashcard, 
  onMarkReviewed,
  inReviewMode 
}: FlashcardItemProps) {
  const [flipped, setFlipped] = useState(false);
  
  const handleFlip = () => {
    setFlipped(!flipped);
  };
  
  return (
    <div className={`h-full ${inReviewMode ? 'min-h-[400px]' : ''}`}>
      <Card 
        className={`h-full flex flex-col cursor-pointer transform transition-all duration-500 ${
          flipped ? 'bg-gray-50' : ''
        }`}
        onClick={handleFlip}
      >
        <CardContent className="flex flex-col justify-between h-full p-5">
          <div>
            <div className="flex justify-between items-start mb-2">
              <div className="text-xs text-gray-500">
                {flashcard.lastReviewedAt 
                  ? `Last reviewed: ${formatRelativeTime(new Date(flashcard.lastReviewedAt))}` 
                  : 'Never reviewed'
                }
              </div>
              <div className="text-xs bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full">
                Reviewed {flashcard.reviewCount} times
              </div>
            </div>
            
            <div className="mt-2 text-center">
              {!flipped ? (
                <div className="font-medium text-lg text-gray-800 min-h-[100px] flex items-center justify-center">
                  {flashcard.front}
                </div>
              ) : (
                <div className="text-gray-700 min-h-[100px] flex items-center justify-center">
                  {flashcard.back}
                </div>
              )}
            </div>
          </div>
          
          <div className="mt-4 text-center">
            <div className="text-xs text-gray-500 mb-2">
              {flipped ? 'Back' : 'Front'} - Click to flip
            </div>
            
            {inReviewMode && flipped && (
              <Button 
                className="mt-2 w-full"
                onClick={(e) => {
                  e.stopPropagation();
                  onMarkReviewed();
                  setFlipped(false);
                }}
              >
                Mark as Reviewed
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
