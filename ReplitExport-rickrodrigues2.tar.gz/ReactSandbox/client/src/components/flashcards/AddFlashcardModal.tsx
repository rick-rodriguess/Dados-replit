import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Question } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface AddFlashcardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddFlashcardModal({ isOpen, onClose }: AddFlashcardModalProps) {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('manual');
  
  // Manual creation state
  const [front, setFront] = useState('');
  const [back, setBack] = useState('');
  
  // From question state
  const [selectedQuestionId, setSelectedQuestionId] = useState<string>('');
  
  // Fetch user's questions
  const { data: questions = [], isLoading } = useQuery<Question[]>({
    queryKey: ['/api/questions', user?.id],
    enabled: isOpen && !!user?.id && activeTab === 'question'
  });
  
  // Create flashcard mutation
  const createFlashcardMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('POST', '/api/flashcards', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/flashcards', user?.id] });
      toast({
        title: "Flashcard created",
        description: "Your flashcard has been successfully created."
      });
      resetForm();
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create flashcard. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Reset form
  const resetForm = () => {
    setFront('');
    setBack('');
    setSelectedQuestionId('');
    setActiveTab('manual');
  };
  
  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to create a flashcard.",
        variant: "destructive"
      });
      return;
    }
    
    if (activeTab === 'manual') {
      if (!front || !back) {
        toast({
          title: "Missing fields",
          description: "Please fill in both front and back of the flashcard.",
          variant: "destructive"
        });
        return;
      }
      
      createFlashcardMutation.mutate({
        userId: user.id,
        front,
        back,
        questionId: null
      });
    } else {
      if (!selectedQuestionId) {
        toast({
          title: "No question selected",
          description: "Please select a question to create a flashcard from.",
          variant: "destructive"
        });
        return;
      }
      
      const question = questions.find(q => q.id.toString() === selectedQuestionId);
      if (!question) return;
      
      createFlashcardMutation.mutate({
        userId: user.id,
        front: question.question,
        back: question.answer,
        questionId: question.id
      });
    }
  };
  
  // Handle close
  const handleDialogClose = () => {
    if (!createFlashcardMutation.isPending) {
      onClose();
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleDialogClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create New Flashcard</DialogTitle>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="manual">Manual Entry</TabsTrigger>
            <TabsTrigger value="question">From Question</TabsTrigger>
          </TabsList>
          
          <form onSubmit={handleSubmit} className="py-4">
            <TabsContent value="manual" className="space-y-4">
              <div>
                <Label htmlFor="front">Front (Question)</Label>
                <Textarea
                  id="front"
                  value={front}
                  onChange={(e) => setFront(e.target.value)}
                  placeholder="Enter the question or term..."
                  className="h-24"
                />
              </div>
              
              <div>
                <Label htmlFor="back">Back (Answer)</Label>
                <Textarea
                  id="back"
                  value={back}
                  onChange={(e) => setBack(e.target.value)}
                  placeholder="Enter the answer or definition..."
                  className="h-24"
                />
              </div>
            </TabsContent>
            
            <TabsContent value="question" className="space-y-4">
              <div>
                <Label htmlFor="question">Select Question</Label>
                {isLoading ? (
                  <div className="h-12 flex items-center text-gray-500">Loading questions...</div>
                ) : questions.length === 0 ? (
                  <div className="h-12 flex items-center text-gray-500">No questions available</div>
                ) : (
                  <Select 
                    value={selectedQuestionId} 
                    onValueChange={setSelectedQuestionId}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a question" />
                    </SelectTrigger>
                    <SelectContent>
                      {questions.map(question => (
                        <SelectItem 
                          key={question.id} 
                          value={question.id.toString()}
                        >
                          {question.question.substring(0, 50)}
                          {question.question.length > 50 ? '...' : ''}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
              
              {selectedQuestionId && (
                <div className="border rounded-md p-3 bg-gray-50">
                  <div className="text-sm font-medium">Preview:</div>
                  <div className="mt-2">
                    <div className="text-sm font-medium">Front:</div>
                    <div className="text-sm text-gray-600">
                      {questions.find(q => q.id.toString() === selectedQuestionId)?.question}
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="text-sm font-medium">Back:</div>
                    <div className="text-sm text-gray-600">
                      {questions.find(q => q.id.toString() === selectedQuestionId)?.answer}
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>
            
            <DialogFooter className="mt-4">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={createFlashcardMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={createFlashcardMutation.isPending}
              >
                {createFlashcardMutation.isPending ? 'Creating...' : 'Create Flashcard'}
              </Button>
            </DialogFooter>
          </form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
