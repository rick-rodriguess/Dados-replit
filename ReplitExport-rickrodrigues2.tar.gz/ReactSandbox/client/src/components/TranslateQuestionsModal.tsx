import React, { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Question } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface TranslateQuestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type TranslationStatus = 'idle' | 'translating' | 'success' | 'error';

export default function TranslateQuestionsModal({ isOpen, onClose }: TranslateQuestionsModalProps) {
  const { user } = useUser();
  const { t } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<TranslationStatus>('idle');
  const [progress, setProgress] = useState(0);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState('');

  // Função para traduzir o conteúdo das questões para português
  const translateQuestions = async () => {
    if (!user) return;
    
    try {
      setStatus('translating');
      
      // Obter todas as questões do usuário
      const questions = await apiRequest<Question[]>('/api/questions');
      
      if (!questions || questions.length === 0) {
        toast({
          title: t('msg.noQuestions'),
          description: t('msg.noQuestionsToTranslate'),
          variant: 'destructive',
        });
        setStatus('idle');
        return;
      }
      
      setTotal(questions.length);
      
      // Filtrar apenas questões em inglês que precisam ser traduzidas
      // Usamos uma heurística simples para detectar idioma (presença de palavras em inglês)
      const englishQuestions = questions.filter(q => {
        const englishWords = ['the', 'is', 'are', 'what', 'which', 'where', 'when', 'why', 'how'];
        const containsEnglishWords = englishWords.some(word => 
          q.question.toLowerCase().includes(' ' + word + ' ') || 
          q.question.toLowerCase().startsWith(word + ' ')
        );
        return containsEnglishWords;
      });
      
      if (englishQuestions.length === 0) {
        toast({
          title: t('msg.noEnglishQuestions'),
          description: t('msg.allQuestionsAlreadyInPortuguese'),
          variant: 'default',
        });
        setStatus('success');
        return;
      }
      
      setTotal(englishQuestions.length);
      
      // Traduções manuais para palavras e frases comuns em medicina
      const translationMap: Record<string, string> = {
        'What is': 'O que é',
        'Which of the following': 'Qual das seguintes',
        'How does': 'Como',
        'When should': 'Quando deve',
        'The most common': 'O mais comum',
        'The primary': 'O principal',
        'The best': 'O melhor',
        'treatment': 'tratamento',
        'symptoms': 'sintomas',
        'diagnosis': 'diagnóstico',
        'patient': 'paciente',
        'disease': 'doença',
        'heart': 'coração',
        'lungs': 'pulmões',
        'liver': 'fígado',
        'kidney': 'rim',
        'blood': 'sangue',
        'brain': 'cérebro',
        'muscle': 'músculo',
        'bone': 'osso',
        'infection': 'infecção',
        'inflammation': 'inflamação',
        'medication': 'medicação',
        'surgery': 'cirurgia',
        'therapy': 'terapia',
        'condition': 'condição',
        'syndrome': 'síndrome',
        'test': 'teste',
        'examination': 'exame',
        'assessment': 'avaliação',
        'management': 'manejo',
        'prognosis': 'prognóstico',
        'complication': 'complicação',
        'risk factor': 'fator de risco',
        'symptom': 'sintoma',
        'sign': 'sinal',
        'indicated': 'indicado',
        'contraindicated': 'contraindicado',
        'The correct answer is': 'A resposta correta é',
      };
      
      // Função simples para substituir palavras em inglês por traduções em português
      const translateText = (text: string): string => {
        let translatedText = text;
        
        // Substituir palavras e frases comuns
        Object.entries(translationMap).forEach(([english, portuguese]) => {
          const regex = new RegExp('\\b' + english + '\\b', 'gi');
          translatedText = translatedText.replace(regex, portuguese);
        });
        
        return translatedText;
      };
      
      // Processar cada questão e atualizá-la
      for (let i = 0; i < englishQuestions.length; i++) {
        const question = englishQuestions[i];
        
        // Traduzir o conteúdo
        const translatedQuestion = translateText(question.question);
        const translatedAnswer = translateText(question.answer);
        
        // Atualizar a questão no banco de dados
        await apiRequest(`/api/questions/${question.id}`, {
          method: 'PUT',
          body: JSON.stringify({
            question: translatedQuestion,
            answer: translatedAnswer,
            // Preservar outros campos
            specialtyId: question.specialtyId,
            difficulty: question.difficulty,
            reference: question.reference,
            isMultipleChoice: question.isMultipleChoice,
            correctOption: question.correctOption,
          }),
        });
        
        // Atualizar o progresso
        setProgress(i + 1);
      }
      
      // Atualizar a cache do React Query
      queryClient.invalidateQueries({ queryKey: ['/api/questions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/questions/recent'] });
      
      setStatus('success');
      toast({
        title: t('msg.translationComplete'),
        description: t('msg.questionsTranslated').replace('{{count}}', englishQuestions.length.toString()),
        variant: 'default',
      });
    } catch (err) {
      console.error('Translation error:', err);
      setStatus('error');
      setError(err instanceof Error ? err.message : String(err));
      toast({
        title: t('msg.translationError'),
        description: t('msg.errorOccurred'),
        variant: 'destructive',
      });
    }
  };
  
  const handleClose = () => {
    if (status !== 'translating') {
      setStatus('idle');
      setProgress(0);
      setTotal(0);
      setError('');
      onClose();
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{t('title.translateQuestions')}</DialogTitle>
          <DialogDescription>
            {t('msg.translateQuestionsDescription')}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          {status === 'idle' && (
            <p className="text-sm text-gray-500">
              {t('msg.translateQuestionsWarning')}
            </p>
          )}
          
          {status === 'translating' && (
            <div className="space-y-4">
              <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary-500 transition-all duration-300"
                  style={{ width: `${total > 0 ? (progress / total) * 100 : 0}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-500 text-center">
                {t('msg.translatingQuestions')} ({progress}/{total})
              </p>
            </div>
          )}
          
          {status === 'success' && (
            <div className="flex items-center space-x-2 text-green-600">
              <CheckCircle className="h-5 w-5" />
              <p>{t('msg.translationComplete')}</p>
            </div>
          )}
          
          {status === 'error' && (
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-red-600">
                <AlertCircle className="h-5 w-5" />
                <p>{t('msg.translationError')}</p>
              </div>
              {error && (
                <p className="text-sm text-red-500 bg-red-50 p-2 rounded">
                  {error}
                </p>
              )}
            </div>
          )}
        </div>
        
        <DialogFooter className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={handleClose}
            disabled={status === 'translating'}
          >
            {status === 'success' ? t('button.done') : t('button.cancel')}
          </Button>
          
          {status === 'idle' && (
            <Button 
              type="button" 
              onClick={translateQuestions}
            >
              {t('button.startTranslation')}
            </Button>
          )}
          
          {status === 'error' && (
            <Button 
              type="button" 
              onClick={translateQuestions}
            >
              {t('button.retry')}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}