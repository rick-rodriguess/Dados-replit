import { PracticeTest } from '@shared/schema';
import { formatRelativeTime } from '@/utils/formatTime';
import { Button } from '@/components/ui/button';

interface TestItemProps {
  test: PracticeTest;
  onStartTest: () => void;
}

export default function TestItem({ test, onStartTest }: TestItemProps) {
  // Format creation date
  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:border-primary-200 hover:bg-primary-50 transition-colors">
      <div className="flex flex-col md:flex-row justify-between">
        <div>
          <h3 className="text-lg font-medium text-gray-800">{test.name}</h3>
          <div className="flex flex-wrap items-center mt-2 text-sm text-gray-500 space-x-4">
            <div className="flex items-center">
              <i className="ri-question-line mr-1"></i>
              <span>{test.questions?.length || 0} questions</span>
            </div>
            <div className="flex items-center">
              <i className="ri-calendar-line mr-1"></i>
              <span>Created: {test.createdAt ? formatDate(test.createdAt) : 'Unknown'}</span>
            </div>
            {test.completedAt && (
              <div className="flex items-center">
                <i className="ri-check-double-line mr-1"></i>
                <span>Completed: {formatDate(test.completedAt)}</span>
              </div>
            )}
            {test.score !== null && test.score !== undefined && (
              <div className="flex items-center">
                <i className="ri-medal-line mr-1"></i>
                <span>Score: {test.score}%</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center">
          <Button onClick={onStartTest}>
            {test.completedAt ? 'Retry Test' : 'Start Test'}
          </Button>
        </div>
      </div>
    </div>
  );
}
