import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Question, Specialty } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';

interface CreateTestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateTestModal({ isOpen, onClose }: CreateTestModalProps) {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Form state
  const [testName, setTestName] = useState('');
  const [selectedSpecialtyId, setSelectedSpecialtyId] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [selectedQuestions, setSelectedQuestions] = useState<number[]>([]);
  const [questionCount, setQuestionCount] = useState<number>(10);
  const [randomSelection, setRandomSelection] = useState<boolean>(true);
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: isOpen && !!user
  });
  
  // Fetch questions
  const { data: questions = [], isLoading } = useQuery<Question[]>({
    queryKey: ['/api/questions', user?.id],
    enabled: isOpen && !!user?.id
  });
  
  // Create test mutation
  const createTestMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('POST', '/api/practice-tests', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/practice-tests', user?.id] });
      toast({
        title: "Practice test created",
        description: "Your practice test has been successfully created."
      });
      resetForm();
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create practice test. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Reset form
  const resetForm = () => {
    setTestName('');
    setSelectedSpecialtyId('all');
    setSelectedDifficulty('all');
    setSelectedQuestions([]);
    setQuestionCount(10);
    setRandomSelection(true);
  };
  
  // Filter questions based on selected specialty and difficulty
  const filteredQuestions = questions.filter(question => {
    const matchesSpecialty = 
      selectedSpecialtyId === 'all' || 
      question.specialtyId.toString() === selectedSpecialtyId;
    
    const matchesDifficulty = 
      selectedDifficulty === 'all' || 
      question.difficulty === selectedDifficulty;
    
    return matchesSpecialty && matchesDifficulty;
  });
  
  // Toggle question selection
  const toggleQuestionSelection = (questionId: number) => {
    if (selectedQuestions.includes(questionId)) {
      setSelectedQuestions(selectedQuestions.filter(id => id !== questionId));
    } else {
      setSelectedQuestions([...selectedQuestions, questionId]);
    }
  };
  
  // Get random questions
  const getRandomQuestions = () => {
    if (filteredQuestions.length <= questionCount) {
      return filteredQuestions.map(q => q.id);
    }
    
    const shuffled = [...filteredQuestions].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, questionCount).map(q => q.id);
  };
  
  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to create a practice test.",
        variant: "destructive"
      });
      return;
    }
    
    if (!testName) {
      toast({
        title: "Missing test name",
        description: "Please provide a name for your practice test.",
        variant: "destructive"
      });
      return;
    }
    
    let testQuestions: number[];
    
    if (randomSelection) {
      testQuestions = getRandomQuestions();
    } else {
      testQuestions = selectedQuestions;
    }
    
    if (testQuestions.length === 0) {
      toast({
        title: "No questions selected",
        description: "Please select at least one question for your test.",
        variant: "destructive"
      });
      return;
    }
    
    createTestMutation.mutate({
      userId: user.id,
      name: testName,
      questions: testQuestions
    });
  };
  
  // Find specialty by ID
  const getSpecialty = (id: number) => {
    return specialties.find(s => s.id === id);
  };
  
  // Get difficulty color class
  const getDifficultyClass = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'bg-green-100 text-green-700';
      case 'medium':
        return 'bg-orange-100 text-orange-700';
      case 'hard':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Create Practice Test</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-2">
          <div>
            <Label htmlFor="testName">Test Name</Label>
            <Input
              id="testName"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
              placeholder="E.g., Cardiology Review"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="specialty">Filter by Specialty</Label>
              <Select 
                value={selectedSpecialtyId} 
                onValueChange={setSelectedSpecialtyId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Specialties" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specialties</SelectItem>
                  {specialties.map(specialty => (
                    <SelectItem 
                      key={specialty.id} 
                      value={specialty.id.toString()}
                    >
                      {specialty.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="difficulty">Filter by Difficulty</Label>
              <Select 
                value={selectedDifficulty} 
                onValueChange={setSelectedDifficulty}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Difficulties" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Difficulties</SelectItem>
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="random"
              checked={randomSelection}
              onCheckedChange={(checked) => setRandomSelection(checked === true)}
            />
            <Label htmlFor="random" className="font-normal">
              Random question selection
            </Label>
          </div>
          
          {randomSelection && (
            <div>
              <Label htmlFor="questionCount">Number of Questions</Label>
              <div className="flex items-center space-x-2">
                <Input
                  id="questionCount"
                  type="number"
                  min={1}
                  max={filteredQuestions.length}
                  value={questionCount}
                  onChange={(e) => setQuestionCount(parseInt(e.target.value) || 10)}
                  className="w-24"
                />
                <span className="text-sm text-gray-500">
                  of {filteredQuestions.length} available
                </span>
              </div>
            </div>
          )}
          
          {!randomSelection && (
            <div>
              <Label>Select Questions</Label>
              <div className="mt-2 max-h-60 overflow-y-auto border rounded-md p-2">
                {isLoading ? (
                  <div className="text-center py-4 text-gray-500">Loading questions...</div>
                ) : filteredQuestions.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">No questions match the filters</div>
                ) : (
                  <div className="space-y-2">
                    {filteredQuestions.map(question => {
                      const specialty = getSpecialty(question.specialtyId);
                      
                      return (
                        <div 
                          key={question.id}
                          className="flex items-start space-x-2 p-2 border rounded-md hover:bg-gray-50"
                        >
                          <Checkbox
                            id={`question-${question.id}`}
                            checked={selectedQuestions.includes(question.id)}
                            onCheckedChange={() => toggleQuestionSelection(question.id)}
                          />
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              {specialty && (
                                <span 
                                  className="text-xs px-2 py-0.5 rounded-full"
                                  style={{ 
                                    backgroundColor: `${specialty.color}20`,
                                    color: specialty.color 
                                  }}
                                >
                                  {specialty.name}
                                </span>
                              )}
                              <span className={`text-xs px-2 py-0.5 rounded-full ${getDifficultyClass(question.difficulty)}`}>
                                {question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1)}
                              </span>
                            </div>
                            <Label 
                              htmlFor={`question-${question.id}`}
                              className="text-sm font-normal cursor-pointer"
                            >
                              {question.question}
                            </Label>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              <div className="mt-2 text-sm text-gray-500">
                Selected: {selectedQuestions.length} questions
              </div>
            </div>
          )}
          
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={createTestMutation.isPending}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={createTestMutation.isPending}
            >
              {createTestMutation.isPending ? 'Creating...' : 'Create Test'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
