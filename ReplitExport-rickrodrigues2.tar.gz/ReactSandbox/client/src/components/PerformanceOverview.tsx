import { useUser } from '@/contexts/UserContext';
import { useQuery } from '@tanstack/react-query';
import { Specialty } from '@shared/schema';

interface PerformanceData {
  specialtyId: number;
  accuracy: number;
}

export default function PerformanceOverview() {
  const { user } = useUser();
  
  // Fetch overall performance
  const { data: overallPerformance, isLoading: isLoadingOverall } = useQuery<{ accuracy: number }>({
    queryKey: ['/api/performance/overall', user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/performance/overall?userId=${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch overall performance');
      return res.json();
    },
    enabled: !!user?.id
  });
  
  // Fetch performance by specialty
  const { data: specialtyPerformance = [], isLoading: isLoadingSpecialty } = useQuery<PerformanceData[]>({
    queryKey: ['/api/performance/by-specialty', user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/performance/by-specialty?userId=${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch specialty performance');
      return res.json();
    },
    enabled: !!user?.id
  });
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: !!user
  });
  
  // Get specialty name by ID
  const getSpecialtyName = (id: number) => {
    const specialty = specialties.find(s => s.id === id);
    return specialty?.name || 'Unknown';
  };
  
  // Get specialty color by ID
  const getSpecialtyColor = (id: number) => {
    const specialty = specialties.find(s => s.id === id);
    return specialty?.color || '#2563EB';
  };
  
  const isLoading = isLoadingOverall || isLoadingSpecialty;
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <h2 className="text-lg font-semibold mb-4">Performance Overview</h2>
      
      <div className="chart-container mb-4">
        {isLoading ? (
          <div className="bg-gray-50 border border-gray-200 rounded-lg h-full flex items-center justify-center">
            <div className="text-gray-500">Loading performance data...</div>
          </div>
        ) : specialtyPerformance.length === 0 ? (
          <div className="bg-gray-50 border border-gray-200 rounded-lg h-full flex items-center justify-center">
            <div className="text-center">
              <div className="text-gray-500">No performance data yet</div>
              <div className="text-sm text-gray-400 mt-1">Add questions and review them</div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-50 border border-gray-200 rounded-lg h-full flex items-center justify-center">
            <div className="text-center">
              <div className="text-4xl font-medium text-primary-500">{overallPerformance?.accuracy || 0}%</div>
              <div className="text-gray-500 mt-1">Overall accuracy</div>
            </div>
          </div>
        )}
      </div>
      
      <div className="space-y-4">
        {specialtyPerformance.length === 0 ? (
          <div className="text-center text-gray-500 py-4">
            Start adding questions to see your performance by specialty
          </div>
        ) : (
          specialtyPerformance.map((performance) => (
            <div key={performance.specialtyId}>
              <div className="flex justify-between items-center mb-1">
                <span className="font-medium text-sm">{getSpecialtyName(performance.specialtyId)}</span>
                <span className="text-sm text-gray-500">{performance.accuracy}%</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full" 
                  style={{ 
                    width: `${performance.accuracy}%`,
                    backgroundColor: getSpecialtyColor(performance.specialtyId)
                  }}
                ></div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
