import { useUser } from '@/contexts/UserContext';
import { useQuery } from '@tanstack/react-query';
import { Specialty } from '@shared/schema';

interface Recommendation {
  specialtyId: number;
  priority: string;
  specialty: Specialty | null;
}

export default function StudyRecommendations() {
  const { user } = useUser();
  
  // Fetch recommendations
  const { data: recommendations = [], isLoading } = useQuery<Recommendation[]>({
    queryKey: ['/api/recommendations', user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/recommendations?userId=${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch recommendations');
      return res.json();
    },
    enabled: !!user?.id
  });
  
  // Get color and icon based on priority
  const getPriorityStyles = (priority: string) => {
    switch (priority) {
      case 'high':
        return {
          container: 'bg-red-50 border-red-200',
          text: 'text-red-800',
          description: 'text-red-700',
          icon: 'bg-red-500',
          iconClass: 'ri-arrow-up-line'
        };
      case 'medium':
        return {
          container: 'bg-orange-50 border-orange-200',
          text: 'text-orange-800',
          description: 'text-orange-700',
          icon: 'bg-orange-500',
          iconClass: 'ri-arrow-right-line'
        };
      case 'low':
        return {
          container: 'bg-green-50 border-green-200',
          text: 'text-green-800',
          description: 'text-green-700',
          icon: 'bg-green-500',
          iconClass: 'ri-check-line'
        };
      default:
        return {
          container: 'bg-gray-50 border-gray-200',
          text: 'text-gray-800',
          description: 'text-gray-700',
          icon: 'bg-gray-500',
          iconClass: 'ri-information-line'
        };
    }
  };
  
  // Priority labels
  const priorityLabels = {
    high: 'High Priority',
    medium: 'Medium Priority',
    low: 'Well Studied'
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <h2 className="text-lg font-semibold mb-4">Study Recommendations</h2>
      
      {isLoading ? (
        <div className="py-4 text-center text-gray-500">Loading recommendations...</div>
      ) : recommendations.length === 0 ? (
        <div className="py-4 text-center text-gray-500">
          <p>No recommendations available yet.</p>
          <p className="mt-2 text-sm">Add and review questions to get personalized recommendations.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {recommendations.map((recommendation) => {
            const styles = getPriorityStyles(recommendation.priority);
            const label = priorityLabels[recommendation.priority as keyof typeof priorityLabels] || 'Review';
            
            return (
              <div 
                key={recommendation.specialtyId} 
                className={`${styles.container} rounded-lg p-3`}
              >
                <div className="flex items-center space-x-2">
                  <div className={`${styles.icon} p-1.5 rounded-full text-white`}>
                    <i className={styles.iconClass}></i>
                  </div>
                  <div className={`font-medium ${styles.text}`}>{label}</div>
                </div>
                <div className={`pl-7 mt-1 text-sm ${styles.description}`}>
                  {recommendation.priority === 'low' ? (
                    <>Keep up the good work with </>
                  ) : (
                    <>Review </>
                  )}
                  {recommendation.specialty?.name || `Specialty #${recommendation.specialtyId}`}
                  {recommendation.priority === 'high' && (
                    <> - Focus on this first</>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
