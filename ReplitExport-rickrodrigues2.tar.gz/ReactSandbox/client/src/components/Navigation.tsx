import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useLanguage } from '@/contexts/LanguageContext';
import LanguageSelector from './LanguageSelector';

export default function Navigation() {
  const [location] = useLocation();
  const { t } = useLanguage();
  
  const tabs = [
    { key: 'nav.dashboard', path: '/' },
    { key: 'nav.questions', path: '/questions' },
    { key: 'nav.flashcards', path: '/flashcards' },
    { key: 'nav.practice', path: '/practice-tests' },
    { key: 'nav.analytics', path: '/analytics' },
    { key: 'nav.answerKeys', path: '/answer-keys' },
    { key: 'nav.verifyAnswers', path: '/answer-verification' }
  ];
  
  return (
    <div className="mb-6 border-b border-gray-200">
      <div className="flex justify-between items-center pr-4">
        <nav className="flex space-x-1 overflow-x-auto">
          {tabs.map((tab) => {
            const isActive = 
              (tab.path === '/' && location === '/') || 
              (tab.path !== '/' && location.startsWith(tab.path));
              
            return (
              <Link 
                key={tab.path} 
                href={tab.path}
                className={`px-4 py-3 font-medium whitespace-nowrap ${
                  isActive 
                    ? 'text-primary-600 border-b-2 border-primary-500' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {t(tab.key)}
              </Link>
            );
          })}
        </nav>
        <LanguageSelector />
      </div>
    </div>
  );
}
