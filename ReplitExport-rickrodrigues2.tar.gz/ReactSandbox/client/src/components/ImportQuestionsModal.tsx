import { useState, useRef } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Specialty } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface ImportQuestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface QuestionImport {
  question: string;
  answer: string;
  specialty: string;
  reference?: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export default function ImportQuestionsModal({ isOpen, onClose }: ImportQuestionsModalProps) {
  const { user } = useUser();
  const { toast } = useToast();
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Local state to store questions for import
  const [questions, setQuestions] = useState<QuestionImport[]>([]);
  const [questionText, setQuestionText] = useState('');
  const [batchTitle, setBatchTitle] = useState('');
  const [defaultSpecialty, setDefaultSpecialty] = useState<string>('');
  const [defaultDifficulty, setDefaultDifficulty] = useState<string>('medium');
  const [parsingStatus, setParsingStatus] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState('');
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: isOpen && !!user
  });
  
  // Create question mutation
  const createQuestionsMutation = useMutation({
    mutationFn: async (questionsData: any[]) => {
      // Create questions one by one
      const results = [];
      for (const questionData of questionsData) {
        const result = await apiRequest('POST', '/api/questions', questionData);
        results.push(result);
      }
      return results;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/questions', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/questions/recent', user?.id] });
      
      toast({
        title: "Questões importadas",
        description: `${questions.length} questões importadas com sucesso de ${batchTitle}`
      });
      
      resetForm();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: "Falha ao importar questões. Por favor, tente novamente.",
        variant: "destructive"
      });
      console.error('Import error:', error);
    }
  });
  
  // Reset form
  const resetForm = () => {
    setQuestions([]);
    setQuestionText('');
    setBatchTitle('');
    setDefaultSpecialty('');
    setDefaultDifficulty('medium');
    setParsingStatus('');
    setUploadedFileName('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  // Handle PDF file upload
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    // Check if the file is a PDF
    if (file.type !== 'application/pdf') {
      toast({
        title: t('msg.invalidFileType'),
        description: t('msg.invalidFileType'),
        variant: "destructive"
      });
      return;
    }
    
    setUploadedFileName(file.name);
    
    if (!batchTitle) {
      // Set batch title based on file name if not already set
      setBatchTitle(file.name.replace('.pdf', ''));
    }
    
    try {
      setIsParsing(true);
      setParsingStatus('Processando arquivo PDF...');
      
      // Create FormData for file upload
      const formData = new FormData();
      formData.append('pdfFile', file);
      
      // Call the server-side PDF parsing endpoint
      const response = await fetch('/api/parse-pdf', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error(`Server returned ${response.status}: ${response.statusText}`);
      }
      
      const result = await response.json();
      const parsedQuestions = result.questions;
      
      if (!parsedQuestions || parsedQuestions.length === 0) {
        toast({
          title: "Nenhuma questão encontrada",
          description: "Não foi possível extrair questões do PDF. Tente ajustar o documento ou use a opção de importação manual.",
          variant: "destructive"
        });
        setParsingStatus('Não foi possível extrair questões do PDF.');
        setIsParsing(false);
        return;
      }
      
      // Convert to QuestionImport format
      const importQuestions: QuestionImport[] = parsedQuestions.map((pq: any) => {
        // Use the provided answer if available, otherwise build from options
        let answerText = pq.answer || '';
        if (!answerText && pq.options && pq.options.length > 0) {
          answerText = pq.options.join('\n');
        }
        
        if (!answerText) {
          answerText = "Resposta não identificada no arquivo PDF.";
        }
        
        // Use the provided specialty if available, otherwise use default
        const specialtyId = pq.specialtyId 
          ? pq.specialtyId.toString() 
          : (defaultSpecialty || '1'); // Default to the first specialty
        
        // Use the provided difficulty if available, otherwise use default
        const difficulty = pq.difficulty || defaultDifficulty;
        
        return {
          question: pq.question,
          answer: answerText,
          specialty: specialtyId,
          difficulty: difficulty as 'easy' | 'medium' | 'hard',
          reference: `PNA Exam - ${batchTitle || file.name}`
        };
      });
      
      setQuestions(importQuestions);
      setParsingStatus(`${importQuestions.length} questões extraídas com sucesso do PDF.`);
    } catch (error) {
      console.error('PDF processing error:', error);
      toast({
        title: "Erro de Processamento do PDF",
        description: "Falha ao processar o arquivo PDF. O arquivo pode estar corrompido ou em um formato não suportado.",
        variant: "destructive"
      });
      setParsingStatus('Erro ao processar o arquivo PDF.');
    } finally {
      setIsParsing(false);
    }
  };

  // Parse exam questions from text
  const parseQuestions = () => {
    try {
      if (!questionText.trim()) {
        toast({
          title: "Erro",
          description: "Por favor, cole o texto das questões do exame primeiro.",
          variant: "destructive"
        });
        return;
      }

      // Split the text by question number patterns (like "1.", "2.", etc.)
      const questionBlocks = questionText.split(/\n\s*\d+\.\s+/).filter(block => block.trim());
      
      // If no question blocks found, try a different split pattern
      let parsedQuestions: QuestionImport[] = [];

      if (questionBlocks.length <= 1) {
        // Simple parsing: Try to find question and answer pairs
        const lines = questionText.split('\n').filter(line => line.trim());
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i].trim();
          
          // Check if line has question number pattern at the beginning
          if (/^\d+\.\s+/.test(line)) {
            const questionText = line.replace(/^\d+\.\s+/, '');
            
            // Look ahead for multiple choice options and the answer
            let answerText = '';
            let j = i + 1;
            
            // Collect options and look for markings that indicate the correct answer
            const options: string[] = [];
            let correctOption = '';
            
            while (j < lines.length && !(/^\d+\.\s+/.test(lines[j]))) {
              const optionLine = lines[j].trim();
              
              // Check for marked correct answer (X, ✓, →, etc.)
              if (/^\s*\([A-E]\)\s+.*/.test(optionLine)) {
                const option = optionLine.match(/^\s*\(([A-E])\)\s+(.*)/);
                if (option) {
                  options.push(`${option[1]}: ${option[2]}`);
                  
                  // Check if this line has a marker for correct answer
                  if (optionLine.includes('X') || optionLine.includes('✓')) {
                    correctOption = option[1];
                  }
                }
              }
              
              j++;
            }
            
            // Construct answer text
            if (options.length > 0) {
              if (correctOption) {
                answerText = `A resposta correta é (${correctOption}). \n${options.join('\n')}`;
              } else {
                answerText = options.join('\n');
              }
            }
            
            // If no answer found, use a default message
            if (!answerText) {
              answerText = "Resposta não identificada no texto importado.";
            }
            
            parsedQuestions.push({
              question: questionText,
              answer: answerText,
              specialty: defaultSpecialty || specialties[0]?.id.toString() || '',
              difficulty: (defaultDifficulty || 'medium') as 'easy' | 'medium' | 'hard',
              reference: `PNA Exam - ${batchTitle || 'Imported'}`
            });
          }
        }
      } else {
        // Process each question block
        parsedQuestions = questionBlocks.map(block => {
          const lines = block.trim().split('\n');
          
          // The first few lines are the question
          const questionLines = [];
          let i = 0;
          
          while (i < lines.length && !lines[i].includes('(A)')) {
            questionLines.push(lines[i].trim());
            i++;
          }
          
          // The remaining lines are multiple choice options
          const optionsLines = [];
          const options: string[] = [];
          let correctOption = '';
          
          while (i < lines.length) {
            const line = lines[i].trim();
            optionsLines.push(line);
            
            // Try to detect options format (A), (B), etc.
            if (/^\s*\([A-E]\)\s+.*/.test(line)) {
              const option = line.match(/^\s*\(([A-E])\)\s+(.*)/);
              if (option) {
                options.push(`${option[1]}: ${option[2]}`);
                
                // Check if this line has a marker for correct answer (X, ✓, etc.)
                if (line.includes('X') || line.includes('✓')) {
                  correctOption = option[1];
                }
              }
            }
            
            i++;
          }
          
          // Construct answer text
          let answerText = '';
          if (options.length > 0) {
            if (correctOption) {
              answerText = `A resposta correta é (${correctOption}). \n${options.join('\n')}`;
            } else {
              answerText = options.join('\n');
            }
          } else {
            answerText = optionsLines.join('\n');
          }
          
          return {
            question: questionLines.join('\n'),
            answer: answerText,
            specialty: defaultSpecialty || specialties[0]?.id.toString() || '',
            difficulty: (defaultDifficulty || 'medium') as 'easy' | 'medium' | 'hard',
            reference: `PNA Exam - ${batchTitle || 'Imported'}`
          };
        });
      }
      
      setQuestions(parsedQuestions);
      setParsingStatus(`${parsedQuestions.length} questões analisadas com sucesso.`);
      
      if (parsedQuestions.length === 0) {
        toast({
          title: "Aviso",
          description: "Não foi possível analisar questões a partir do texto. Por favor, verifique o formato.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Parsing error:', error);
      setParsingStatus('Erro ao analisar questões. Verifique o formato.');
      toast({
        title: "Erro",
        description: "Falha ao analisar questões. Por favor, verifique o formato.",
        variant: "destructive"
      });
    }
  };
  
  // Helper function to detect if a question is multiple choice and extract the correct option
  const processMultipleChoiceQuestion = (question: QuestionImport) => {
    // Check if answer contains multiple-choice options (A, B, C, D, E)
    const isMultipleChoice = 
      /^[A-E][):.]\s+.+/m.test(question.answer) || // A) Option format
      /^[(]\s*[A-E]\s*[)]\s+.+/m.test(question.answer) || // (A) Option format
      question.answer.includes("A resposta correta é");
    
    // Extract correct option if specified
    let correctOption = null;
    
    // Look for patterns like "A resposta correta é (A)" or similar in Portuguese
    const correctOptionMatch = 
      question.answer.match(/resposta correta\s*[éei]s?\s*[(]?\s*([A-E])\s*[)]?/i) ||
      question.answer.match(/alternativa correta\s*[éei]s?\s*[(]?\s*([A-E])\s*[)]?/i) ||
      question.answer.match(/opção correta\s*[éei]s?\s*[(]?\s*([A-E])\s*[)]?/i);
    
    if (correctOptionMatch) {
      correctOption = correctOptionMatch[1];
    }
    
    return {
      isMultipleChoice,
      correctOption
    };
  };

  // Handle import
  const handleImport = async () => {
    if (!user) {
      toast({
        title: "Erro",
        description: "Você precisa estar logado para importar questões.",
        variant: "destructive"
      });
      return;
    }
    
    if (questions.length === 0) {
      toast({
        title: "Erro",
        description: "Não há questões para importar. Por favor, cole e analise questões primeiro.",
        variant: "destructive"
      });
      return;
    }
    
    // Map to the correct specialtyId and add multiple choice info
    const questionsToImport = questions.map(q => {
      // Process multiple choice attributes
      const { isMultipleChoice, correctOption } = processMultipleChoiceQuestion(q);
      
      return {
        userId: user.id,
        specialtyId: parseInt(q.specialty),
        question: q.question,
        answer: q.answer,
        difficulty: q.difficulty,
        reference: q.reference,
        isMultipleChoice: isMultipleChoice,
        correctOption: correctOption
      };
    });
    
    createQuestionsMutation.mutate(questionsToImport);
  };
  
  // Handle close
  const handleDialogClose = () => {
    if (!createQuestionsMutation.isPending) {
      resetForm();
      onClose();
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleDialogClose}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Importar Questões do Exame PNA</DialogTitle>
          <DialogDescription>
            Faça upload de arquivos PDF ou cole texto dos exames PNA para extrair e importar questões automaticamente.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <div>
            <Label htmlFor="batchTitle">Nome do Lote</Label>
            <Input
              id="batchTitle"
              value={batchTitle}
              onChange={(e) => setBatchTitle(e.target.value)}
              placeholder="ex., PNA 2024 Conjunto 1"
              className="w-full"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="defaultSpecialty">Especialidade Padrão</Label>
              <Select 
                value={defaultSpecialty} 
                onValueChange={setDefaultSpecialty}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma especialidade" />
                </SelectTrigger>
                <SelectContent>
                  {specialties.map(specialty => (
                    <SelectItem 
                      key={specialty.id} 
                      value={specialty.id.toString()}
                    >
                      {specialty.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="defaultDifficulty">Dificuldade Padrão</Label>
              <Select 
                value={defaultDifficulty} 
                onValueChange={setDefaultDifficulty}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a dificuldade" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">Fácil</SelectItem>
                  <SelectItem value="medium">Média</SelectItem>
                  <SelectItem value="hard">Difícil</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Tabs defaultValue="pdf" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="pdf">Importar PDF</TabsTrigger>
              <TabsTrigger value="text">Colar Texto</TabsTrigger>
            </TabsList>
            
            {/* PDF Upload Tab */}
            <TabsContent value="pdf" className="space-y-4">
              <div 
                className={`border-2 border-dashed ${uploadedFileName ? 'border-primary-300 bg-primary-50' : 'border-gray-300'} rounded-lg p-6 flex flex-col items-center justify-center`}
                onDragOver={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  
                  if (isParsing) return;
                  
                  const files = e.dataTransfer.files;
                  if (files && files.length > 0) {
                    if (files[0].type === 'application/pdf') {
                      // Update the file input
                      if (fileInputRef.current) {
                        // Create a DataTransfer to set the file
                        const dataTransfer = new DataTransfer();
                        dataTransfer.items.add(files[0]);
                        fileInputRef.current.files = dataTransfer.files;
                        
                        // Trigger the change event handler
                        const event = new Event('change', { bubbles: true });
                        fileInputRef.current.dispatchEvent(event);
                      }
                    } else {
                      toast({
                        title: "Tipo de arquivo inválido",
                        description: "Por favor, faça upload de um arquivo PDF.",
                        variant: "destructive"
                      });
                    }
                  }
                }}
              >
                <input
                  type="file"
                  id="pdfFile"
                  accept=".pdf"
                  className="hidden"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                />
                
                {!uploadedFileName ? (
                  <>
                    <div className="text-center mb-4">
                      <i className="ri-file-pdf-line text-4xl text-gray-400"></i>
                      <p className="mt-2 text-sm text-gray-500">
                        Arraste e solte o PDF do exame PNA ou clique para navegar
                      </p>
                    </div>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isParsing}
                    >
                      Selecionar Arquivo PDF
                    </Button>
                  </>
                ) : (
                  <div className="w-full">
                    <div className="flex items-center justify-between mb-2 p-2 bg-blue-50 rounded">
                      <div className="flex items-center">
                        <i className="ri-file-pdf-line text-xl text-primary-500 mr-2"></i>
                        <span className="text-sm">{uploadedFileName}</span>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setUploadedFileName('');
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        disabled={isParsing}
                      >
                        <i className="ri-close-line"></i>
                      </Button>
                    </div>
                    {isParsing && (
                      <div className="flex justify-center my-2">
                        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary-500"></div>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              <div className="text-sm text-gray-500 italic space-y-2">
                <p>
                  <i className="ri-information-line mr-1"></i>
                  O sistema extrairá automaticamente as questões e respostas do PDF.
                </p>
                <p>
                  <i className="ri-lightbulb-line mr-1"></i>
                  Melhores resultados são obtidos com PDFs de exames PNA bem formatados.
                </p>
              </div>
            </TabsContent>
            
            {/* Text Paste Tab */}
            <TabsContent value="text" className="space-y-4">
              <div>
                <Label htmlFor="questionText">Colar Questões</Label>
                <Textarea
                  id="questionText"
                  value={questionText}
                  onChange={(e) => setQuestionText(e.target.value)}
                  placeholder="Cole as questões dos exames PNA aqui..."
                  className="w-full h-48"
                />
              </div>
              
              <div className="flex justify-end">
                <Button 
                  type="button" 
                  onClick={parseQuestions}
                  variant="outline"
                >
                  Analisar Questões
                </Button>
              </div>
              
              <div className="text-sm text-gray-500 italic space-y-2">
                <p>
                  <i className="ri-information-line mr-1"></i>
                  Formato: Cada questão deve começar com um número (ex., "1. O que é...").
                </p>
                <p>
                  <i className="ri-lightbulb-line mr-1"></i>
                  Inclua opções de múltipla escolha usando o formato (A), (B), (C), etc.
                </p>
              </div>
            </TabsContent>
          </Tabs>
          
          {parsingStatus && (
            <div className={`p-3 rounded text-sm ${
              parsingStatus.includes('Erro') 
                ? 'bg-red-100 text-red-800' 
                : 'bg-green-100 text-green-800'
            }`}>
              {parsingStatus}
            </div>
          )}
          
          {questions.length > 0 && (
            <div className="border border-gray-200 rounded-lg p-4 max-h-48 overflow-y-auto">
              <h3 className="font-medium mb-2">Pré-visualização ({questions.length} questões):</h3>
              <ul className="space-y-2">
                {questions.map((q, index) => (
                  <li key={index} className="text-sm">
                    <span className="font-medium">Q{index + 1}:</span> {q.question.substring(0, 100)}...
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleDialogClose}
              disabled={createQuestionsMutation.isPending}
            >
              Cancelar
            </Button>
            <Button 
              type="button"
              onClick={handleImport}
              disabled={createQuestionsMutation.isPending || questions.length === 0}
            >
              {createQuestionsMutation.isPending 
                ? `Importando ${questions.length} questões...` 
                : `Importar ${questions.length} Questões`}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}