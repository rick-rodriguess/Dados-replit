import { useUser } from '@/contexts/UserContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Question, Specialty } from '@shared/schema';
import { formatRelativeTime } from '@/utils/formatTime';
import { useState } from 'react';
import { Link } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface RecentQuestionsProps {
  onAddQuestion?: () => void;
}

export default function RecentQuestions({ onAddQuestion }: RecentQuestionsProps) {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: !!user
  });
  
  // Fetch recent questions
  const { data: questions = [], isLoading } = useQuery<Question[]>({
    queryKey: [`/api/questions/recent?userId=${user?.id}&limit=5`, user?.id],
    enabled: !!user?.id
  });
  
  // Review question mutation
  const reviewMutation = useMutation({
    mutationFn: async ({ questionId, knewAnswer }: { questionId: number, knewAnswer: boolean }) => {
      return apiRequest('POST', '/api/question-reviews', {
        userId: user?.id,
        questionId,
        knewAnswer
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/questions/recent?userId=${user?.id}&limit=5`, user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/overall'] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/by-specialty'] });
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
    }
  });
  
  // Handle review
  const handleReview = async (questionId: number, knewAnswer: boolean) => {
    try {
      await reviewMutation.mutateAsync({ questionId, knewAnswer });
      toast({
        title: knewAnswer ? "Great job!" : "Keep practicing!",
        description: knewAnswer 
          ? "Question marked as known" 
          : "Question marked as needing more review",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update question review",
        variant: "destructive"
      });
    }
  };
  
  // Find specialty by ID
  const getSpecialty = (id: number) => {
    return specialties.find(s => s.id === id);
  };
  
  // Get difficulty color class
  const getDifficultyClass = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'bg-green-100 text-green-700';
      case 'medium':
        return 'bg-orange-100 text-orange-700';
      case 'hard':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Recently Added Questions</h2>
        <Link 
          href="/questions"
          className="text-primary-500 hover:text-primary-600 flex items-center text-sm"
        >
          <span>View all</span>
          <i className="ri-arrow-right-s-line"></i>
        </Link>
      </div>
      
      {isLoading ? (
        <div className="py-8 text-center text-gray-500">Loading questions...</div>
      ) : questions.length === 0 ? (
        <div className="py-8 text-center text-gray-500">
          <p>No questions added yet.</p>
          <p className="mt-2 text-sm">Add your first question to start tracking your progress.</p>
        </div>
      ) : (
        <div className="space-y-3 mb-3">
          {questions.map(question => {
            const specialty = getSpecialty(question.specialtyId);
            
            return (
              <div 
                key={question.id}
                className="border border-gray-200 rounded-lg p-4 hover:border-primary-200 hover:bg-primary-50 transition duration-150"
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      {specialty && (
                        <span 
                          className="text-xs px-2 py-0.5 rounded-full"
                          style={{ 
                            backgroundColor: `${specialty.color}20`, // 20% opacity
                            color: specialty.color 
                          }}
                        >
                          {specialty.name}
                        </span>
                      )}
                      <span className={`text-xs px-2 py-0.5 rounded-full ${getDifficultyClass(question.difficulty)}`}>
                        {question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1)}
                      </span>
                    </div>
                    <h3 className="font-medium text-gray-800">{question.question}</h3>
                    <div className="mt-2 text-sm text-gray-600">
                      <p>{question.answer}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <div className="text-xs text-gray-500">
                      {question.createdAt && formatRelativeTime(new Date(question.createdAt))}
                    </div>
                    <div className="mt-2 flex space-x-1">
                      <button 
                        className="p-1 text-gray-400 hover:text-primary-500"
                        title="Edit question"
                      >
                        <i className="ri-edit-line"></i>
                      </button>
                      <button 
                        className="p-1 text-gray-400 hover:text-accent-500"
                        title="Create flashcard"
                      >
                        <i className="ri-flashcard-line"></i>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between items-center">
                  <div className="flex items-center space-x-2 text-sm">
                    <i className="ri-time-line text-gray-400"></i>
                    <span className="text-gray-500">
                      {question.lastReviewedAt 
                        ? `Last reviewed: ${formatRelativeTime(new Date(question.lastReviewedAt))}`
                        : 'Last reviewed: Never'
                      }
                    </span>
                  </div>
                  <div className="flex space-x-2">
                    <button 
                      onClick={() => handleReview(question.id, false)}
                      className="bg-red-100 text-red-600 px-3 py-1.5 rounded text-sm hover:bg-red-200"
                    >
                      Struggled
                    </button>
                    <button 
                      onClick={() => handleReview(question.id, true)}
                      className="bg-green-100 text-green-600 px-3 py-1.5 rounded text-sm hover:bg-green-200"
                    >
                      Knew it
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
      
      <button 
        onClick={onAddQuestion}
        className="w-full border border-dashed border-gray-300 text-gray-500 hover:text-primary-500 hover:border-primary-400 rounded-lg p-3 flex items-center justify-center space-x-2 transition"
      >
        <i className="ri-add-line"></i>
        <span>Add new question</span>
      </button>
    </div>
  );
}
