import { Link } from 'wouter';

interface QuickActionsProps {
  onAddQuestion?: () => void;
  onCreateFlashcard?: () => void;
  onPracticeTest?: () => void;
}

export default function QuickActions({ 
  onAddQuestion, 
  onCreateFlashcard, 
  onPracticeTest 
}: QuickActionsProps) {
  const handleExportData = () => {
    // This would be implemented with a proper export functionality
    alert('Export data functionality would be implemented here');
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
      
      <div className="grid grid-cols-2 gap-3">
        <button 
          onClick={onAddQuestion}
          className="bg-primary-50 hover:bg-primary-100 border border-primary-200 rounded-lg p-3 flex flex-col items-center justify-center"
        >
          <i className="ri-add-circle-line text-primary-500 text-xl mb-1"></i>
          <span className="text-sm text-gray-700">New Question</span>
        </button>
        
        <Link 
          href={onCreateFlashcard ? '#' : '/flashcards/new'}
          onClick={onCreateFlashcard}
          className="bg-accent-50 hover:bg-accent-100 border border-accent-200 rounded-lg p-3 flex flex-col items-center justify-center"
        >
          <i className="ri-flashcard-line text-accent-500 text-xl mb-1"></i>
          <span className="text-sm text-gray-700">Create Flashcards</span>
        </Link>
        
        <Link 
          href={onPracticeTest ? '#' : '/practice-tests/new'}
          onClick={onPracticeTest}
          className="bg-secondary-50 hover:bg-secondary-100 border border-secondary-200 rounded-lg p-3 flex flex-col items-center justify-center"
        >
          <i className="ri-file-text-line text-secondary-500 text-xl mb-1"></i>
          <span className="text-sm text-gray-700">Practice Test</span>
        </Link>
        
        <button 
          onClick={handleExportData}
          className="bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg p-3 flex flex-col items-center justify-center"
        >
          <i className="ri-export-line text-gray-500 text-xl mb-1"></i>
          <span className="text-sm text-gray-700">Export Data</span>
        </button>
      </div>
    </div>
  );
}
