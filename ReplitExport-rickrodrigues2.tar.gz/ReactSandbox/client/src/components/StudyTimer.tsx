import { useUser } from '@/contexts/UserContext';
import { useTimer } from '@/hooks/useTimer';
import { useQuery } from '@tanstack/react-query';
import { formatTime } from '@/utils/formatTime';
import { useState, useEffect } from 'react';
import { 
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectGroup,
  SelectItem
} from '@/components/ui/select';
import { Specialty } from '@shared/schema';
import { Separator } from '@/components/ui/separator';
import { PlayIcon, PauseIcon, Square as StopIcon } from 'lucide-react';

export default function StudyTimer() {
  const { user } = useUser();
  const [selectedSpecialty, setSelectedSpecialty] = useState<number | null>(null);
  const [focus, setFocus] = useState<string>('');
  const [isChangingSpecialty, setIsChangingSpecialty] = useState(false);
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: !!user
  });
  
  const { 
    seconds, 
    isRunning, 
    startTimer, 
    pauseTimer, 
    stopTimer, 
    totalToday,
    activeSession
  } = useTimer({
    userId: user?.id || 0,
    specialtyId: selectedSpecialty || undefined,
    focus: focus || undefined,
    autoStart: false
  });
  
  // Set the selected specialty from active session if available
  useEffect(() => {
    if (activeSession && activeSession.specialtyId) {
      setSelectedSpecialty(activeSession.specialtyId);
      setFocus(activeSession.focus || '');
    }
  }, [activeSession]);
  
  // Find the active specialty object
  const activeSpecialty = specialties.find(s => s.id === (activeSession?.specialtyId || selectedSpecialty));
  
  // Handle specialty change
  const handleSpecialtyChange = (value: string) => {
    setSelectedSpecialty(parseInt(value));
  };
  
  const handleFocusChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFocus(e.target.value);
  };

  const handleSaveSpecialty = () => {
    setIsChangingSpecialty(false);
    // The next time user starts a timer, it will use the new specialty
  };
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Study Session</h2>
        <div className="flex space-x-2">
          <span className="text-sm text-gray-500">Total today: {totalToday}</span>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
        <div className="bg-gray-100 rounded-lg py-3 px-5 mb-4 sm:mb-0 w-full sm:w-auto">
          <div className="font-mono text-3xl font-medium text-gray-800 text-center">
            {formatTime(seconds)}
          </div>
          <div className="text-sm text-gray-500 text-center mt-1">Current Session</div>
        </div>
        
        <div className="flex space-x-3">
          <button 
            onClick={startTimer}
            disabled={isRunning}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
              isRunning 
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                : 'bg-secondary-500 hover:bg-secondary-600 text-white'
            }`}
          >
            <PlayIcon className="h-4 w-4" />
            <span>Start</span>
          </button>
          
          <button 
            onClick={pauseTimer}
            disabled={!isRunning}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
              !isRunning 
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
            }`}
          >
            <PauseIcon className="h-4 w-4" />
            <span>Pause</span>
          </button>
          
          <button 
            onClick={stopTimer}
            disabled={!activeSession}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
              !activeSession 
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed' 
                : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
            }`}
          >
            <StopIcon className="h-4 w-4" />
            <span>Stop</span>
          </button>
        </div>
      </div>
      
      <div className="mt-4">
        <div className="flex items-center justify-between text-sm text-gray-500 mb-2">
          <span>Currently studying:</span>
          <button 
            onClick={() => setIsChangingSpecialty(!isChangingSpecialty)}
            className="text-primary-500 hover:text-primary-600 flex items-center"
          >
            <span>Change</span>
            <i className="ri-arrow-right-s-line"></i>
          </button>
        </div>
        
        {isChangingSpecialty ? (
          <div className="bg-primary-50 border border-primary-100 rounded-lg p-3">
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Specialty
                </label>
                <Select
                  value={selectedSpecialty?.toString() || ''}
                  onValueChange={handleSpecialtyChange}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select a specialty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      {specialties.map(specialty => (
                        <SelectItem 
                          key={specialty.id} 
                          value={specialty.id.toString()}
                        >
                          {specialty.name}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Focus Area (optional)
                </label>
                <input
                  type="text"
                  value={focus}
                  onChange={handleFocusChange}
                  placeholder="E.g., Arrhythmias, Heart Failure"
                  className="w-full p-2 border border-gray-300 rounded-md"
                />
              </div>
              
              <div className="flex justify-end">
                <button
                  onClick={handleSaveSpecialty}
                  className="bg-primary-500 text-white px-3 py-1.5 rounded text-sm hover:bg-primary-600"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-primary-50 border border-primary-100 rounded-lg p-3 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div 
                className="rounded-full p-2 text-white"
                style={{ backgroundColor: activeSpecialty?.color || '#2563EB' }}
              >
                <i className="ri-heart-pulse-line"></i>
              </div>
              <div>
                <div className="font-medium text-gray-800">
                  {activeSpecialty?.name || 'No specialty selected'}
                </div>
                {activeSession?.focus && (
                  <div className="text-sm text-gray-500">Focus: {activeSession.focus}</div>
                )}
              </div>
            </div>
            {activeSession && (
              <span className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full">
                Active session
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
