import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';

interface ChartData {
  name: string;
  value: number;
}

interface StudyTimeChartProps {
  data: ChartData[];
}

export default function StudyTimeChart({ data }: StudyTimeChartProps) {
  // Colors for the pie chart
  const COLORS = [
    '#2563eb', // blue
    '#8b5cf6', // purple
    '#10b981', // green
    '#f59e0b', // amber
    '#ec4899', // pink
    '#ef4444', // red
    '#6366f1', // indigo
    '#14b8a6', // teal
    '#a3e635'  // lime
  ];
  
  // Custom tooltip formatting
  const renderTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border border-gray-200 shadow-sm rounded">
          <p className="font-medium">{payload[0].name}</p>
          <p className="text-gray-600">{`${payload[0].value.toFixed(1)} hours`}</p>
          <p className="text-gray-500">{`${payload[0].payload.percent.toFixed(1)}%`}</p>
        </div>
      );
    }
    return null;
  };
  
  // Calculate percentages for each item
  const totalValue = data.reduce((sum, item) => sum + item.value, 0);
  const dataWithPercent = data.map(item => ({
    ...item,
    percent: (item.value / totalValue) * 100
  }));
  
  return (
    <div className="h-60 w-full">
      {data.length === 0 ? (
        <div className="h-full flex items-center justify-center">
          <p className="text-gray-500">No study data available</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={dataWithPercent}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {dataWithPercent.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip content={renderTooltip} />
            <Legend formatter={(value) => <span className="text-sm">{value}</span>} />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
