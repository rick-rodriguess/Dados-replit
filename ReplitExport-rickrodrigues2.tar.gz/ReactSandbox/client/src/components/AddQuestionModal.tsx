import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Specialty } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';

interface AddQuestionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddQuestionModal({ isOpen, onClose }: AddQuestionModalProps) {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: isOpen && !!user
  });
  
  // Form state
  const [specialtyId, setSpecialtyId] = useState<string>('');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [difficulty, setDifficulty] = useState<string>('medium');
  const [reference, setReference] = useState('');
  const [createFlashcard, setCreateFlashcard] = useState(false);
  const [isMultipleChoice, setIsMultipleChoice] = useState(false);
  const [correctOption, setCorrectOption] = useState<string>('');
  
  // Create question mutation
  const createQuestionMutation = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest('POST', '/api/questions', data);
    },
    onSuccess: async (response) => {
      const question = await response.json();
      
      queryClient.invalidateQueries({ queryKey: ['/api/questions', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/questions/recent', user?.id] });
      
      // If create flashcard is checked, create a flashcard
      if (createFlashcard) {
        await apiRequest('POST', '/api/flashcards', {
          userId: user?.id,
          questionId: question.id,
          front: question.question,
          back: question.answer
        });
        queryClient.invalidateQueries({ queryKey: ['/api/flashcards', user?.id] });
      }
      
      toast({
        title: "Question added",
        description: "Your question has been successfully added."
      });
      
      resetForm();
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add question. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Reset form
  const resetForm = () => {
    setSpecialtyId('');
    setQuestion('');
    setAnswer('');
    setDifficulty('medium');
    setReference('');
    setCreateFlashcard(false);
    setIsMultipleChoice(false);
    setCorrectOption('');
  };
  
  // Handle submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to add a question.",
        variant: "destructive"
      });
      return;
    }
    
    if (!specialtyId || !question || !answer) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }
    
    createQuestionMutation.mutate({
      userId: user.id,
      specialtyId: parseInt(specialtyId),
      question,
      answer,
      difficulty,
      reference: reference || undefined,
      isMultipleChoice,
      correctOption: isMultipleChoice ? correctOption || null : null
    });
  };
  
  // Handle close
  const handleDialogClose = () => {
    if (!createQuestionMutation.isPending) {
      onClose();
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={handleDialogClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add New Question</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-2">
          <div>
            <Label htmlFor="specialty">Medical Specialty</Label>
            <Select 
              value={specialtyId} 
              onValueChange={setSpecialtyId}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select a specialty" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map(specialty => (
                  <SelectItem 
                    key={specialty.id} 
                    value={specialty.id.toString()}
                  >
                    {specialty.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="question">Question</Label>
            <Textarea
              id="question"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Enter your question here..."
              className="h-24"
            />
          </div>
          
          <div>
            <Label htmlFor="answer">Answer</Label>
            <Textarea
              id="answer"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Enter the answer here..."
              className="h-24"
            />
          </div>
          
          <div>
            <Label>Difficulty</Label>
            <div className="flex space-x-2 mt-1">
              <Button
                type="button"
                onClick={() => setDifficulty('easy')}
                className={`flex-1 ${
                  difficulty === 'easy'
                    ? 'bg-green-100 hover:bg-green-200 text-green-800 border border-green-300'
                    : 'bg-transparent hover:bg-gray-100 text-gray-700 border border-gray-300'
                }`}
                variant="ghost"
              >
                Easy
              </Button>
              <Button
                type="button"
                onClick={() => setDifficulty('medium')}
                className={`flex-1 ${
                  difficulty === 'medium'
                    ? 'bg-orange-100 hover:bg-orange-200 text-orange-800 border border-orange-300'
                    : 'bg-transparent hover:bg-gray-100 text-gray-700 border border-gray-300'
                }`}
                variant="ghost"
              >
                Medium
              </Button>
              <Button
                type="button"
                onClick={() => setDifficulty('hard')}
                className={`flex-1 ${
                  difficulty === 'hard'
                    ? 'bg-red-100 hover:bg-red-200 text-red-800 border border-red-300'
                    : 'bg-transparent hover:bg-gray-100 text-gray-700 border border-gray-300'
                }`}
                variant="ghost"
              >
                Hard
              </Button>
            </div>
          </div>
          
          <div>
            <Label htmlFor="reference">Evidence/Reference (Optional)</Label>
            <Input
              id="reference"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              placeholder="Add a reference or citation..."
            />
          </div>
          
          <div className="flex items-center space-x-2 pt-2">
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isMultipleChoice"
                checked={isMultipleChoice}
                onChange={(e) => setIsMultipleChoice(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
              />
              <Label htmlFor="isMultipleChoice" className="text-sm font-medium">
                This is a multiple choice question
              </Label>
            </div>
          </div>

          {isMultipleChoice && (
            <div>
              <Label htmlFor="correctOption">Correct Option</Label>
              <Select 
                value={correctOption} 
                onValueChange={setCorrectOption}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select correct option" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  <SelectItem value="A">A</SelectItem>
                  <SelectItem value="B">B</SelectItem>
                  <SelectItem value="C">C</SelectItem>
                  <SelectItem value="D">D</SelectItem>
                  <SelectItem value="E">E</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500 mt-1">
                Make sure your answer text includes options in the format: A) Option text
              </p>
            </div>
          )}
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="create-flashcard"
              checked={createFlashcard}
              onCheckedChange={(checked) => setCreateFlashcard(checked === true)}
            />
            <Label htmlFor="create-flashcard" className="text-sm font-normal">
              Also create flashcard from this question
            </Label>
          </div>
          
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={createQuestionMutation.isPending}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={createQuestionMutation.isPending}
            >
              {createQuestionMutation.isPending ? 'Saving...' : 'Save Question'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
