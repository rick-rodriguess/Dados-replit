import pdfParse from 'pdf-parse';

// Fixing TypeScript error for line parameter
type TextLine = string;

export interface ParsedQuestion {
  question: string;
  options: string[];
  correctOptionIndex?: number;
  hasMultipleChoiceFormat: boolean;
}

export async function extractQuestionsFromPdf(fileBuffer: ArrayBuffer): Promise<ParsedQuestion[]> {
  try {
    // Convert ArrayBuffer to Buffer for pdf-parse
    const buffer = Buffer.from(fileBuffer);
    const pdfData = await pdfParse(buffer);
    const text = pdfData.text;
    
    // Split text into lines for processing
    const lines = text.split('\n').filter(line => line.trim());
    
    // Initialize variables to track question extraction
    const parsedQuestions: ParsedQuestion[] = [];
    let currentQuestion: ParsedQuestion | null = null;
    
    // Regular expressions for pattern matching
    const questionStartRegex = /^\s*(\d+)\.\s+(.+)/;
    const optionRegex = /^\s*\(?([A-E])\)?\s+(.+)/;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // Check if this line starts a new question
      const questionMatch = line.match(questionStartRegex);
      if (questionMatch) {
        // Save previous question if exists
        if (currentQuestion) {
          parsedQuestions.push(currentQuestion);
        }
        
        // Start a new question
        currentQuestion = {
          question: questionMatch[2],
          options: [],
          hasMultipleChoiceFormat: false
        };
        
        // Continue building the question text from subsequent lines until we hit options
        let j = i + 1;
        while (j < lines.length) {
          const nextLine = lines[j].trim();
          const optionMatch = nextLine.match(optionRegex);
          
          if (optionMatch) {
            // We've reached the options, stop adding to question text
            break;
          } else if (nextLine.match(questionStartRegex)) {
            // We've hit the next question, stop here
            break;
          } else {
            // Add this line to the question text
            currentQuestion.question += ' ' + nextLine;
            j++;
            i = j - 1; // Update the outer loop counter
          }
        }
      } else {
        // Check if this line is an option for the current question
        const optionMatch = line.match(optionRegex);
        if (currentQuestion && optionMatch) {
          const optionLetter = optionMatch[1];
          const optionText = optionMatch[2];
          
          currentQuestion.options.push(`(${optionLetter}) ${optionText}`);
          currentQuestion.hasMultipleChoiceFormat = true;
          
          // Check if this option is marked as correct somehow
          // This is just a placeholder - actual detection would depend on the PDF format
          if (optionText.includes("correto") || optionText.includes("correta") ||
              line.includes("✓") || line.includes("X")) {
            currentQuestion.correctOptionIndex = currentQuestion.options.length - 1;
          }
        }
      }
    }
    
    // Add the last question if exists
    if (currentQuestion) {
      parsedQuestions.push(currentQuestion);
    }
    
    return parsedQuestions;
  } catch (error) {
    console.error('Error parsing PDF:', error);
    throw new Error('Failed to parse PDF file.');
  }
}

export function preprocessPdfText(text: string): string {
  // Remove headers, footers, and page numbers
  let processed = text.replace(/Page \d+ of \d+/g, '');
  
  // Clean up extra whitespace
  processed = processed.replace(/\s+/g, ' ');
  
  // Fix common OCR errors in medical terms
  const medicalTermsCorrections: Record<string, string> = {
    'cardiopatla': 'cardiopatia',
    'hipertensáo': 'hipertensão',
    // Add more medical terms corrections here
  };
  
  // Apply medical term corrections
  Object.entries(medicalTermsCorrections).forEach(([incorrect, correct]) => {
    processed = processed.replace(new RegExp(incorrect, 'g'), correct);
  });
  
  return processed;
}

// Helper to determine specialty based on question content
export function guessSpecialty(question: string, specialties: any[]): number {
  // Define keywords for each specialty
  const specialtyKeywords: Record<string, string[]> = {
    'Cardiology': ['heart', 'cardiac', 'chest pain', 'cardiac', 'cardíaco', 'coração', 'ECG', 'angina'],
    'Neurology': ['brain', 'neural', 'headache', 'cérebro', 'neural', 'cabeça', 'epilepsia', 'neurologia'],
    'Gastroenterology': ['stomach', 'intestine', 'liver', 'digestive', 'estômago', 'intestino', 'fígado', 'digestivo'],
    'Pulmonology': ['lung', 'respiratory', 'respiration', 'pulmão', 'respiratório', 'respiração', 'asma', 'DPOC'],
    'Endocrinology': ['hormone', 'thyroid', 'diabetes', 'hormona', 'tiróide', 'diabetes', 'insulina'],
    'Nephrology': ['kidney', 'renal', 'rim', 'renal', 'diálise', 'ureter', 'nefrite'],
    'Hematology': ['blood', 'anemia', 'sangue', 'anemia', 'leucemia', 'coagulação'],
    'Immunology': ['immune', 'allergy', 'imune', 'alergia', 'auto-imune', 'anticorpo'],
    'Dermatology': ['skin', 'rash', 'pele', 'erupção', 'dermatite', 'eczema'],
    'Psychiatry': ['mental', 'depression', 'anxiety', 'schizophrenia', 'mental', 'depressão', 'ansiedade', 'esquizofrenia'],
    'Oncology': ['cancer', 'tumor', 'malignant', 'cancro', 'tumor', 'maligno', 'metástase'],
    'Infectious Disease': ['infection', 'bacteria', 'virus', 'infecção', 'bactéria', 'vírus', 'antibiótico'],
    'Rheumatology': ['joint', 'arthritis', 'articulação', 'artrite', 'reumatismo', 'auto-imune'],
    'Pharmacology': ['drug', 'medication', 'medicamento', 'fármaco', 'dosagem', 'interação'],
    'Pathology': ['tissue', 'biopsy', 'tecido', 'biópsia', 'histologia', 'patologia']
  };
  
  // Count matches for each specialty
  const matches: Record<string, number> = {};
  
  // Convert question to lowercase for case-insensitive matching
  const lowerQuestion = question.toLowerCase();
  
  // Check each specialty's keywords
  Object.entries(specialtyKeywords).forEach(([specialty, keywords]) => {
    let count = 0;
    keywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword.toLowerCase()}\\b`, 'g');
      const matches = lowerQuestion.match(regex);
      if (matches) {
        count += matches.length;
      }
    });
    matches[specialty] = count;
  });
  
  // Find the specialty with the most matches
  let bestMatch = '';
  let highestCount = 0;
  
  Object.entries(matches).forEach(([specialty, count]) => {
    if (count > highestCount) {
      highestCount = count;
      bestMatch = specialty;
    }
  });
  
  // Find the specialty ID that corresponds to the best match
  const matchedSpecialty = specialties.find(s => s.name === bestMatch);
  
  // Return the ID or the first specialty ID as fallback
  return matchedSpecialty ? matchedSpecialty.id : (specialties[0]?.id || 1);
}

// Function to detect question difficulty based on content
export function assessQuestionDifficulty(question: string, options: string[]): 'easy' | 'medium' | 'hard' {
  // Count the length of question and options
  const totalLength = question.length + options.join('').length;
  
  // Check for keywords indicating complexity
  const complexityIndicators = [
    'diagnóstico diferencial', 'differential diagnosis',
    'complexo', 'complex',
    'raro', 'rare',
    'avançado', 'advanced',
    'controverso', 'controversial'
  ];
  
  let complexityScore = 0;
  
  // Check for presence of complexity indicators
  complexityIndicators.forEach(indicator => {
    if (question.toLowerCase().includes(indicator.toLowerCase())) {
      complexityScore += 1;
    }
  });
  
  // Length-based difficulty assessment
  if (totalLength > 500 || complexityScore >= 2) {
    return 'hard';
  } else if (totalLength > 300 || complexityScore >= 1) {
    return 'medium';
  } else {
    return 'easy';
  }
}