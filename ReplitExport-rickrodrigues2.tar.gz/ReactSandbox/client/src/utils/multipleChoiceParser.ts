/**
 * Multiple choice question parser
 * Converts multiple choice question text into structured data
 */

export interface Option {
  letter: string;
  text: string;
}

export interface ParsedMultipleChoice {
  questionText: string;
  options: Option[];
  isMultipleChoice: boolean;
}

/**
 * Parses the question text to extract multiple choice options if present
 * 
 * @param text The full question text potentially containing multiple choice options
 * @returns Object containing the question text and extracted options
 */
export function parseMultipleChoiceQuestion(text: string): ParsedMultipleChoice {
  // Default return value for non-multiple choice questions
  const defaultResult: ParsedMultipleChoice = {
    questionText: text,
    options: [],
    isMultipleChoice: false
  };

  if (!text) return defaultResult;

  // Various option patterns
  const optionPatterns = [
    /^([A-E])[):.]\s+(.+)$/m, // A) Text or A. Text or A: Text
    /^([A-E])[-–]\s+(.+)$/m,  // A - Text or A – Text
    /^\(([A-E])\)\s+(.+)$/m,  // (A) Text
    /^\[([A-E])\]\s+(.+)$/m,  // [A] Text
  ];

  // Split by lines for processing
  const lines = text.split('\n');
  const options: Option[] = [];
  const nonOptionLines: string[] = [];
  
  let foundMultipleChoice = false;
  let lastOptionIndex = -1;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    let matched = false;

    for (const pattern of optionPatterns) {
      const match = line.match(pattern);
      if (match) {
        foundMultipleChoice = true;
        lastOptionIndex = i;
        options.push({
          letter: match[1],
          text: match[2].trim()
        });
        matched = true;
        break;
      }
    }

    if (!matched) {
      nonOptionLines.push(line);
    }
  }

  // If we found multiple choice options
  if (foundMultipleChoice && options.length > 0) {
    // The question text is everything before the first option
    const questionText = nonOptionLines.join('\n').trim();

    return {
      questionText,
      options,
      isMultipleChoice: true
    };
  }

  return defaultResult;
}

/**
 * Converts a raw answer text that might contain multiple choice options 
 * into an array of options
 */
export function parseAnswerOptions(answerText: string): Option[] {
  if (!answerText) return [];

  const lines = answerText.split('\n');
  const options: Option[] = [];

  // Regular expressions for different option formats
  const optionRegex = /^([A-E])[):.]\s+(.+)$/;
  const dashOptionRegex = /^([A-E])[-–]\s+(.+)$/;
  const parenthesisOptionRegex = /^\(([A-E])\)\s+(.+)$/;
  const bracketOptionRegex = /^\[([A-E])\]\s+(.+)$/;

  for (const line of lines) {
    const trimmedLine = line.trim();
    let match = trimmedLine.match(optionRegex) || 
                trimmedLine.match(dashOptionRegex) ||
                trimmedLine.match(parenthesisOptionRegex) ||
                trimmedLine.match(bracketOptionRegex);

    if (match) {
      options.push({
        letter: match[1],
        text: match[2].trim()
      });
    }
  }

  return options;
}

/**
 * Determines the appropriate class name for an option based on selection status
 */
export function getOptionClassName(
  optionLetter: string, 
  selectedOption?: string, 
  correctOption?: string, 
  showCorrect: boolean = false
): string {
  let className = "p-2 rounded border border-gray-200 flex items-start hover:bg-gray-50 cursor-pointer transition-all duration-200";
  
  // Style for selected option
  if (selectedOption === optionLetter) {
    if (showCorrect) {
      // Show red if selected and incorrect
      if (correctOption && selectedOption !== correctOption) {
        className = "p-2 rounded border-2 border-red-500 bg-red-50 flex items-start shadow-md";
      } 
      // Show green if selected and correct
      else if (correctOption && selectedOption === correctOption) {
        className = "p-2 rounded border-2 border-green-500 bg-green-50 flex items-start shadow-md";
      } 
      // Show blue if just selected (no correct answer revealed)
      else {
        className = "p-2 rounded border-2 border-primary-500 bg-primary-50 flex items-start shadow-md";
      }
    } else {
      className = "p-2 rounded border-2 border-primary-500 bg-primary-50 flex items-start shadow-md";
    }
  }
  
  // If showing correct answers and this is the correct one (but not selected)
  if (showCorrect && correctOption === optionLetter && selectedOption !== optionLetter) {
    className = "p-2 rounded border-2 border-green-500 bg-green-50 flex items-start shadow-md";
  }
  
  return className;
}