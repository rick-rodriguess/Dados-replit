import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Question, Specialty } from '@shared/schema';
import { formatRelativeTime } from '@/utils/formatTime';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { parseAnswerOptions, Option, getOptionClassName } from '@/utils/multipleChoiceParser';
import Header from '@/components/Header';
import Navigation from '@/components/Navigation';
import AddQuestionModal from '@/components/AddQuestionModal';
import EditQuestionModal from '@/components/EditQuestionModal';
import AddFlashcardModal from '@/components/AddFlashcardModal';
import ImportQuestionsModal from '@/components/ImportQuestionsModal';
import PDFViewer from '@/components/PDFViewer';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Questions() {
  const { user } = useUser();
  const { toast } = useToast();
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const [isAddQuestionModalOpen, setIsAddQuestionModalOpen] = useState(false);
  const [isEditQuestionModalOpen, setIsEditQuestionModalOpen] = useState(false);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  const [isAddFlashcardModalOpen, setIsAddFlashcardModalOpen] = useState(false);
  const [isImportQuestionsModalOpen, setIsImportQuestionsModalOpen] = useState(false);
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [isPdfViewerOpen, setIsPdfViewerOpen] = useState(false);
  const [viewingPdfUrl, setViewingPdfUrl] = useState('');
  const [answeredQuestions, setAnsweredQuestions] = useState<Record<number, {selectedOption: string, isCorrect: boolean}>>({});
  
  // Fetch questions
  const { data: questions = [], isLoading } = useQuery<Question[]>({
    queryKey: [`/api/questions?userId=${user?.id}`, user?.id],
    enabled: !!user?.id
  });
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: !!user
  });
  
  // Review question mutation
  const reviewMutation = useMutation({
    mutationFn: async ({ questionId, knewAnswer }: { questionId: number, knewAnswer: boolean }) => {
      return apiRequest('POST', '/api/question-reviews', {
        userId: user?.id,
        questionId,
        knewAnswer
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/questions?userId=${user?.id}`, user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/overall'] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/by-specialty'] });
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
    }
  });
  
  // Answer multiple choice question mutation
  const answerQuestionMutation = useMutation({
    mutationFn: async ({ questionId, selectedOption }: { questionId: number, selectedOption: string }) => {
      return apiRequest('POST', `/api/questions/${questionId}/answer`, {
        selectedOption
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: [`/api/questions?userId=${user?.id}`, user?.id] });
      queryClient.invalidateQueries({ queryKey: [`/api/questions/recent?userId=${user?.id}&limit=5`, user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/overall'] });
      queryClient.invalidateQueries({ queryKey: ['/api/performance/by-specialty'] });
      
      // Update local state to show feedback immediately
      setAnsweredQuestions(prev => ({
        ...prev,
        [data.question.id]: {
          selectedOption: data.question.userSelectedOption,
          isCorrect: data.isCorrect
        }
      }));
      
      toast({
        title: data.isCorrect ? "Correto!" : "Incorreto",
        description: data.isCorrect 
          ? "Muito bem! Você acertou." 
          : `A resposta correta era: ${data.correctOption}`,
        variant: data.isCorrect ? "default" : "destructive"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit answer. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Delete question mutation
  const deleteQuestionMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest('DELETE', `/api/questions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/questions?userId=${user?.id}`, user?.id] });
      queryClient.invalidateQueries({ queryKey: [`/api/questions/recent?userId=${user?.id}&limit=5`, user?.id] });
      
      toast({
        title: "Question deleted",
        description: "The question has been successfully deleted."
      });
      
      setIsDeleteAlertOpen(false);
      setSelectedQuestion(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete question. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  // Filter questions
  const filteredQuestions = questions.filter(question => {
    // Filter by search term
    const matchesSearch = 
      question.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      question.answer.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by specialty
    const matchesSpecialty = 
      selectedSpecialty === 'all' || 
      question.specialtyId.toString() === selectedSpecialty;
    
    // Filter by difficulty
    const matchesDifficulty = 
      selectedDifficulty === 'all' || 
      question.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesSpecialty && matchesDifficulty;
  });
  
  // Handle review
  const handleReview = async (questionId: number, knewAnswer: boolean) => {
    try {
      await reviewMutation.mutateAsync({ questionId, knewAnswer });
      toast({
        title: knewAnswer ? "Great job!" : "Keep practicing!",
        description: knewAnswer 
          ? "Question marked as known" 
          : "Question marked as needing more review",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update question review",
        variant: "destructive"
      });
    }
  };
  
  // Find specialty by ID
  const getSpecialty = (id: number) => {
    return specialties.find(s => s.id === id);
  };
  
  // Get difficulty color class
  const getDifficultyClass = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case 'easy':
        return 'bg-green-100 text-green-700';
      case 'medium':
        return 'bg-orange-100 text-orange-700';
      case 'hard':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };
  
  const handlePdfImport = () => {
    setIsImportQuestionsModalOpen(true);
  };
  
  const handleViewPdf = (pdfUrl: string) => {
    setViewingPdfUrl(pdfUrl);
    setIsPdfViewerOpen(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Navigation />
        
        <Card className="p-6 mb-6">
          <h3 className="text-lg font-medium mb-4">{t('title.importFromPdf')}</h3>
          <p className="mb-4">{t('msg.importPdfDescription')}</p>
          <div className="flex items-center space-x-4">
            <Button onClick={handlePdfImport} variant="default">
              <i className="ri-file-list-line mr-2"></i>
              {t('button.importFromPdf')}
            </Button>
            <Button 
              onClick={() => handleViewPdf('/158-24_PNA_Parte-I_Versao-A.pdf')} 
              variant="outline"
              className="text-sm"
            >
              {t('button.viewExamplePdf')}
            </Button>
          </div>
        </Card>
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 mb-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 space-y-4 md:space-y-0">
            <h2 className="text-xl font-semibold">{t('title.questions')}</h2>
            <div className="flex space-x-2">
              <Button 
                variant="outline"
                onClick={() => setIsImportQuestionsModalOpen(true)}
              >
                <i className="ri-file-list-line mr-2"></i>
                {t('button.import')} PNA
              </Button>
              <Button onClick={() => setIsAddQuestionModalOpen(true)}>
                <i className="ri-add-line mr-2"></i>
                {t('button.add')} {t('form.question')}
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <Input
                placeholder={t('msg.searchQuestions')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            
            <div>
              <Select
                value={selectedSpecialty}
                onValueChange={setSelectedSpecialty}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('form.allSpecialties')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('form.allSpecialties')}</SelectItem>
                  {specialties.map(specialty => (
                    <SelectItem 
                      key={specialty.id} 
                      value={specialty.id.toString()}
                    >
                      {specialty.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Select
                value={selectedDifficulty}
                onValueChange={setSelectedDifficulty}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('form.allDifficulties')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('form.allDifficulties')}</SelectItem>
                  <SelectItem value="easy">{t('form.easy')}</SelectItem>
                  <SelectItem value="medium">{t('form.medium')}</SelectItem>
                  <SelectItem value="hard">{t('form.hard')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {isLoading ? (
            <div className="py-8 text-center text-gray-500">Loading questions...</div>
          ) : filteredQuestions.length === 0 ? (
            <div className="py-8 text-center text-gray-500">
              <p>No questions found.</p>
              <p className="mt-2 text-sm">
                {questions.length === 0 
                  ? "Add your first question to start tracking your progress." 
                  : "Try changing your search filters."}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredQuestions.map(question => {
                const specialty = getSpecialty(question.specialtyId);
                
                return (
                  <div 
                    key={question.id}
                    className="border border-gray-200 rounded-lg p-4 hover:border-primary-200 hover:bg-primary-50 transition duration-150"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          {specialty && (
                            <span 
                              className="text-xs px-2 py-0.5 rounded-full"
                              style={{ 
                                backgroundColor: `${specialty.color}20`, // 20% opacity
                                color: specialty.color 
                              }}
                            >
                              {specialty.name}
                            </span>
                          )}
                          <span className={`text-xs px-2 py-0.5 rounded-full ${getDifficultyClass(question.difficulty)}`}>
                            {question.difficulty.charAt(0).toUpperCase() + question.difficulty.slice(1)}
                          </span>
                          {question.isKnown && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700">
                              Known
                            </span>
                          )}
                        </div>
                        <h3 className="font-medium text-gray-800">{question.question}</h3>
                        
                        {/* Parse and render multiple choice options if present */}
                        {question.answer && (
                          <>
                            {/* Try to parse multiple choice options */}
                            {(() => {
                              // Check if question is marked as multiple choice in the database
                              // If not explicitly set, try to detect by parsing the answer
                              const options = parseAnswerOptions(question.answer);
                              if (question.isMultipleChoice || (options.length > 0)) {
                                // This is a multiple choice question
                                return (
                                  <div className="space-y-2 mt-3">
                                    {options.map(option => {
                                      // Get appropriate class based on selection state
                                      const className = getOptionClassName(
                                        option.letter, 
                                        question.userSelectedOption?.toString() || undefined, 
                                        question.correctOption?.toString() || undefined,
                                        // Always show correct/incorrect after user has selected an option
                                        question.userSelectedOption !== undefined && question.userSelectedOption !== null
                                      );
                                      
                                      return (
                                        <button 
                                          key={option.letter}
                                          className={className}
                                          onClick={() => {
                                            // Only allow answering if not already answered
                                            if (!question.userSelectedOption) {
                                              answerQuestionMutation.mutate({
                                                questionId: question.id,
                                                selectedOption: option.letter
                                              });
                                            }
                                          }}
                                          disabled={question.userSelectedOption !== undefined}
                                        >
                                          <div className="mr-2 w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-xs font-medium">
                                            {option.letter}
                                          </div>
                                          <div className="text-sm text-left">{option.text}</div>
                                        </button>
                                      );
                                    })}
                                  </div>
                                );
                              } else {
                                // Regular question (not multiple choice)
                                return (
                                  <div className="mt-2 text-sm text-gray-600">
                                    <p>{question.answer}</p>
                                  </div>
                                );
                              }
                            })()}
                          </>
                        )}
                        
                        {question.reference && (
                          <div className="mt-2 text-xs text-gray-500">
                            <strong>Reference:</strong> {question.reference}
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col items-end">
                        <div className="text-xs text-gray-500">
                          {question.createdAt && formatRelativeTime(new Date(question.createdAt))}
                        </div>
                        <div className="mt-2 flex space-x-1">
                          <button 
                            onClick={() => {
                              setSelectedQuestion(question);
                              setIsEditQuestionModalOpen(true);
                            }}
                            className="p-1 text-gray-400 hover:text-primary-500"
                            title="Edit question"
                          >
                            <i className="ri-edit-line"></i>
                          </button>
                          <button 
                            onClick={() => {
                              setSelectedQuestion(question);
                              setIsAddFlashcardModalOpen(true);
                            }}
                            className="p-1 text-gray-400 hover:text-accent-500"
                            title="Create flashcard"
                          >
                            <i className="ri-flashcard-line"></i>
                          </button>
                          <button 
                            onClick={() => {
                              setSelectedQuestion(question);
                              setIsDeleteAlertOpen(true);
                            }}
                            className="p-1 text-gray-400 hover:text-red-500"
                            title="Delete question"
                          >
                            <i className="ri-delete-bin-line"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between items-center">
                      <div className="flex items-center space-x-2 text-sm">
                        <i className="ri-time-line text-gray-400"></i>
                        <span className="text-gray-500">
                          {question.lastReviewedAt 
                            ? `Last reviewed: ${formatRelativeTime(new Date(question.lastReviewedAt))}`
                            : 'Last reviewed: Never'
                          }
                        </span>
                      </div>
                      <div className="flex space-x-2">
                        <button 
                          onClick={() => handleReview(question.id, false)}
                          className="bg-red-100 text-red-600 px-3 py-1.5 rounded text-sm hover:bg-red-200"
                        >
                          Struggled
                        </button>
                        <button 
                          onClick={() => handleReview(question.id, true)}
                          className="bg-green-100 text-green-600 px-3 py-1.5 rounded text-sm hover:bg-green-200"
                        >
                          Knew it
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>
      
      <AddQuestionModal 
        isOpen={isAddQuestionModalOpen} 
        onClose={() => setIsAddQuestionModalOpen(false)} 
      />
      
      <EditQuestionModal
        isOpen={isEditQuestionModalOpen}
        onClose={() => {
          setIsEditQuestionModalOpen(false);
          setSelectedQuestion(null);
        }}
        question={selectedQuestion}
      />
      
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete this question
              and remove it from your collection.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel
              onClick={() => {
                setIsDeleteAlertOpen(false);
                setSelectedQuestion(null);
              }}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (selectedQuestion) {
                  deleteQuestionMutation.mutate(selectedQuestion.id);
                }
              }}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
            >
              {deleteQuestionMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <AddFlashcardModal
        isOpen={isAddFlashcardModalOpen}
        onClose={() => {
          setIsAddFlashcardModalOpen(false);
          setSelectedQuestion(null);
        }}
        initialQuestion={selectedQuestion}
      />
      
      <ImportQuestionsModal
        isOpen={isImportQuestionsModalOpen}
        onClose={() => setIsImportQuestionsModalOpen(false)}
      />
      
      {isPdfViewerOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-6xl">
            <PDFViewer 
              pdfUrl={viewingPdfUrl} 
              onClose={() => setIsPdfViewerOpen(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}
