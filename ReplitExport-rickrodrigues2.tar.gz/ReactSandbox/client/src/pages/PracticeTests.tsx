import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useQuery } from '@tanstack/react-query';
import { PracticeTest, Question } from '@shared/schema';
import { formatRelativeTime } from '@/utils/formatTime';
import Header from '@/components/Header';
import Navigation from '@/components/Navigation';
import TestItem from '@/components/practiceTests/TestItem';
import CreateTestModal from '@/components/practiceTests/CreateTestModal';
import { Button } from '@/components/ui/button';

export default function PracticeTests() {
  const { user } = useUser();
  const [isCreateTestModalOpen, setIsCreateTestModalOpen] = useState(false);
  const [activeTest, setActiveTest] = useState<PracticeTest | null>(null);
  const [testInProgress, setTestInProgress] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<{ [key: number]: boolean }>({});
  
  // Fetch practice tests
  const { data: practiceTests = [], isLoading } = useQuery<PracticeTest[]>({
    queryKey: ['/api/practice-tests', user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/practice-tests?userId=${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch practice tests');
      return res.json();
    },
    enabled: !!user?.id
  });
  
  // Fetch questions for the selected test
  const { data: testQuestions = [], isLoading: isLoadingQuestions } = useQuery<Question[]>({
    queryKey: ['/api/questions', activeTest?.questions],
    queryFn: async () => {
      // In a real implementation, we would fetch the specific questions
      // Here we're getting all questions and filtering the ones in the test
      const res = await fetch(`/api/questions?userId=${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch questions');
      const allQuestions = await res.json();
      
      return activeTest?.questions 
        ? allQuestions.filter((q: Question) => activeTest.questions.includes(q.id))
        : [];
    },
    enabled: !!activeTest && !!user?.id
  });
  
  const handleStartTest = (test: PracticeTest) => {
    setActiveTest(test);
    setTestInProgress(true);
    setCurrentQuestionIndex(0);
    setUserAnswers({});
  };
  
  const handleEndTest = () => {
    // Calculate score
    const totalQuestions = testQuestions.length;
    const correctAnswers = Object.values(userAnswers).filter(a => a).length;
    const score = Math.round((correctAnswers / totalQuestions) * 100);
    
    // In a real implementation, we would save the test results
    // For now, just show the completed test
    setTestInProgress(false);
    setActiveTest(null);
  };
  
  const handleNextQuestion = (knewAnswer: boolean) => {
    if (!activeTest || !testQuestions[currentQuestionIndex]) return;
    
    // Save the user's answer
    setUserAnswers({
      ...userAnswers,
      [testQuestions[currentQuestionIndex].id]: knewAnswer
    });
    
    // Move to the next question or end the test
    if (currentQuestionIndex < testQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      handleEndTest();
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Navigation />
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 mb-6">
          {!testInProgress ? (
            <>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 space-y-4 md:space-y-0">
                <h2 className="text-xl font-semibold">Practice Tests</h2>
                <Button onClick={() => setIsCreateTestModalOpen(true)}>
                  <i className="ri-add-line mr-2"></i>
                  Create New Test
                </Button>
              </div>
              
              {isLoading ? (
                <div className="py-8 text-center text-gray-500">Loading practice tests...</div>
              ) : practiceTests.length === 0 ? (
                <div className="py-8 text-center text-gray-500">
                  <p>No practice tests found.</p>
                  <p className="mt-2 text-sm">
                    Create your first practice test to start practicing for the PNA exam.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {practiceTests.map(test => (
                    <TestItem 
                      key={test.id} 
                      test={test} 
                      onStartTest={() => handleStartTest(test)}
                    />
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="py-4">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">
                  {activeTest?.name || 'Practice Test'}
                </h2>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-500">
                    Question {currentQuestionIndex + 1} of {testQuestions.length}
                  </span>
                  <Button variant="outline" onClick={handleEndTest}>
                    End Test
                  </Button>
                </div>
              </div>
              
              {isLoadingQuestions ? (
                <div className="py-8 text-center text-gray-500">Loading questions...</div>
              ) : testQuestions.length === 0 ? (
                <div className="py-8 text-center text-gray-500">
                  <p>No questions found for this test.</p>
                </div>
              ) : (
                <div className="bg-accent-50 border border-accent-200 rounded-lg p-6">
                  <div className="mb-6">
                    <h3 className="text-xl font-medium text-gray-800">
                      {testQuestions[currentQuestionIndex]?.question}
                    </h3>
                  </div>
                  
                  <div className="bg-white border border-accent-200 rounded-lg p-4 mb-6">
                    <p>{testQuestions[currentQuestionIndex]?.answer}</p>
                  </div>
                  
                  <div className="flex justify-end space-x-3">
                    <Button 
                      variant="outline" 
                      className="bg-red-100 hover:bg-red-200 text-red-700 border-red-300"
                      onClick={() => handleNextQuestion(false)}
                    >
                      I was wrong
                    </Button>
                    <Button 
                      variant="outline"
                      className="bg-green-100 hover:bg-green-200 text-green-700 border-green-300"
                      onClick={() => handleNextQuestion(true)}
                    >
                      I knew it
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      
      <CreateTestModal 
        isOpen={isCreateTestModalOpen} 
        onClose={() => setIsCreateTestModalOpen(false)} 
      />
    </div>
  );
}
