import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useQuery } from '@tanstack/react-query';
import { Specialty, StudySession, QuestionReview } from '@shared/schema';
import Header from '@/components/Header';
import Navigation from '@/components/Navigation';
import PerformanceChart from '@/components/analytics/PerformanceChart';
import StudyTimeChart from '@/components/analytics/StudyTimeChart';
import { formatTimeHuman } from '@/utils/formatTime';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Analytics() {
  const { user } = useUser();
  const [timeRange, setTimeRange] = useState('7'); // 7 days, 30 days, 90 days
  
  // Fetch specialties
  const { data: specialties = [] } = useQuery<Specialty[]>({
    queryKey: ['/api/specialties'],
    enabled: !!user
  });
  
  // Fetch performance by specialty
  const { data: specialtyPerformance = [], isLoading: isLoadingPerformance } = useQuery<
    { specialtyId: number; accuracy: number }[]
  >({
    queryKey: ['/api/performance/by-specialty', user?.id],
    enabled: !!user?.id
  });
  
  // Fetch overall performance
  const { data: overallPerformance, isLoading: isLoadingOverall } = useQuery<{ accuracy: number }>({
    queryKey: ['/api/performance/overall', user?.id],
    enabled: !!user?.id
  });
  
  // Fetch study sessions
  const { data: studySessions = [], isLoading: isLoadingStudySessions } = useQuery<StudySession[]>({
    queryKey: ['/api/study-sessions', user?.id],
    queryFn: async () => {
      // In a full implementation, we would fetch the study sessions with date filtering
      // For now, we'll simulate this by fetching all sessions
      const res = await fetch(`/api/study-sessions?userId=${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch study sessions');
      return res.json();
    },
    enabled: !!user?.id
  });
  
  // Calculate total study time
  const totalStudyTime = studySessions.reduce((total, session) => {
    return total + (session.duration || 0);
  }, 0);
  
  // Get specialty name by ID
  const getSpecialtyName = (id: number) => {
    const specialty = specialties.find(s => s.id === id);
    return specialty?.name || 'Unknown';
  };
  
  // Calculate study time by specialty
  const studyTimeBySpecialty = studySessions.reduce<{ [key: number]: number }>((acc, session) => {
    if (!session.specialtyId || !session.duration) return acc;
    
    if (!acc[session.specialtyId]) {
      acc[session.specialtyId] = 0;
    }
    
    acc[session.specialtyId] += session.duration;
    return acc;
  }, {});
  
  // Filter data based on time range
  const filterDataByTimeRange = (data: any[]) => {
    const daysAgo = parseInt(timeRange);
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysAgo);
    
    return data.filter(item => {
      const itemDate = new Date(item.createdAt || item.startTime);
      return itemDate >= cutoffDate;
    });
  };
  
  const filteredStudySessions = filterDataByTimeRange(studySessions);
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Navigation />
        
        <div className="mb-6 flex justify-between items-center">
          <h1 className="text-2xl font-semibold">Analytics & Insights</h1>
          
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">Time range:</span>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Select range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="365">Last year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Overall Performance</CardTitle>
              <CardDescription>Your answer accuracy rate</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingOverall ? (
                <div className="h-20 flex items-center justify-center">
                  <p className="text-gray-500">Loading...</p>
                </div>
              ) : (
                <div className="flex items-center">
                  <span className="text-4xl font-semibold text-primary-600">
                    {overallPerformance?.accuracy || 0}%
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Study Time</CardTitle>
              <CardDescription>Time invested in your education</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingStudySessions ? (
                <div className="h-20 flex items-center justify-center">
                  <p className="text-gray-500">Loading...</p>
                </div>
              ) : (
                <div className="flex items-center">
                  <span className="text-4xl font-semibold text-primary-600">
                    {formatTimeHuman(totalStudyTime)}
                  </span>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Questions Reviewed</CardTitle>
              <CardDescription>Total practice questions reviewed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <span className="text-4xl font-semibold text-primary-600">
                  {/* This would come from question reviews in a full implementation */}
                  {Math.floor(Math.random() * 100) + 50}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance by Specialty</CardTitle>
              <CardDescription>How well you know each medical specialty</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingPerformance ? (
                <div className="h-60 flex items-center justify-center">
                  <p className="text-gray-500">Loading performance data...</p>
                </div>
              ) : specialtyPerformance.length === 0 ? (
                <div className="h-60 flex items-center justify-center">
                  <p className="text-gray-500">No performance data available</p>
                </div>
              ) : (
                <PerformanceChart 
                  data={specialtyPerformance.map(perf => ({
                    name: getSpecialtyName(perf.specialtyId),
                    value: perf.accuracy
                  }))} 
                />
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Study Time Distribution</CardTitle>
              <CardDescription>Where you've focused your study time</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingStudySessions ? (
                <div className="h-60 flex items-center justify-center">
                  <p className="text-gray-500">Loading study data...</p>
                </div>
              ) : filteredStudySessions.length === 0 ? (
                <div className="h-60 flex items-center justify-center">
                  <p className="text-gray-500">No study data available for this period</p>
                </div>
              ) : (
                <StudyTimeChart 
                  data={Object.entries(studyTimeBySpecialty).map(([specialtyId, duration]) => ({
                    name: getSpecialtyName(parseInt(specialtyId)),
                    value: duration / 3600 // Convert to hours
                  }))} 
                />
              )}
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Study Session History</CardTitle>
              <CardDescription>Your recent study activity</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingStudySessions ? (
                <div className="h-20 flex items-center justify-center">
                  <p className="text-gray-500">Loading session history...</p>
                </div>
              ) : filteredStudySessions.length === 0 ? (
                <div className="h-20 flex items-center justify-center">
                  <p className="text-gray-500">No study sessions found for this period</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full table-auto">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-4 font-medium text-gray-700">Date</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-700">Specialty</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-700">Focus</th>
                        <th className="text-left py-3 px-4 font-medium text-gray-700">Duration</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredStudySessions.map(session => (
                        <tr key={session.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-4">
                            {new Date(session.startTime).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4">
                            {session.specialtyId ? getSpecialtyName(session.specialtyId) : 'General'}
                          </td>
                          <td className="py-3 px-4">{session.focus || 'Not specified'}</td>
                          <td className="py-3 px-4">
                            {session.duration ? formatTimeHuman(session.duration) : 'In progress'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
