import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useUser } from '@/contexts/UserContext';
import { useLanguage } from '@/contexts/LanguageContext';

import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { Loader2, Plus, Trash2, Edit, AlertTriangle, CheckCircle, Download } from 'lucide-react';

type AnswerKey = {
  id: number;
  userId: number;
  year: number;
  examVersion: string;
  answers: {
    questionNumber: number;
    correctOption: string;
  }[];
  source: string;
  createdAt: string;
};

const AnswerKeys: React.FC = () => {
  const { user } = useUser();
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [isEditSheetOpen, setIsEditSheetOpen] = useState(false);
  const [selectedAnswerKey, setSelectedAnswerKey] = useState<AnswerKey | null>(null);
  
  // Define form schemas
  const answerKeyFormSchema = z.object({
    year: z.coerce.number().min(2000, { message: t('gabaritos.yearMinError') }).max(2100, { message: t('gabaritos.yearMaxError') }),
    examVersion: z.string().min(1, { message: t('gabaritos.versionError') }),
    source: z.string().min(1, { message: t('gabaritos.sourceError') }),
    answers: z.array(
      z.object({
        questionNumber: z.coerce.number().min(1, { message: t('gabaritos.questionNumberError') }),
        correctOption: z.string().min(1, { message: t('gabaritos.optionError') }).max(1, { message: t('gabaritos.optionMaxError') })
      })
    ),
  });

  const importFormSchema = z.object({
    year: z.coerce.number().min(2000, { message: t('gabaritos.yearMinError') }).max(2100, { message: t('gabaritos.yearMaxError') }),
    examVersion: z.string().min(1, { message: t('gabaritos.versionError') }),
    source: z.string().min(1, { message: t('gabaritos.sourceError') }),
    answersText: z.string().min(10, { message: t('gabaritos.answersTextError') }),
  });

  // Forms setup
  const addForm = useForm<z.infer<typeof answerKeyFormSchema>>({
    resolver: zodResolver(answerKeyFormSchema),
    defaultValues: {
      year: new Date().getFullYear(),
      examVersion: 'A',
      source: 'Oficial',
      answers: [{ questionNumber: 1, correctOption: '' }]
    },
  });

  const editForm = useForm<z.infer<typeof answerKeyFormSchema>>({
    resolver: zodResolver(answerKeyFormSchema),
    defaultValues: {
      year: new Date().getFullYear(),
      examVersion: 'A',
      source: 'Oficial',
      answers: [{ questionNumber: 1, correctOption: '' }]
    },
  });

  const importForm = useForm<z.infer<typeof importFormSchema>>({
    resolver: zodResolver(importFormSchema),
    defaultValues: {
      year: new Date().getFullYear(),
      examVersion: 'A',
      source: 'Oficial',
      answersText: '',
    },
  });

  // Mutations and queries
  const { data: answerKeys, isLoading: isLoadingAnswerKeys } = useQuery({
    queryKey: ['/api/answer-keys', user?.id],
    queryFn: () => apiRequest<AnswerKey[]>(`/api/answer-keys?userId=${user?.id}`, { method: 'GET' }),
    enabled: !!user,
  });

  const createAnswerKeyMutation = useMutation({
    mutationFn: (data: z.infer<typeof answerKeyFormSchema>) => {
      return apiRequest<AnswerKey>('/api/answer-keys', {
        method: 'POST',
        data: {
          userId: user?.id,
          year: data.year,
          examVersion: data.examVersion,
          source: data.source,
          answers: data.answers,
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/answer-keys'] });
      setIsAddDialogOpen(false);
      addForm.reset();
      toast({
        title: t('gabaritos.addSuccess'),
        description: t('gabaritos.addSuccessDesc'),
      });
    },
    onError: (error: any) => {
      toast({
        title: t('gabaritos.addError'),
        description: error.message || t('gabaritos.addErrorDesc'),
        variant: 'destructive',
      });
    },
  });

  const updateAnswerKeyMutation = useMutation({
    mutationFn: (data: { id: number, answerKey: z.infer<typeof answerKeyFormSchema> }) => {
      return apiRequest<AnswerKey>(`/api/answer-keys/${data.id}`, {
        method: 'PUT',
        data: {
          year: data.answerKey.year,
          examVersion: data.answerKey.examVersion,
          source: data.answerKey.source,
          answers: data.answerKey.answers,
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/answer-keys'] });
      setIsEditSheetOpen(false);
      setSelectedAnswerKey(null);
      toast({
        title: t('gabaritos.updateSuccess'),
        description: t('gabaritos.updateSuccessDesc'),
      });
    },
    onError: (error: any) => {
      toast({
        title: t('gabaritos.updateError'),
        description: error.message || t('gabaritos.updateErrorDesc'),
        variant: 'destructive',
      });
    },
  });

  const deleteAnswerKeyMutation = useMutation({
    mutationFn: (id: number) => {
      return apiRequest(`/api/answer-keys/${id}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/answer-keys'] });
      toast({
        title: t('gabaritos.deleteSuccess'),
        description: t('gabaritos.deleteSuccessDesc'),
      });
    },
    onError: (error: any) => {
      toast({
        title: t('gabaritos.deleteError'),
        description: error.message || t('gabaritos.deleteErrorDesc'),
        variant: 'destructive',
      });
    },
  });

  // Event handlers
  const onAddAnswerKey = (data: z.infer<typeof answerKeyFormSchema>) => {
    createAnswerKeyMutation.mutate(data);
  };

  const onEditAnswerKey = (data: z.infer<typeof answerKeyFormSchema>) => {
    if (selectedAnswerKey) {
      updateAnswerKeyMutation.mutate({
        id: selectedAnswerKey.id,
        answerKey: data,
      });
    }
  };

  const onDeleteAnswerKey = (id: number) => {
    if (confirm(t('gabaritos.confirmDelete'))) {
      deleteAnswerKeyMutation.mutate(id);
    }
  };

  const onImportAnswers = (data: z.infer<typeof importFormSchema>) => {
    // Parse the answersText into the expected array format
    try {
      // Example format for parsing: "1:A, 2:B, 3:C" or "1-A, 2-B, 3-C"
      const parsedAnswers = data.answersText
        .split(/[,;\n]/)
        .map(answer => answer.trim())
        .filter(answer => answer)
        .map(answer => {
          // Support multiple formats: "1:A", "1-A", "1. A", "1) A"
          const match = answer.match(/(\d+)[:.\-)\s]+\s*([A-E])/i);
          if (!match) {
            throw new Error(`${t('gabaritos.parseError')}: ${answer}`);
          }
          return {
            questionNumber: parseInt(match[1], 10),
            correctOption: match[2].toUpperCase(),
          };
        });
      
      // Create answer key with parsed answers
      createAnswerKeyMutation.mutate({
        year: data.year,
        examVersion: data.examVersion,
        source: data.source,
        answers: parsedAnswers,
      });
      
      setIsImportDialogOpen(false);
      importForm.reset();
    } catch (error: any) {
      toast({
        title: t('gabaritos.importError'),
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  const handleEditAnswerKey = (answerKey: AnswerKey) => {
    setSelectedAnswerKey(answerKey);
    editForm.reset({
      year: answerKey.year,
      examVersion: answerKey.examVersion,
      source: answerKey.source,
      answers: answerKey.answers,
    });
    setIsEditSheetOpen(true);
  };

  // Helper functions
  const addAnswerField = () => {
    const currentAnswers = addForm.getValues('answers');
    const lastQuestionNumber = currentAnswers.length > 0 
      ? currentAnswers[currentAnswers.length - 1].questionNumber 
      : 0;
      
    addForm.setValue('answers', [
      ...currentAnswers,
      { questionNumber: lastQuestionNumber + 1, correctOption: '' }
    ]);
  };

  const addEditAnswerField = () => {
    const currentAnswers = editForm.getValues('answers');
    const lastQuestionNumber = currentAnswers.length > 0 
      ? currentAnswers[currentAnswers.length - 1].questionNumber 
      : 0;
      
    editForm.setValue('answers', [
      ...currentAnswers,
      { questionNumber: lastQuestionNumber + 1, correctOption: '' }
    ]);
  };

  const removeAnswerField = (index: number) => {
    const currentAnswers = addForm.getValues('answers');
    addForm.setValue('answers', currentAnswers.filter((_, i) => i !== index));
  };

  const removeEditAnswerField = (index: number) => {
    const currentAnswers = editForm.getValues('answers');
    editForm.setValue('answers', currentAnswers.filter((_, i) => i !== index));
  };

  const exportAnswerKeyAsCsv = (answerKey: AnswerKey) => {
    // Create CSV content
    const headers = "Question Number,Correct Option";
    const rows = answerKey.answers
      .map(a => `${a.questionNumber},${a.correctOption}`)
      .join('\n');
    const csvContent = `${headers}\n${rows}`;
    
    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `pna_${answerKey.year}_${answerKey.examVersion}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Organize answer keys by year
  const answerKeysByYear = answerKeys?.reduce<Record<number, AnswerKey[]>>((acc, answerKey) => {
    if (!acc[answerKey.year]) {
      acc[answerKey.year] = [];
    }
    acc[answerKey.year].push(answerKey);
    return acc;
  }, {}) || {};

  // Sort years in descending order
  const sortedYears = Object.keys(answerKeysByYear)
    .map(year => parseInt(year, 10))
    .sort((a, b) => b - a);

  return (
    <div className="container py-10">
      <div className="mb-8 space-y-4">
        <h1 className="text-3xl font-bold tracking-tight">{t('gabaritos.title')}</h1>
        <p className="text-muted-foreground">{t('gabaritos.description')}</p>
        
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" /> {t('gabaritos.addButton')}
          </Button>
          <Button variant="outline" onClick={() => setIsImportDialogOpen(true)}>
            <Download className="mr-2 h-4 w-4" /> {t('gabaritos.importButton')}
          </Button>
        </div>
      </div>

      {isLoadingAnswerKeys ? (
        <div className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : sortedYears.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle>{t('gabaritos.noData')}</CardTitle>
            <CardDescription>{t('gabaritos.noDataDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" /> {t('gabaritos.addFirstButton')}
            </Button>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue={sortedYears[0]?.toString()} className="w-full">
          <TabsList className="mb-4 flex flex-wrap w-full">
            {sortedYears.map(year => (
              <TabsTrigger key={year} value={year.toString()} className="px-4">
                {year}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {sortedYears.map(year => (
            <TabsContent key={year} value={year.toString()}>
              <Card>
                <CardHeader>
                  <CardTitle>{t('gabaritos.yearHeader', { year })}</CardTitle>
                  <CardDescription>
                    {t('gabaritos.yearDescription')}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t('gabaritos.version')}</TableHead>
                        <TableHead>{t('gabaritos.source')}</TableHead>
                        <TableHead>{t('gabaritos.questionCount')}</TableHead>
                        <TableHead>{t('gabaritos.createdAt')}</TableHead>
                        <TableHead className="text-right">{t('gabaritos.actions')}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {answerKeysByYear[year].map((answerKey) => (
                        <TableRow key={answerKey.id}>
                          <TableCell className="font-medium">{answerKey.examVersion}</TableCell>
                          <TableCell>{answerKey.source}</TableCell>
                          <TableCell>{answerKey.answers.length}</TableCell>
                          <TableCell>{new Date(answerKey.createdAt).toLocaleDateString()}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => handleEditAnswerKey(answerKey)}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => exportAnswerKeyAsCsv(answerKey)}
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="destructive" 
                                size="sm"
                                onClick={() => onDeleteAnswerKey(answerKey.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      )}

      {/* Add Answer Key Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{t('gabaritos.addDialogTitle')}</DialogTitle>
            <DialogDescription>
              {t('gabaritos.addDialogDescription')}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...addForm}>
            <form onSubmit={addForm.handleSubmit(onAddAnswerKey)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={addForm.control}
                  name="year"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('gabaritos.year')}</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="2023" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addForm.control}
                  name="examVersion"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('gabaritos.version')}</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t('gabaritos.selectVersion')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="A">A</SelectItem>
                          <SelectItem value="B">B</SelectItem>
                          <SelectItem value="C">C</SelectItem>
                          <SelectItem value="D">D</SelectItem>
                          <SelectItem value="E">E</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={addForm.control}
                  name="source"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('gabaritos.source')}</FormLabel>
                      <FormControl>
                        <Input placeholder={t('gabaritos.sourcePlaceholder')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">{t('gabaritos.answers')}</h3>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={addAnswerField}
                  >
                    <Plus className="h-4 w-4 mr-1" /> {t('gabaritos.addAnswer')}
                  </Button>
                </div>
                
                <div className="space-y-2">
                  {addForm.watch('answers').map((_, index) => (
                    <div key={index} className="flex items-end gap-2">
                      <FormField
                        control={addForm.control}
                        name={`answers.${index}.questionNumber`}
                        render={({ field }) => (
                          <FormItem className="flex-1">
                            <FormLabel>{t('gabaritos.questionNumber')}</FormLabel>
                            <FormControl>
                              <Input type="number" min="1" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={addForm.control}
                        name={`answers.${index}.correctOption`}
                        render={({ field }) => (
                          <FormItem className="w-28">
                            <FormLabel>{t('gabaritos.option')}</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="A">A</SelectItem>
                                <SelectItem value="B">B</SelectItem>
                                <SelectItem value="C">C</SelectItem>
                                <SelectItem value="D">D</SelectItem>
                                <SelectItem value="E">E</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="button"
                        variant="ghost" 
                        className="mb-2"
                        onClick={() => removeAnswerField(index)}
                        disabled={addForm.watch('answers').length <= 1}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsAddDialogOpen(false)}
                >
                  {t('cancel')}
                </Button>
                <Button 
                  type="submit" 
                  disabled={createAnswerKeyMutation.isPending}
                >
                  {createAnswerKeyMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t('saving')}
                    </>
                  ) : (
                    t('save')
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Answer Key Sheet */}
      <Sheet open={isEditSheetOpen} onOpenChange={setIsEditSheetOpen}>
        <SheetContent className="sm:max-w-3xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle>{t('gabaritos.editTitle')}</SheetTitle>
            <SheetDescription>
              {t('gabaritos.editDescription')}
            </SheetDescription>
          </SheetHeader>
          
          {selectedAnswerKey && (
            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(onEditAnswerKey)} className="space-y-6 py-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={editForm.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('gabaritos.year')}</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="2023" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="examVersion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('gabaritos.version')}</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={t('gabaritos.selectVersion')} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="A">A</SelectItem>
                            <SelectItem value="B">B</SelectItem>
                            <SelectItem value="C">C</SelectItem>
                            <SelectItem value="D">D</SelectItem>
                            <SelectItem value="E">E</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={editForm.control}
                    name="source"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('gabaritos.source')}</FormLabel>
                        <FormControl>
                          <Input placeholder={t('gabaritos.sourcePlaceholder')} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">{t('gabaritos.answers')}</h3>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={addEditAnswerField}
                    >
                      <Plus className="h-4 w-4 mr-1" /> {t('gabaritos.addAnswer')}
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    {editForm.watch('answers').map((_, index) => (
                      <div key={index} className="flex items-end gap-2">
                        <FormField
                          control={editForm.control}
                          name={`answers.${index}.questionNumber`}
                          render={({ field }) => (
                            <FormItem className="flex-1">
                              <FormLabel>{t('gabaritos.questionNumber')}</FormLabel>
                              <FormControl>
                                <Input type="number" min="1" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={editForm.control}
                          name={`answers.${index}.correctOption`}
                          render={({ field }) => (
                            <FormItem className="w-28">
                              <FormLabel>{t('gabaritos.option')}</FormLabel>
                              <Select 
                                onValueChange={field.onChange} 
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="A">A</SelectItem>
                                  <SelectItem value="B">B</SelectItem>
                                  <SelectItem value="C">C</SelectItem>
                                  <SelectItem value="D">D</SelectItem>
                                  <SelectItem value="E">E</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button 
                          type="button"
                          variant="ghost" 
                          className="mb-2"
                          onClick={() => removeEditAnswerField(index)}
                          disabled={editForm.watch('answers').length <= 1}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
                
                <SheetFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setIsEditSheetOpen(false)}
                  >
                    {t('cancel')}
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={updateAnswerKeyMutation.isPending}
                  >
                    {updateAnswerKeyMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {t('updating')}
                      </>
                    ) : (
                      t('update')
                    )}
                  </Button>
                </SheetFooter>
              </form>
            </Form>
          )}
        </SheetContent>
      </Sheet>

      {/* Import Answers Dialog */}
      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('gabaritos.importTitle')}</DialogTitle>
            <DialogDescription>
              {t('gabaritos.importDescription')}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...importForm}>
            <form onSubmit={importForm.handleSubmit(onImportAnswers)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={importForm.control}
                  name="year"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('gabaritos.year')}</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="2023" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={importForm.control}
                  name="examVersion"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('gabaritos.version')}</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t('gabaritos.selectVersion')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="A">A</SelectItem>
                          <SelectItem value="B">B</SelectItem>
                          <SelectItem value="C">C</SelectItem>
                          <SelectItem value="D">D</SelectItem>
                          <SelectItem value="E">E</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={importForm.control}
                  name="source"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('gabaritos.source')}</FormLabel>
                      <FormControl>
                        <Input placeholder={t('gabaritos.sourcePlaceholder')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={importForm.control}
                name="answersText"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('gabaritos.answersText')}</FormLabel>
                    <FormControl>
                      <textarea
                        className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder={t('gabaritos.answersTextPlaceholder')}
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      {t('gabaritos.answersTextHelper')}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsImportDialogOpen(false)}
                >
                  {t('cancel')}
                </Button>
                <Button 
                  type="submit" 
                  disabled={createAnswerKeyMutation.isPending}
                >
                  {createAnswerKeyMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t('importing')}
                    </>
                  ) : (
                    t('gabaritos.importButton')
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AnswerKeys;