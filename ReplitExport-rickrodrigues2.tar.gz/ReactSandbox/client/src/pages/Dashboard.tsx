import { useState } from 'react';
import Header from '@/components/Header';
import Navigation from '@/components/Navigation';
import StudyTimer from '@/components/StudyTimer';
import RecentQuestions from '@/components/RecentQuestions';
import QuickReview from '@/components/QuickReview';
import PerformanceOverview from '@/components/PerformanceOverview';
import StudyRecommendations from '@/components/StudyRecommendations';
import QuickActions from '@/components/QuickActions';
import AddQuestionModal from '@/components/AddQuestionModal';

export default function Dashboard() {
  const [isAddQuestionModalOpen, setIsAddQuestionModalOpen] = useState(false);
  
  const handleAddQuestion = () => {
    setIsAddQuestionModalOpen(true);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Navigation />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <StudyTimer />
            <RecentQuestions onAddQuestion={handleAddQuestion} />
            <QuickReview />
          </div>
          
          <div className="space-y-6">
            <PerformanceOverview />
            <StudyRecommendations />
            <QuickActions onAddQuestion={handleAddQuestion} />
          </div>
        </div>
      </main>
      
      <AddQuestionModal 
        isOpen={isAddQuestionModalOpen} 
        onClose={() => setIsAddQuestionModalOpen(false)} 
      />
    </div>
  );
}
