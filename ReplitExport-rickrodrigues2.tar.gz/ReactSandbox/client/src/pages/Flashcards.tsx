import { useState } from 'react';
import { useUser } from '@/contexts/UserContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Flashcard, Specialty } from '@shared/schema';
import { formatRelativeTime } from '@/utils/formatTime';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/Header';
import Navigation from '@/components/Navigation';
import FlashcardItem from '@/components/flashcards/FlashcardItem';
import AddFlashcardModal from '@/components/flashcards/AddFlashcardModal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Flashcards() {
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddFlashcardModalOpen, setIsAddFlashcardModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [reviewMode, setReviewMode] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Fetch flashcards
  const { data: flashcards = [], isLoading } = useQuery<Flashcard[]>({
    queryKey: ['/api/flashcards', user?.id],
    queryFn: async () => {
      const res = await fetch(`/api/flashcards?userId=${user?.id}`);
      if (!res.ok) throw new Error('Failed to fetch flashcards');
      return res.json();
    },
    enabled: !!user?.id
  });
  
  // Filter flashcards
  const filteredFlashcards = flashcards.filter(flashcard => {
    return (
      flashcard.front.toLowerCase().includes(searchTerm.toLowerCase()) ||
      flashcard.back.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });
  
  // Update flashcard mutation
  const updateFlashcardMutation = useMutation({
    mutationFn: async ({ id, reviewCount }: { id: number, reviewCount: number }) => {
      return apiRequest('PUT', `/api/flashcards/${id}`, {
        reviewCount,
        lastReviewedAt: new Date()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/flashcards', user?.id] });
    }
  });
  
  const handleStartReview = () => {
    if (filteredFlashcards.length === 0) {
      toast({
        title: "No flashcards",
        description: "Add flashcards first to start reviewing",
        variant: "destructive"
      });
      return;
    }
    
    setReviewMode(true);
    setCurrentIndex(0);
  };
  
  const handleEndReview = () => {
    setReviewMode(false);
  };
  
  const handleNextCard = () => {
    if (currentIndex < filteredFlashcards.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      toast({
        title: "Review completed",
        description: "You've reviewed all flashcards",
      });
      setReviewMode(false);
    }
  };
  
  const handleMarkReviewed = async (id: number, currentReviewCount: number) => {
    try {
      await updateFlashcardMutation.mutateAsync({ 
        id, 
        reviewCount: currentReviewCount + 1
      });
      
      handleNextCard();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update flashcard",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-6">
        <Navigation />
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 mb-6">
          {!reviewMode ? (
            <>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 space-y-4 md:space-y-0">
                <h2 className="text-xl font-semibold">Flashcards</h2>
                <div className="flex space-x-2">
                  <Button variant="outline" onClick={handleStartReview}>
                    <i className="ri-play-line mr-2"></i>
                    Start Review
                  </Button>
                  <Button onClick={() => setIsAddFlashcardModalOpen(true)}>
                    <i className="ri-add-line mr-2"></i>
                    Add Flashcard
                  </Button>
                </div>
              </div>
              
              <div className="mb-4">
                <Input
                  placeholder="Search flashcards..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full md:w-1/3"
                />
              </div>
              
              {isLoading ? (
                <div className="py-8 text-center text-gray-500">Loading flashcards...</div>
              ) : filteredFlashcards.length === 0 ? (
                <div className="py-8 text-center text-gray-500">
                  <p>No flashcards found.</p>
                  <p className="mt-2 text-sm">
                    {flashcards.length === 0 
                      ? "Add your first flashcard to start studying." 
                      : "Try changing your search filter."}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredFlashcards.map(flashcard => (
                    <FlashcardItem 
                      key={flashcard.id} 
                      flashcard={flashcard} 
                      onMarkReviewed={() => {}}
                      inReviewMode={false}
                    />
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="py-4">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">Flashcard Review</h2>
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-500">
                    {currentIndex + 1} of {filteredFlashcards.length}
                  </span>
                  <Button variant="outline" onClick={handleEndReview}>
                    End Review
                  </Button>
                </div>
              </div>
              
              {filteredFlashcards.length > 0 && (
                <div className="flex justify-center">
                  <div className="w-full max-w-xl">
                    <FlashcardItem 
                      flashcard={filteredFlashcards[currentIndex]} 
                      onMarkReviewed={() => handleMarkReviewed(
                        filteredFlashcards[currentIndex].id,
                        filteredFlashcards[currentIndex].reviewCount
                      )}
                      inReviewMode={true}
                    />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      
      <AddFlashcardModal 
        isOpen={isAddFlashcardModalOpen} 
        onClose={() => setIsAddFlashcardModalOpen(false)} 
      />
    </div>
  );
}
