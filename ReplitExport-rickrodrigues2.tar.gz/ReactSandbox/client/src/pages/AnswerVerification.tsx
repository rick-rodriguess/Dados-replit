import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useUser } from '@/contexts/UserContext';
import { useLanguage } from '@/contexts/LanguageContext';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Loader2, AlertTriangle, CheckCircle, Sparkles, RefreshCw, FileQuestion } from 'lucide-react';

type Question = {
  id: number;
  userId: number;
  specialtyId: number;
  question: string;
  answer: string;
  difficulty: string;
  reference?: string;
  createdAt: string;
  lastReviewedAt?: string;
  reviewCount: number;
  isKnown: boolean;
  isMultipleChoice: boolean;
  correctOption?: string;
  userSelectedOption?: string;
};

type AiVerification = {
  id: number;
  questionId: number;
  verificationStatus: 'pending' | 'verified' | 'conflicting' | 'error';
  aiRecommendedAnswer?: string;
  officialAnswerLetter?: string;
  explanationOfDifference?: string;
  evidenceRating: number;
  scientificEvidence?: string;
  aiModelsConsulted: string[];
  lastVerifiedAt: string;
};

type ConflictingAnswer = {
  questionId: number;
  aiRecommendedAnswer: string;
  officialAnswer: string;
  explanation: string;
};

const AnswerVerification: React.FC = () => {
  const { user } = useUser();
  const { t, language } = useLanguage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [isVerifyDialogOpen, setIsVerifyDialogOpen] = useState(false);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const [selectedVerification, setSelectedVerification] = useState<AiVerification | null>(null);

  // Queries
  const { data: questions = [], isLoading: isLoadingQuestions } = useQuery({
    queryKey: ['/api/questions', user?.id],
    queryFn: async () => {
      const response = await apiRequest(`/api/questions?userId=${user?.id}`, { method: 'GET' });
      return response as Question[];
    },
    enabled: !!user,
  });

  const { data: conflictingAnswers = [], isLoading: isLoadingConflicts } = useQuery({
    queryKey: ['/api/conflicting-answers', user?.id],
    queryFn: async () => {
      const response = await apiRequest(`/api/conflicting-answers?userId=${user?.id}`, { method: 'GET' });
      return response as ConflictingAnswer[];
    },
    enabled: !!user,
  });

  // For a specific question verification
  const getVerificationDetails = async (questionId: number): Promise<AiVerification | null> => {
    const response = await apiRequest(`/api/ai-verification/${questionId}`, { method: 'GET' });
    return response as AiVerification | null;
  };

  // Mutations
  const verifyQuestionMutation = useMutation({
    mutationFn: async (questionId: number) => {
      const response = await apiRequest(`/api/ai-verification/${questionId}`, {
        method: 'POST',
      });
      return response as { verification: AiVerification };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/conflicting-answers'] });
      setIsVerifyDialogOpen(false);
      toast({
        title: t('verifyAnswers.verificationInitiated'),
        description: t('verifyAnswers.verificationInitiatedDesc'),
      });
    },
    onError: (error: any) => {
      toast({
        title: t('verifyAnswers.verificationError'),
        description: error.message || t('verifyAnswers.verificationErrorDesc'),
        variant: 'destructive',
      });
    },
  });

  // Event handlers
  const handleVerifyQuestion = (question: Question) => {
    setSelectedQuestion(question);
    setIsVerifyDialogOpen(true);
  };

  const startVerification = () => {
    if (selectedQuestion) {
      verifyQuestionMutation.mutate(selectedQuestion.id);
    }
  };

  const handleViewVerificationDetails = async (questionId: number) => {
    try {
      const verification = await getVerificationDetails(questionId);
      setSelectedVerification(verification);
      setIsDetailsDialogOpen(true);
    } catch (error) {
      toast({
        title: t('verifyAnswers.fetchError'),
        description: t('verifyAnswers.fetchErrorDesc'),
        variant: 'destructive',
      });
    }
  };

  // Filter questions that have multiple choice format with correct answers
  const verifiableQuestions = questions.filter(
    (q) => q.isMultipleChoice && q.correctOption
  );

  // Get questions with conflicts
  const questionsWithConflicts = questions.filter(
    (q) => conflictingAnswers.some((c) => c.questionId === q.id)
  );

  return (
    <div className="container py-10">
      <div className="mb-8 space-y-4">
        <h1 className="text-3xl font-bold tracking-tight">{t('verifyAnswers.title')}</h1>
        <p className="text-muted-foreground">{t('verifyAnswers.description')}</p>
      </div>

      <Tabs defaultValue="conflicts" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="conflicts">
            {t('verifyAnswers.conflictsTab')}
            {conflictingAnswers.length > 0 ? (
              <Badge variant="destructive" className="ml-2">{conflictingAnswers.length}</Badge>
            ) : null}
          </TabsTrigger>
          <TabsTrigger value="questions">{t('verifyAnswers.questionsTab')}</TabsTrigger>
        </TabsList>
        
        {/* Conflicts Tab */}
        <TabsContent value="conflicts">
          {isLoadingConflicts ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : conflictingAnswers.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>{t('verifyAnswers.noConflicts')}</CardTitle>
                <CardDescription>{t('verifyAnswers.noConflictsDesc')}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center p-6">
                  <CheckCircle className="h-16 w-16 text-green-500" />
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>{t('verifyAnswers.conflictsFound', { count: conflictingAnswers.length })}</AlertTitle>
                <AlertDescription>
                  {t('verifyAnswers.conflictsFoundDesc')}
                </AlertDescription>
              </Alert>
              
              {questionsWithConflicts.map((question) => {
                const conflict = conflictingAnswers.find(c => c.questionId === question.id);
                if (!conflict) return null;
                
                return (
                  <Card key={question.id} className="border-red-200">
                    <CardHeader>
                      <div className="flex justify-between">
                        <CardTitle className="text-lg">
                          {question.question.substring(0, 100)}
                          {question.question.length > 100 ? '...' : ''}
                        </CardTitle>
                        <Badge variant="outline" className="ml-2">
                          {question.difficulty}
                        </Badge>
                      </div>
                      <CardDescription>
                        {t('verifyAnswers.questionId')}: {question.id}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-4 bg-red-50 rounded-lg">
                            <h3 className="font-semibold">{t('verifyAnswers.officialAnswer')}:</h3>
                            <div className="mt-2 flex items-center">
                              <Badge variant="outline" className="text-lg mr-2">
                                {conflict.officialAnswer}
                              </Badge>
                              <span className="text-muted-foreground">{t('verifyAnswers.fromGabarito')}</span>
                            </div>
                          </div>
                          
                          <div className="p-4 bg-blue-50 rounded-lg">
                            <h3 className="font-semibold">{t('verifyAnswers.aiRecommendedAnswer')}:</h3>
                            <div className="mt-2 flex items-center">
                              <Badge variant="outline" className="text-lg mr-2">
                                {conflict.aiRecommendedAnswer}
                              </Badge>
                              <span className="text-muted-foreground">{t('verifyAnswers.basedOnEvidence')}</span>
                            </div>
                          </div>
                        </div>
                        
                        <Separator />
                        
                        <div>
                          <h3 className="font-semibold mb-2">{t('verifyAnswers.explanation')}:</h3>
                          <p className="text-sm">{conflict.explanation}</p>
                        </div>
                      </div>
                    </CardContent>
                    
                    <CardFooter className="flex justify-between">
                      <Button variant="outline" onClick={() => handleViewVerificationDetails(question.id)}>
                        {t('verifyAnswers.viewDetails')}
                      </Button>
                      <Button onClick={() => handleVerifyQuestion(question)}>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        {t('verifyAnswers.verifyAgain')}
                      </Button>
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
        
        {/* Questions Tab */}
        <TabsContent value="questions">
          {isLoadingQuestions ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : verifiableQuestions.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>{t('verifyAnswers.noQuestions')}</CardTitle>
                <CardDescription>{t('verifyAnswers.noQuestionsDesc')}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center p-6">
                  <FileQuestion className="h-16 w-16 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              <Alert>
                <FileQuestion className="h-4 w-4" />
                <AlertTitle>{t('verifyAnswers.verifiableQuestionsFound', { count: verifiableQuestions.length })}</AlertTitle>
                <AlertDescription>
                  {t('verifyAnswers.verifiableQuestionsFoundDesc')}
                </AlertDescription>
              </Alert>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {verifiableQuestions.slice(0, 10).map((question) => (
                  <Card key={question.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between">
                        <CardTitle className="text-md">
                          {question.question.substring(0, 80)}
                          {question.question.length > 80 ? '...' : ''}
                        </CardTitle>
                        <Badge variant="outline" className="ml-2">
                          {question.difficulty}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="py-2">
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <span>{t('verifyAnswers.correctAnswer')}: {question.correctOption}</span>
                        <span>{t('verifyAnswers.questionId')}: {question.id}</span>
                      </div>
                    </CardContent>
                    
                    <CardFooter className="pt-2">
                      <Button 
                        className="w-full" 
                        variant="outline"
                        onClick={() => handleVerifyQuestion(question)}
                      >
                        <Sparkles className="mr-2 h-4 w-4" />
                        {t('verifyAnswers.verifyWithAi')}
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
              
              {verifiableQuestions.length > 10 && (
                <div className="text-center mt-4">
                  <p className="text-muted-foreground">
                    {t('verifyAnswers.showingLimited', { 
                      shown: 10, 
                      total: verifiableQuestions.length 
                    })}
                  </p>
                </div>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Verify Question Dialog */}
      <Dialog open={isVerifyDialogOpen} onOpenChange={setIsVerifyDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('verifyAnswers.verifyQuestionTitle')}</DialogTitle>
            <DialogDescription>
              {t('verifyAnswers.verifyQuestionDescription')}
            </DialogDescription>
          </DialogHeader>
          
          {selectedQuestion && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="font-medium">{t('verifyAnswers.question')}:</h3>
                <p className="text-sm border p-3 rounded-md bg-muted/50">{selectedQuestion.question}</p>
              </div>
              
              {selectedQuestion.correctOption && (
                <div className="flex items-center">
                  <span className="font-medium mr-2">{t('verifyAnswers.currentAnswer')}:</span>
                  <Badge>{selectedQuestion.correctOption}</Badge>
                </div>
              )}
              
              <Alert>
                <Sparkles className="h-4 w-4" />
                <AlertDescription>
                  {t('verifyAnswers.aiVerificationExplanation')}
                </AlertDescription>
              </Alert>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsVerifyDialogOpen(false)}>
              {t('cancel')}
            </Button>
            <Button 
              onClick={startVerification}
              disabled={verifyQuestionMutation.isPending}
            >
              {verifyQuestionMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('verifyAnswers.processing')}
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  {t('verifyAnswers.verifyNow')}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Verification Details Dialog */}
      <Dialog open={isDetailsDialogOpen} onOpenChange={setIsDetailsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('verifyAnswers.verificationDetailsTitle')}</DialogTitle>
            <DialogDescription>
              {t('verifyAnswers.verificationDetailsDescription')}
            </DialogDescription>
          </DialogHeader>
          
          {selectedVerification && (
            <div className="space-y-6 py-4">
              <div className="flex items-center justify-between">
                <div className="space-x-2">
                  <Badge variant={
                    selectedVerification.verificationStatus === 'verified' ? 'default' :
                    selectedVerification.verificationStatus === 'conflicting' ? 'destructive' :
                    selectedVerification.verificationStatus === 'pending' ? 'outline' : 'secondary'
                  }>
                    {selectedVerification.verificationStatus.toUpperCase()}
                  </Badge>
                  
                  <span className="text-sm text-muted-foreground">
                    {t('verifyAnswers.lastVerified')}: {new Date(selectedVerification.lastVerifiedAt).toLocaleString()}
                  </span>
                </div>
                
                <div className="flex items-center space-x-1">
                  <span className="text-sm font-medium">{t('verifyAnswers.evidenceRating')}:</span>
                  <Progress value={selectedVerification.evidenceRating * 20} className="w-20 h-2" />
                  <span className="text-sm">{selectedVerification.evidenceRating}/5</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="font-medium">{t('verifyAnswers.aiRecommendedAnswer')}:</h3>
                <div className="flex items-center space-x-2">
                  <Badge className="text-lg" variant="outline">
                    {selectedVerification.aiRecommendedAnswer || '?'}
                  </Badge>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="font-medium">{t('verifyAnswers.officialAnswer')}:</h3>
                <div className="flex items-center space-x-2">
                  <Badge className="text-lg" variant="outline">
                    {selectedVerification.officialAnswerLetter || t('verifyAnswers.notAvailable')}
                  </Badge>
                </div>
              </div>
              
              {selectedVerification.explanationOfDifference && (
                <div className="space-y-2">
                  <h3 className="font-medium">{t('verifyAnswers.explanationOfDifference')}:</h3>
                  <p className="text-sm border p-3 rounded-md bg-muted/50">
                    {selectedVerification.explanationOfDifference}
                  </p>
                </div>
              )}
              
              {selectedVerification.scientificEvidence && (
                <div className="space-y-2">
                  <h3 className="font-medium">{t('verifyAnswers.scientificEvidence')}:</h3>
                  <p className="text-sm border p-3 rounded-md bg-muted/50">
                    {selectedVerification.scientificEvidence}
                  </p>
                </div>
              )}
              
              {selectedVerification.aiModelsConsulted?.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-medium">{t('verifyAnswers.aiModelsConsulted')}:</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedVerification.aiModelsConsulted.map((model, index) => (
                      <Badge key={index} variant="secondary">
                        {model}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button onClick={() => setIsDetailsDialogOpen(false)}>
              {t('close')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AnswerVerification;