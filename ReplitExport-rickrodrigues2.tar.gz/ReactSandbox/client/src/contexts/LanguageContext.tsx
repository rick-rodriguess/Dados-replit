import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

// Definir os idiomas suportados
export type Language = 'pt' | 'en';

// Interface para o contexto de idioma
interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

// Criar o contexto
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Dicionário de traduções
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navegação
    'nav.dashboard': 'Dashboard',
    'nav.questions': 'Questions',
    'nav.flashcards': 'Flashcards',
    'nav.practice': 'Practice Tests',
    'nav.analytics': 'Analytics',
    'nav.answerKeys': 'Answer Keys',
    'nav.verifyAnswers': 'Verify Answers',
    'nav.logout': 'Logout',
    'nav.login': 'Login',
    'nav.register': 'Register',
    
    // Sistema
    'msg.loading': 'Loading...',
    'msg.pleaseWait': 'Please wait while we set up your experience',
    
    // Cabeçalhos e títulos
    'title.dashboard': 'Dashboard',
    'title.questions': 'Questions',
    'title.flashcards': 'Flashcards',
    'title.practice': 'Practice Tests',
    'title.analytics': 'Analytics',
    'title.import': 'Import Questions from PNA Exam',
    'title.importFromPdf': 'Import Portuguese PNA Questions',
    'msg.importPdfDescription': 'Import questions directly from the official PNA exam in PDF format. The content will be maintained in its original language.',
    'button.importFromPdf': 'Import from PDF',
    'button.viewExamplePdf': 'View Example PDF',
    'title.login': 'Login',
    'title.register': 'Register',
    
    // Botões comuns
    'button.save': 'Save',
    'button.cancel': 'Cancel',
    'button.add': 'Add',
    'button.edit': 'Edit',
    'button.delete': 'Delete',
    'button.import': 'Import',
    'button.export': 'Export',
    'button.start': 'Start',
    'button.stop': 'Stop',
    'button.submit': 'Submit',
    'button.analyze': 'Analyze Questions',
    'cancel': 'Cancel',
    'close': 'Close',
    'save': 'Save',
    'update': 'Update',
    'saving': 'Saving...',
    'updating': 'Updating...',
    'importing': 'Importing...',
    
    // Forms e inputs
    'form.username': 'Username',
    'form.password': 'Password',
    'form.displayName': 'Display Name',
    'form.specialty': 'Specialty',
    'form.difficulty': 'Difficulty',
    'form.question': 'Question',
    'form.answer': 'Answer',
    'form.reference': 'Reference',
    'form.easy': 'Easy',
    'form.medium': 'Medium',
    'form.hard': 'Hard',
    'form.selectSpecialty': 'Select a specialty',
    'form.selectDifficulty': 'Select difficulty',
    'form.batchTitle': 'Batch Name',
    
    // Mensagens
    'msg.welcome': 'Welcome back',
    'msg.studyTime': 'Study time today',
    'msg.performance': 'Overall Performance',
    'msg.recommendations': 'Study Recommendations',
    'msg.noQuestions': 'No questions found. Add your first question!',
    'msg.importSuccess': 'Successfully imported {{count}} questions.',
    'msg.loginRequired': 'You must be logged in to import questions.',
    'msg.noQuestionsToImport': 'No questions to import. Please paste and parse questions first.',
    'msg.parsingError': 'Failed to parse questions. Please check the format.',
    'msg.pasteText': 'Please paste the exam questions text first.',
    'msg.parsingQuestions': 'Parsing questions...',
    'msg.invalidFileType': 'Invalid file type. Please upload a PDF file.',
    'msg.searchQuestions': 'Search questions...',
    'form.allSpecialties': 'All Specialties',
    'form.allDifficulties': 'All Difficulties',
    
    // Componentes específicos
    'quickActions.title': 'Quick Actions',
    'quickActions.add': 'Add Question',
    'quickActions.practice': 'Start Practice',
    'quickActions.flashcard': 'Create Flashcard',
    'recentQuestions.title': 'Recent Questions',
    'studyTimer.title': 'Study Timer',
    'studyTimer.start': 'Start Timer',
    'studyTimer.stop': 'Stop Timer',
    'studyTimer.specialty': 'Select specialty to focus on',
    'studyTimer.focus': 'What are you studying?',
    'performanceOverview.title': 'Performance Overview',
    'language.select': 'Language',
    
    // Answer Keys
    'gabaritos.title': 'Answer Keys',
    'gabaritos.description': 'Manage answer keys for PNA exams',
    'gabaritos.addButton': 'Add Answer Key',
    'gabaritos.importButton': 'Import Answers',
    'gabaritos.noData': 'No answer keys found',
    'gabaritos.noDataDesc': 'Add your first answer key to start verifying your answers',
    'gabaritos.addFirstButton': 'Add First Answer Key',
    'gabaritos.yearHeader': 'PNA {{year}} Exam',
    'gabaritos.yearDescription': 'Answer keys for this exam year',
    'gabaritos.version': 'Version',
    'gabaritos.source': 'Source',
    'gabaritos.questionCount': 'Questions',
    'gabaritos.createdAt': 'Created At',
    'gabaritos.actions': 'Actions',
    'gabaritos.addDialogTitle': 'Add Answer Key',
    'gabaritos.addDialogDescription': 'Add a new official answer key for PNA exam',
    'gabaritos.editTitle': 'Edit Answer Key',
    'gabaritos.editDescription': 'Update the answer key information',
    'gabaritos.year': 'Year',
    'gabaritos.selectVersion': 'Select Version',
    'gabaritos.sourcePlaceholder': 'e.g. Official, Prep School',
    'gabaritos.answers': 'Answers',
    'gabaritos.addAnswer': 'Add Answer',
    'gabaritos.questionNumber': 'Question #',
    'gabaritos.option': 'Option',
    'gabaritos.addSuccess': 'Answer key added',
    'gabaritos.addSuccessDesc': 'The answer key has been successfully added',
    'gabaritos.addError': 'Failed to add answer key',
    'gabaritos.addErrorDesc': 'There was an error adding the answer key',
    'gabaritos.updateSuccess': 'Answer key updated',
    'gabaritos.updateSuccessDesc': 'The answer key has been successfully updated',
    'gabaritos.updateError': 'Failed to update answer key',
    'gabaritos.updateErrorDesc': 'There was an error updating the answer key',
    'gabaritos.deleteSuccess': 'Answer key deleted',
    'gabaritos.deleteSuccessDesc': 'The answer key has been successfully deleted',
    'gabaritos.deleteError': 'Failed to delete answer key',
    'gabaritos.deleteErrorDesc': 'There was an error deleting the answer key',
    'gabaritos.confirmDelete': 'Are you sure you want to delete this answer key?',
    'gabaritos.importTitle': 'Import Answers',
    'gabaritos.importDescription': 'Import answers in bulk by pasting a formatted list',
    'gabaritos.answersText': 'Answers List',
    'gabaritos.answersTextPlaceholder': '1:A, 2:B, 3:C...',
    'gabaritos.answersTextHelper': 'Format: "Question Number:Option" separated by commas, semicolons, or new lines.',
    'gabaritos.importError': 'Import Error',
    'gabaritos.parseError': 'Failed to parse answer',
    'gabaritos.yearMinError': 'Year must be 2000 or later',
    'gabaritos.yearMaxError': 'Year must be 2100 or earlier',
    'gabaritos.versionError': 'Version is required',
    'gabaritos.sourceError': 'Source is required',
    'gabaritos.questionNumberError': 'Question number must be 1 or greater',
    'gabaritos.optionError': 'Option is required',
    'gabaritos.optionMaxError': 'Option must be a single letter',
    'gabaritos.answersTextError': 'Answers text is required',
    
    // Answer Verification
    'verifyAnswers.title': 'Verify Answers',
    'verifyAnswers.description': 'Verify exam answers against AI models and official sources',
    'verifyAnswers.conflictsTab': 'Conflicts',
    'verifyAnswers.questionsTab': 'Questions',
    'verifyAnswers.noConflicts': 'No conflicts found',
    'verifyAnswers.noConflictsDesc': 'There are no conflicts between official answers and AI verifications',
    'verifyAnswers.conflictsFound': '{{count}} conflicts found',
    'verifyAnswers.conflictsFoundDesc': 'We found discrepancies between official answers and evidence-based recommendations',
    'verifyAnswers.questionId': 'Question ID',
    'verifyAnswers.officialAnswer': 'Official Answer',
    'verifyAnswers.fromGabarito': 'From answer key',
    'verifyAnswers.aiRecommendedAnswer': 'AI Recommended Answer',
    'verifyAnswers.basedOnEvidence': 'Based on evidence',
    'verifyAnswers.explanation': 'Explanation',
    'verifyAnswers.viewDetails': 'View Details',
    'verifyAnswers.verifyAgain': 'Verify Again',
    'verifyAnswers.noQuestions': 'No questions to verify',
    'verifyAnswers.noQuestionsDesc': 'Add multiple-choice questions with correct answers to verify',
    'verifyAnswers.verifiableQuestionsFound': '{{count}} verifiable questions found',
    'verifyAnswers.verifiableQuestionsFoundDesc': 'You can verify these questions with AI assistance',
    'verifyAnswers.correctAnswer': 'Correct Answer',
    'verifyAnswers.verifyWithAi': 'Verify with AI',
    'verifyAnswers.showingLimited': 'Showing {{shown}} of {{total}} questions',
    'verifyAnswers.verifyQuestionTitle': 'Verify Question',
    'verifyAnswers.verifyQuestionDescription': 'AI will analyze this question and check if the answer aligns with current scientific evidence',
    'verifyAnswers.question': 'Question',
    'verifyAnswers.currentAnswer': 'Current Answer',
    'verifyAnswers.aiVerificationExplanation': 'AI verification consults multiple sources and compares with the latest medical literature',
    'verifyAnswers.processing': 'Processing',
    'verifyAnswers.verifyNow': 'Verify Now',
    'verifyAnswers.verificationDetailsTitle': 'Verification Details',
    'verifyAnswers.verificationDetailsDescription': 'Detailed information about the answer verification',
    'verifyAnswers.lastVerified': 'Last verified',
    'verifyAnswers.evidenceRating': 'Evidence Rating',
    'verifyAnswers.notAvailable': 'Not available',
    'verifyAnswers.explanationOfDifference': 'Explanation of Difference',
    'verifyAnswers.scientificEvidence': 'Scientific Evidence',
    'verifyAnswers.aiModelsConsulted': 'AI Models Consulted',
    'verifyAnswers.verificationInitiated': 'Verification initiated',
    'verifyAnswers.verificationInitiatedDesc': 'The answer verification has been initiated and will be processed soon',
    'verifyAnswers.verificationError': 'Verification error',
    'verifyAnswers.verificationErrorDesc': 'An error occurred while initiating verification',
    'verifyAnswers.fetchError': 'Fetch error',
    'verifyAnswers.fetchErrorDesc': 'Could not fetch verification details',
  },
  pt: {
    // Navegação
    'nav.dashboard': 'Painel',
    'nav.questions': 'Questões',
    'nav.flashcards': 'Flashcards',
    'nav.practice': 'Testes de Prática',
    'nav.analytics': 'Análises',
    'nav.answerKeys': 'Gabaritos',
    'nav.verifyAnswers': 'Verificar Respostas',
    'nav.logout': 'Sair',
    'nav.login': 'Entrar',
    'nav.register': 'Registrar',
    
    // Sistema
    'msg.loading': 'Carregando...',
    'msg.pleaseWait': 'Aguarde enquanto preparamos sua experiência',
    
    // Cabeçalhos e títulos
    'title.dashboard': 'Painel',
    'title.questions': 'Questões',
    'title.flashcards': 'Flashcards',
    'title.practice': 'Testes de Prática',
    'title.analytics': 'Análises',
    'title.import': 'Importar Questões do Exame PNA',
    'title.importFromPdf': 'Importar Questões PNA em Português',
    'msg.importPdfDescription': 'Importe questões diretamente do exame oficial PNA em formato PDF. O conteúdo será mantido em seu idioma original.',
    'button.importFromPdf': 'Importar do PDF',
    'button.viewExamplePdf': 'Ver PDF de Exemplo',
    'title.login': 'Entrar',
    'title.register': 'Registrar',
    
    // Botões comuns
    'button.save': 'Salvar',
    'button.cancel': 'Cancelar',
    'button.add': 'Adicionar',
    'button.edit': 'Editar',
    'button.delete': 'Excluir',
    'button.import': 'Importar',
    'button.export': 'Exportar',
    'button.start': 'Iniciar',
    'button.stop': 'Parar',
    'button.submit': 'Enviar',
    'button.analyze': 'Analisar Questões',
    'cancel': 'Cancelar',
    'close': 'Fechar',
    'save': 'Salvar',
    'update': 'Atualizar',
    'saving': 'Salvando...',
    'updating': 'Atualizando...',
    'importing': 'Importando...',
    
    // Forms e inputs
    'form.username': 'Nome de Usuário',
    'form.password': 'Senha',
    'form.displayName': 'Nome de Exibição',
    'form.specialty': 'Especialidade',
    'form.difficulty': 'Dificuldade',
    'form.question': 'Questão',
    'form.answer': 'Resposta',
    'form.reference': 'Referência',
    'form.easy': 'Fácil',
    'form.medium': 'Média',
    'form.hard': 'Difícil',
    'form.selectSpecialty': 'Selecione uma especialidade',
    'form.selectDifficulty': 'Selecione a dificuldade',
    'form.batchTitle': 'Nome do Lote',
    
    // Mensagens
    'msg.welcome': 'Bem-vindo(a) de volta',
    'msg.studyTime': 'Tempo de estudo hoje',
    'msg.performance': 'Desempenho Geral',
    'msg.recommendations': 'Recomendações de Estudo',
    'msg.noQuestions': 'Nenhuma questão encontrada. Adicione sua primeira questão!',
    'msg.importSuccess': 'Importadas com sucesso {{count}} questões.',
    'msg.loginRequired': 'Você precisa estar logado para importar questões.',
    'msg.noQuestionsToImport': 'Não há questões para importar. Por favor, cole e analise questões primeiro.',
    'msg.parsingError': 'Falha ao analisar questões. Por favor, verifique o formato.',
    'msg.pasteText': 'Por favor, cole o texto das questões do exame primeiro.',
    'msg.parsingQuestions': 'Analisando questões...',
    'msg.invalidFileType': 'Tipo de arquivo inválido. Por favor, faça upload de um arquivo PDF.',
    'msg.searchQuestions': 'Pesquisar questões...',
    'form.allSpecialties': 'Todas as Especialidades',
    'form.allDifficulties': 'Todas as Dificuldades',
    
    // Componentes específicos
    'quickActions.title': 'Ações Rápidas',
    'quickActions.add': 'Adicionar Questão',
    'quickActions.practice': 'Iniciar Prática',
    'quickActions.flashcard': 'Criar Flashcard',
    'recentQuestions.title': 'Questões Recentes',
    'studyTimer.title': 'Cronômetro de Estudo',
    'studyTimer.start': 'Iniciar Cronômetro',
    'studyTimer.stop': 'Parar Cronômetro',
    'studyTimer.specialty': 'Selecione especialidade para focar',
    'studyTimer.focus': 'O que você está estudando?',
    'performanceOverview.title': 'Visão Geral de Desempenho',
    'language.select': 'Idioma',
    
    // Answer Keys
    'gabaritos.title': 'Gabaritos',
    'gabaritos.description': 'Gerencie gabaritos para exames PNA',
    'gabaritos.addButton': 'Adicionar Gabarito',
    'gabaritos.importButton': 'Importar Respostas',
    'gabaritos.noData': 'Nenhum gabarito encontrado',
    'gabaritos.noDataDesc': 'Adicione seu primeiro gabarito para começar a verificar suas respostas',
    'gabaritos.addFirstButton': 'Adicionar Primeiro Gabarito',
    'gabaritos.yearHeader': 'Exame PNA {{year}}',
    'gabaritos.yearDescription': 'Gabaritos para este ano de exame',
    'gabaritos.version': 'Versão',
    'gabaritos.source': 'Fonte',
    'gabaritos.questionCount': 'Questões',
    'gabaritos.createdAt': 'Criado Em',
    'gabaritos.actions': 'Ações',
    'gabaritos.addDialogTitle': 'Adicionar Gabarito',
    'gabaritos.addDialogDescription': 'Adicione um novo gabarito oficial para o exame PNA',
    'gabaritos.editTitle': 'Editar Gabarito',
    'gabaritos.editDescription': 'Atualize as informações do gabarito',
    'gabaritos.year': 'Ano',
    'gabaritos.selectVersion': 'Selecione Versão',
    'gabaritos.sourcePlaceholder': 'ex: Oficial, Curso Preparatório',
    'gabaritos.answers': 'Respostas',
    'gabaritos.addAnswer': 'Adicionar Resposta',
    'gabaritos.questionNumber': 'Questão #',
    'gabaritos.option': 'Opção',
    'gabaritos.addSuccess': 'Gabarito adicionado',
    'gabaritos.addSuccessDesc': 'O gabarito foi adicionado com sucesso',
    'gabaritos.addError': 'Falha ao adicionar gabarito',
    'gabaritos.addErrorDesc': 'Ocorreu um erro ao adicionar o gabarito',
    'gabaritos.updateSuccess': 'Gabarito atualizado',
    'gabaritos.updateSuccessDesc': 'O gabarito foi atualizado com sucesso',
    'gabaritos.updateError': 'Falha ao atualizar gabarito',
    'gabaritos.updateErrorDesc': 'Ocorreu um erro ao atualizar o gabarito',
    'gabaritos.deleteSuccess': 'Gabarito excluído',
    'gabaritos.deleteSuccessDesc': 'O gabarito foi excluído com sucesso',
    'gabaritos.deleteError': 'Falha ao excluir gabarito',
    'gabaritos.deleteErrorDesc': 'Ocorreu um erro ao excluir o gabarito',
    'gabaritos.confirmDelete': 'Tem certeza que deseja excluir este gabarito?',
    'gabaritos.importTitle': 'Importar Respostas',
    'gabaritos.importDescription': 'Importe respostas em massa colando uma lista formatada',
    'gabaritos.answersText': 'Lista de Respostas',
    'gabaritos.answersTextPlaceholder': '1:A, 2:B, 3:C...',
    'gabaritos.answersTextHelper': 'Formato: "Número da Questão:Opção" separados por vírgulas, ponto e vírgula ou novas linhas.',
    'gabaritos.importError': 'Erro de Importação',
    'gabaritos.parseError': 'Falha ao analisar resposta',
    'gabaritos.yearMinError': 'O ano deve ser 2000 ou posterior',
    'gabaritos.yearMaxError': 'O ano deve ser 2100 ou anterior',
    'gabaritos.versionError': 'A versão é obrigatória',
    'gabaritos.sourceError': 'A fonte é obrigatória',
    'gabaritos.questionNumberError': 'O número da questão deve ser 1 ou maior',
    'gabaritos.optionError': 'A opção é obrigatória',
    'gabaritos.optionMaxError': 'A opção deve ser uma única letra',
    'gabaritos.answersTextError': 'O texto das respostas é obrigatório',
    
    // Answer Verification
    'verifyAnswers.title': 'Verificar Respostas',
    'verifyAnswers.description': 'Verifique respostas do exame com modelos de IA e fontes oficiais',
    'verifyAnswers.conflictsTab': 'Conflitos',
    'verifyAnswers.questionsTab': 'Questões',
    'verifyAnswers.noConflicts': 'Nenhum conflito encontrado',
    'verifyAnswers.noConflictsDesc': 'Não há conflitos entre as respostas oficiais e as verificações de IA',
    'verifyAnswers.conflictsFound': '{{count}} conflitos encontrados',
    'verifyAnswers.conflictsFoundDesc': 'Encontramos discrepâncias entre as respostas oficiais e as recomendações baseadas em evidências',
    'verifyAnswers.questionId': 'ID da Questão',
    'verifyAnswers.officialAnswer': 'Resposta Oficial',
    'verifyAnswers.fromGabarito': 'Do gabarito',
    'verifyAnswers.aiRecommendedAnswer': 'Resposta Recomendada pela IA',
    'verifyAnswers.basedOnEvidence': 'Baseada em evidências',
    'verifyAnswers.explanation': 'Explicação',
    'verifyAnswers.viewDetails': 'Ver Detalhes',
    'verifyAnswers.verifyAgain': 'Verificar Novamente',
    'verifyAnswers.noQuestions': 'Nenhuma questão para verificar',
    'verifyAnswers.noQuestionsDesc': 'Adicione questões de múltipla escolha com respostas corretas para verificar',
    'verifyAnswers.verifiableQuestionsFound': '{{count}} questões verificáveis encontradas',
    'verifyAnswers.verifiableQuestionsFoundDesc': 'Você pode verificar estas questões com assistência de IA',
    'verifyAnswers.correctAnswer': 'Resposta Correta',
    'verifyAnswers.verifyWithAi': 'Verificar com IA',
    'verifyAnswers.showingLimited': 'Mostrando {{shown}} de {{total}} questões',
    'verifyAnswers.verifyQuestionTitle': 'Verificar Questão',
    'verifyAnswers.verifyQuestionDescription': 'A IA analisará esta questão e verificará se a resposta está de acordo com as evidências científicas atuais',
    'verifyAnswers.question': 'Questão',
    'verifyAnswers.currentAnswer': 'Resposta Atual',
    'verifyAnswers.aiVerificationExplanation': 'A verificação por IA consulta múltiplas fontes e compara com a literatura médica mais recente',
    'verifyAnswers.processing': 'Processando',
    'verifyAnswers.verifyNow': 'Verificar Agora',
    'verifyAnswers.verificationDetailsTitle': 'Detalhes da Verificação',
    'verifyAnswers.verificationDetailsDescription': 'Informações detalhadas sobre a verificação da resposta',
    'verifyAnswers.lastVerified': 'Última verificação',
    'verifyAnswers.evidenceRating': 'Nível de Evidência',
    'verifyAnswers.notAvailable': 'Não disponível',
    'verifyAnswers.explanationOfDifference': 'Explicação da Diferença',
    'verifyAnswers.scientificEvidence': 'Evidência Científica',
    'verifyAnswers.aiModelsConsulted': 'Modelos de IA Consultados',
    'verifyAnswers.verificationInitiated': 'Verificação iniciada',
    'verifyAnswers.verificationInitiatedDesc': 'A verificação da resposta foi iniciada e será processada em breve',
    'verifyAnswers.verificationError': 'Erro de verificação',
    'verifyAnswers.verificationErrorDesc': 'Ocorreu um erro ao iniciar a verificação',
    'verifyAnswers.fetchError': 'Erro ao buscar dados',
    'verifyAnswers.fetchErrorDesc': 'Não foi possível buscar os detalhes da verificação',
  }
};

// Provider do contexto
interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  // Tenta obter o idioma salvo no localStorage, ou usa português como padrão
  const [language, setLanguageState] = useState<Language>(() => {
    const savedLanguage = localStorage.getItem('language');
    return (savedLanguage as Language) || 'pt';
  });

  // Função para traduzir uma chave
  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  // Função para alterar o idioma e salvar no localStorage
  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    localStorage.setItem('language', newLanguage);
  };

  // Efeito para aplicar classe no body para estilos específicos do idioma
  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Hook personalizado para usar o contexto de idioma
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};