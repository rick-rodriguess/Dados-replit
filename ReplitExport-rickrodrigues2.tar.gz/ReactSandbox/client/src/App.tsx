import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { UserProvider } from "@/contexts/UserContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Questions from "@/pages/Questions";
import Flashcards from "@/pages/Flashcards";
import PracticeTests from "@/pages/PracticeTests";
import Analytics from "@/pages/Analytics";
import AnswerKeys from "@/pages/AnswerKeys";
import AnswerVerification from "@/pages/AnswerVerification";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import { useUser } from "@/contexts/UserContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useEffect } from "react";
import { useLocation } from "wouter";

function PrivateRoute({ component: Component, ...rest }: any) {
  const { user, isLoading } = useUser();
  const { t } = useLanguage();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/login");
    }
  }, [user, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-xl font-semibold mb-2">{t('msg.loading')}</div>
          <div className="text-gray-500">{t('msg.pleaseWait')}</div>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return <Component {...rest} />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/">
        <PrivateRoute component={Dashboard} />
      </Route>
      <Route path="/questions">
        <PrivateRoute component={Questions} />
      </Route>
      <Route path="/flashcards">
        <PrivateRoute component={Flashcards} />
      </Route>
      <Route path="/practice-tests">
        <PrivateRoute component={PracticeTests} />
      </Route>
      <Route path="/analytics">
        <PrivateRoute component={Analytics} />
      </Route>
      <Route path="/answer-keys">
        <PrivateRoute component={AnswerKeys} />
      </Route>
      <Route path="/answer-verification">
        <PrivateRoute component={AnswerVerification} />
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <UserProvider>
          <Router />
          <Toaster />
        </UserProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
