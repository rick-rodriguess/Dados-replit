import { useState, useEffect, useCallback, useRef } from 'react';
import { apiRequest } from '@/lib/queryClient';

interface TimerOptions {
  userId: number;
  specialtyId?: number;
  focus?: string;
  autoStart?: boolean;
}

export const useTimer = ({ userId, specialtyId, focus, autoStart = false }: TimerOptions) => {
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [activeSession, setActiveSession] = useState<any>(null);
  const [totalToday, setTotalToday] = useState<string>('0h 0m');
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch active session on initial render
  useEffect(() => {
    const fetchActiveSession = async () => {
      try {
        const res = await fetch(`/api/study-sessions/active?userId=${userId}`);
        if (res.ok) {
          const session = await res.json();
          if (session) {
            setActiveSession(session);
            // Calculate elapsed time for the active session
            const startTime = new Date(session.startTime).getTime();
            const elapsed = Math.floor((Date.now() - startTime) / 1000);
            setSeconds(elapsed);
            if (autoStart) {
              setIsRunning(true);
            }
          }
        }
      } catch (error) {
        console.error('Error fetching active session:', error);
      }
    };

    const fetchTotalStudyTimeToday = async () => {
      try {
        const res = await fetch(`/api/study-sessions/today?userId=${userId}`);
        if (res.ok) {
          const data = await res.json();
          setTotalToday(data.formatted);
        }
      } catch (error) {
        console.error('Error fetching total study time:', error);
      }
    };

    fetchActiveSession();
    fetchTotalStudyTimeToday();
  }, [userId, autoStart]);

  // Update the timer every second when running
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setSeconds(prev => prev + 1);
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isRunning]);

  const startTimer = useCallback(async () => {
    try {
      // If there's already an active session, just resume it
      if (activeSession) {
        setIsRunning(true);
        return;
      }

      // Otherwise, create a new session
      const res = await apiRequest('POST', '/api/study-sessions/start', {
        userId,
        specialtyId,
        focus,
        startTime: new Date(),
      });

      if (res.ok) {
        const newSession = await res.json();
        setActiveSession(newSession);
        setIsRunning(true);
        setSeconds(0);
      }
    } catch (error) {
      console.error('Error starting timer:', error);
    }
  }, [userId, specialtyId, focus, activeSession]);

  const pauseTimer = useCallback(() => {
    setIsRunning(false);
  }, []);

  const stopTimer = useCallback(async () => {
    if (!activeSession) return;

    try {
      const res = await apiRequest('PATCH', `/api/study-sessions/${activeSession.id}/end`, {});
      
      if (res.ok) {
        setIsRunning(false);
        setSeconds(0);
        setActiveSession(null);
        
        // Update total study time for today
        const totalRes = await fetch(`/api/study-sessions/today?userId=${userId}`);
        if (totalRes.ok) {
          const data = await totalRes.json();
          setTotalToday(data.formatted);
        }
      }
    } catch (error) {
      console.error('Error stopping timer:', error);
    }
  }, [activeSession, userId]);

  return {
    seconds,
    isRunning,
    startTimer,
    pauseTimer,
    stopTimer,
    totalToday,
    activeSession
  };
};
