import { pgTable, text, serial, integer, boolean, timestamp, json, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Medical specialty table schema
export const specialties = pgTable("specialties", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  color: text("color").notNull().default("#2563EB"), // Default color for specialty
});

// Question table schema
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  specialtyId: integer("specialty_id").notNull().references(() => specialties.id),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  difficulty: text("difficulty").notNull().default("medium"), // easy, medium, hard
  reference: text("reference"), // Optional evidence/reference
  createdAt: timestamp("created_at").defaultNow(),
  lastReviewedAt: timestamp("last_reviewed_at"),
  reviewCount: integer("review_count").notNull().default(0),
  isKnown: boolean("is_known").default(false),
  isMultipleChoice: boolean("is_multiple_choice").default(false),
  correctOption: text("correct_option"), // Stores the correct option letter (A, B, C, D, E)
  userSelectedOption: text("user_selected_option"), // Stores the user's selected option
});

// Flashcard table schema
export const flashcards = pgTable("flashcards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  questionId: integer("question_id").references(() => questions.id),
  front: text("front").notNull(),
  back: text("back").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  lastReviewedAt: timestamp("last_reviewed_at"),
  reviewCount: integer("review_count").notNull().default(0),
});

// Study session table schema
export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  specialtyId: integer("specialty_id").references(() => specialties.id),
  focus: text("focus"), // What specific topic they're focusing on
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // In seconds
  isActive: boolean("is_active").notNull().default(true),
});

// Question review records
export const questionReviews = pgTable("question_reviews", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  questionId: integer("question_id").notNull().references(() => questions.id),
  knewAnswer: boolean("knew_answer").notNull(),
  reviewedAt: timestamp("reviewed_at").notNull().defaultNow(),
});

// Practice test schema
export const practiceTests = pgTable("practice_tests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  questions: json("questions").$type<number[]>(), // Array of question IDs
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  score: integer("score"),
});

// Answer key schema (gabarito oficial)
export const answerKeys = pgTable("answer_keys", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  pdfUrl: text("pdf_url"), // URL to the PDF with the official answer key
  imageUrl: text("image_url"), // URL to an image of the answer key
  sourceType: text("source_type").notNull(), // "official", "user_defined"
  source: text("source"), // Description of the source: "2024 PNA", "Journal X", etc.
  year: integer("year"), // Year of the exam/source
  createdAt: timestamp("created_at").notNull().defaultNow(),
  mappedAnswers: jsonb("mapped_answers"), // JSON mapping: questionId => answerLetter
});

// AI verified answers schema 
export const aiVerifiedAnswers = pgTable("ai_verified_answers", {
  id: serial("id").primaryKey(),
  questionId: integer("question_id").notNull().references(() => questions.id),
  aiRecommendedAnswer: text("ai_recommended_answer"), // The option letter recommended by AI
  officialAnswerLetterIfDifferent: text("official_answer_letter"), // Only populated if different
  explanationOfDifference: text("explanation_of_difference"), // Explains why AI disagrees with official
  evidenceRating: integer("evidence_rating").notNull().default(0), // 1-5 rating for evidence strength
  evidenceSources: jsonb("evidence_sources"), // Array of sources: [{name, url, type}]
  lastVerifiedAt: timestamp("last_verified_at").notNull().defaultNow(),
  verificationStatus: text("verification_status").notNull().default("pending"), // pending, verified, conflicting
  aiModelsConsulted: jsonb("ai_models_consulted"), // Which AI models were used in the verification
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
});

export const insertSpecialtySchema = createInsertSchema(specialties).pick({
  name: true,
  color: true,
});

export const insertQuestionSchema = createInsertSchema(questions).pick({
  userId: true,
  specialtyId: true,
  question: true,
  answer: true,
  difficulty: true,
  reference: true,
  isMultipleChoice: true,
  correctOption: true,
  userSelectedOption: true,
});

export const insertFlashcardSchema = createInsertSchema(flashcards).pick({
  userId: true,
  questionId: true,
  front: true,
  back: true,
});

export const insertStudySessionSchema = createInsertSchema(studySessions).pick({
  userId: true,
  specialtyId: true,
  focus: true,
  startTime: true,
});

export const insertQuestionReviewSchema = createInsertSchema(questionReviews).pick({
  userId: true,
  questionId: true,
  knewAnswer: true,
});

export const insertPracticeTestSchema = createInsertSchema(practiceTests).pick({
  userId: true,
  name: true,
  questions: true,
});

export const insertAnswerKeySchema = createInsertSchema(answerKeys).pick({
  userId: true,
  name: true,
  pdfUrl: true,
  imageUrl: true,
  sourceType: true,
  source: true,
  year: true,
  mappedAnswers: true,
});

export const insertAiVerifiedAnswerSchema = createInsertSchema(aiVerifiedAnswers).pick({
  questionId: true,
  aiRecommendedAnswer: true,
  officialAnswerLetterIfDifferent: true,
  explanationOfDifference: true,
  evidenceRating: true,
  evidenceSources: true,
  verificationStatus: true,
  aiModelsConsulted: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Specialty = typeof specialties.$inferSelect;
export type InsertSpecialty = z.infer<typeof insertSpecialtySchema>;

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;

export type Flashcard = typeof flashcards.$inferSelect;
export type InsertFlashcard = z.infer<typeof insertFlashcardSchema>;

export type StudySession = typeof studySessions.$inferSelect;
export type InsertStudySession = z.infer<typeof insertStudySessionSchema>;

export type QuestionReview = typeof questionReviews.$inferSelect;
export type InsertQuestionReview = z.infer<typeof insertQuestionReviewSchema>;

export type PracticeTest = typeof practiceTests.$inferSelect;
export type InsertPracticeTest = z.infer<typeof insertPracticeTestSchema>;

export type AnswerKey = typeof answerKeys.$inferSelect;
export type InsertAnswerKey = z.infer<typeof insertAnswerKeySchema>;

export type AiVerifiedAnswer = typeof aiVerifiedAnswers.$inferSelect;
export type InsertAiVerifiedAnswer = z.infer<typeof insertAiVerifiedAnswerSchema>;
